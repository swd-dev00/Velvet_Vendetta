# Build Assist Agent

A Unity Editor package for working toward one persistent build objective: **inspect Unity → determine the next build action → guide or execute → observe → verify → continue**.

This is a new implementation. It does not contain or depend on the unavailable Unity Operator Agent archives from the earlier conversation, or the Velvet Vendetta browser game.

## Install

1. In Unity, use **Window → Package Manager → + → Install package from tarball** (called **Add package from tarball** in some versions). Select `BuildAssistAgent_0.1.0.tgz`.
2. Open **Window → AI → Build Assist Agent**.
3. In **Settings**, select your native Codex CLI executable, sign in using `codex login` in your terminal, and enable AI reasoning for this project. Windows requires the native `codex.exe`, not the npm `codex.cmd` wrapper. The integration uses CLI flags inspected in version **0.159.2**; older CLIs may need an update. Leave Model blank for the CLI default or set a model available to your account.
4. Enable Editor capture if you want automatic visual context. The package asks once through this project setting; you do not take screenshots yourself.
5. Start in **Guide** and enter an objective such as “Build the player HUD.” Work normally in Unity. Selection, fields, scene contents, compilation, Play Mode, console events, and tests update the observation. Verified steps trigger another reasoning pass automatically.

Target: **Unity 6 / 6000.x**, particularly the requested Unity 6.3 installation. Package dependency: Unity Test Framework **1.4.5**. Existing compatible newer versions may be retained by Unity's resolver. Native screenshot and OS-pointer support currently targets Windows. Scene, Inspector, persistence, reasoning, and action code are otherwise platform-neutral Editor C#.

**This package has not yet been compiled or exercised inside a real Unity Editor.** See [VALIDATION.md](VALIDATION.md). Linux .NET tests and C# parsing are not Unity compilation.

## What this build implements

- Persistent objective, step, mode, evidence checks, receipts, and progress across Editor/domain reloads.
- Event-driven observation with debouncing, periodic checks for missed changes, one request at a time, stale-response rejection, cancellation, and a 24-pass progress-review limit.
- Scene hierarchy, selection, components, missing scripts, selected serialized fields, selected C# source, packages, render pipeline, build target/state, runtime UIDocument trees, RectTransforms, and recently observed console messages.
- **Ctrl+Shift+E**: explain the pointer context. UI Toolkit uses panel picking; Scene view uses Unity's picking API. Automatic capture includes one Unity pane when needed and enabled, while Unity is foreground.
- Guide steps with machine-evaluated completion conditions. You do not have to confirm every completed click.
- Bounded GameObject creation, primitives, parenting, transforms, allowlisted components, serialized values and object references, prefab instantiation/saving, material creation, additive scenes, scene saves, reviewed script writes/attachment, deletion, Play Mode, and Unity tests.
- Automatic checks after actions; independent checks must pass before a completion claim is accepted. Compile and test outcomes are observed, not inferred from process launch.
- A Project Doctor panel for observable missing scripts, broken selected references, compile errors, and recent warnings/errors. It reports unknown compilation state honestly.
- User-edited project memory and transaction receipts with guarded recovery.

## Permissions

| Mode | Behavior |
| --- | --- |
| Observe | Collects local Unity context and diagnostics. No AI calls or mutations. |
| Guide | Reasons about the objective and gives exact steps with automatic checks. No mutations. |
| Operator | Executes supported scene actions. Saving scenes/prefabs, entering Play Mode, and running tests require review. |
| Full | Also allows reviewed complete C# writes/replacements, custom script attachment and GameObject deletion. |

All C# writes require Full and review: even a new runtime-looking script can execute Editor code after import. No arbitrary `eval`, shell action, unrestricted component lookup, or unrestricted MCP mutation is exposed. Existing file replacements require a matching SHA-256 from observation. Asset writes stay within non-symlink `Assets/` paths.

Codex receives an isolated temporary working directory, a read-only sandbox, a strict response schema, and disabled shell, app, plugin, hook, browser, computer-use and delegation features. User configuration and execution rules are ignored, while CLI authentication stays with the installed CLI. The Unity gateway validates every requested action again at execution time. This is an application permission boundary; it is not an OS sandbox around Unity or around arbitrary third-party project scripts. Only use a trusted CLI installation and managed CLI configuration.

## Verification and recovery

The package verifies concrete state: actual object/component presence, serialized values, transforms, file hashes, observed compilation, Play state, and current test-run counts. A test run with zero passing tests never passes verification. The agent must use relevant behavior evidence for runtime goals; state checks alone do not prove that a game feels correct.

Receipts are appended to `Library/BuildAssistAgent/transactions.jsonl`; overwritten file backups live beside them. Recovery requires Full, pauses the objective, and checks the current file hash before restoring it. Scene-file backups require manual review and restoration to avoid overwriting an open dirty scene. Scene object recovery only uses Unity Undo when the most recent group still belongs to that receipt. Later user changes block automatic recovery. Undo history and Library backups do not survive every project cleanup or Editor restart.

## Unity integrations and current boundaries

Native Editor APIs and Unity Test Framework provide the primary integration. Installed Assistant and Pipeline packages appear in observations; this build does **not** launch an unrestricted `unity mcp` or Assistant connection. Direct external writes would bypass the gateway. A future adapter can add explicit capabilities after version/capability discovery rather than assuming private or deprecated APIs.

This initial build does not provide universal control recognition: opaque IMGUI widgets, runtime Game-view raycasts, USS rule provenance, arbitrary package-specific workflows, input simulation, headless builds/deployment, and broad prefab-asset editing remain outside the implemented action set. UI Toolkit picking/capture needs DPI/layout validation on the target machine. The hierarchy is bounded to 600 objects; serialized fields and UI trees are also bounded and truncation is reported. Source context covers selected scripts rather than indexing the whole project. Console capture begins when the package loads, and compilation is unknown until a compiler cycle has been observed.

The progress-review limit prevents unattended reasoning loops. It can be resumed without replacing the objective. Configure AI/capture explicitly for each project; changing either setting pauses the objective. Model calls use your Codex account and may consume its allowance.

## Source and checks

- `Packages/com.buildassist.agent/Core`: Unity-independent policy, scheduling, file guards, process integration, and contracts.
- `Packages/com.buildassist.agent/Editor`: observation, pointer perception, loop, UI, actions, checks, tests, and persistence.
- `Packages/com.buildassist.agent/Tests/Editor`: integration tests that must run inside Unity.
- `tests`: executable .NET core tests and a .NET Standard 2.1 compatibility build.
- `tools/package.py`: deterministic UPM/source packaging, metadata generation and SHA-256 manifest.

Run with a .NET 8 SDK:

```sh
dotnet run --project tests/BuildAssist.Core.Tests.csproj
dotnet build tests/BuildAssist.Core.Compatibility.csproj
python3 tools/package.py
```

To run the package's Editor tests, add `"com.buildassist.agent"` to your project's `testables` array in `Packages/manifest.json`, then use **Window → General → Test Runner → EditMode**. See the validation checklist for actual Unity startup, guided progression, action, reload, and capture checks.

Active session/settings: `UserSettings/BuildAssistAgent.asset` (local). Stable project conventions: `ProjectSettings/BuildAssistAgent.memory.txt` (shareable, user-edited). No credentials are stored in either file.
