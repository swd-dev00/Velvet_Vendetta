import { useState, type ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import {
  Activity,
  ArrowRight,
  Bot,
  BrainCircuit,
  CheckCircle2,
  Clock3,
  Database,
  Fingerprint,
  GitBranch,
  Globe2,
  KeyRound,
  Network,
  Play,
  RotateCcw,
  ScrollText,
  Search,
  ShieldCheck,
  Sparkles,
  Workflow,
  type LucideIcon,
} from "lucide-react";

type CardSpec = { title: string; description: string; icon: LucideIcon };

function PageShell({
  eyebrow,
  title,
  description,
  children,
}: {
  eyebrow: string;
  title: string;
  description: string;
  children: ReactNode;
}) {
  const [, setLocation] = useLocation();
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-white">
      <nav className="sticky top-0 z-50 border-b border-slate-800 bg-slate-950/85 backdrop-blur-xl">
        <div className="container mx-auto flex items-center justify-between px-4 py-4">
          <button onClick={() => setLocation("/")} className="text-2xl font-black tracking-tight text-cyan-400">
            I-IN-TEAM
          </button>
          <div className="hidden items-center gap-6 md:flex">
            <button onClick={() => setLocation("/platform")} className="text-sm text-slate-300 hover:text-cyan-400">Platform</button>
            <button onClick={() => setLocation("/capabilities")} className="text-sm text-slate-300 hover:text-cyan-400">Capabilities</button>
            <button onClick={() => setLocation("/architecture")} className="text-sm text-slate-300 hover:text-cyan-400">Architecture</button>
            <button onClick={() => setLocation("/demo")} className="text-sm text-slate-300 hover:text-cyan-400">Prototype</button>
          </div>
          <Button onClick={() => setLocation("/contact")} className="bg-cyan-500 font-semibold text-slate-950 hover:bg-cyan-400">
            Request access
          </Button>
        </div>
      </nav>
      <header className="border-b border-slate-800">
        <div className="container mx-auto px-4 py-20">
          <span className="inline-flex rounded-full border border-cyan-400/30 bg-cyan-400/10 px-4 py-2 text-xs font-bold uppercase tracking-[0.2em] text-cyan-300">{eyebrow}</span>
          <h1 className="mt-6 max-w-5xl text-4xl font-black tracking-tight md:text-6xl">{title}</h1>
          <p className="mt-6 max-w-3xl text-lg leading-8 text-slate-300">{description}</p>
        </div>
      </header>
      <main>{children}</main>
      <footer className="mt-20 border-t border-slate-800 py-10 text-center text-sm text-slate-500">
        © 2026 I-IN-TEAM Systems. All rights reserved.
      </footer>
    </div>
  );
}

function Surface({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <section className={`rounded-2xl border border-slate-800 bg-slate-900/70 p-6 shadow-2xl shadow-black/10 ${className}`}>{children}</section>;
}

function InfoPage({ eyebrow, title, description, cards }: { eyebrow: string; title: string; description: string; cards: CardSpec[] }) {
  return (
    <PageShell eyebrow={eyebrow} title={title} description={description}>
      <div className="container mx-auto grid gap-6 px-4 py-16 md:grid-cols-2 xl:grid-cols-3">
        {cards.map(({ title: cardTitle, description: cardDescription, icon: Icon }) => (
          <Surface key={cardTitle} className="transition hover:-translate-y-1 hover:border-cyan-500/40">
            <Icon className="h-10 w-10 text-cyan-400" />
            <h2 className="mt-6 text-xl font-bold">{cardTitle}</h2>
            <p className="mt-3 leading-7 text-slate-400">{cardDescription}</p>
          </Surface>
        ))}
      </div>
    </PageShell>
  );
}

const cards = {
  platform: [
    { title: "Agent runtime", description: "Specialized agents with bounded roles, tools, permissions, and completion criteria.", icon: Bot },
    { title: "Workflow engine", description: "Triggers, branching logic, retries, approvals, and multi-agent handoffs.", icon: GitBranch },
    { title: "Control room", description: "Live runs, exceptions, queues, service levels, and operating metrics.", icon: Activity },
    { title: "Evidence layer", description: "Decision context, source references, approvals, and outcome verification.", icon: ShieldCheck },
  ],
  capabilities: [
    { title: "Workflow learning", description: "Observe recurring work and convert team knowledge into executable workflows.", icon: BrainCircuit },
    { title: "Multi-agent orchestration", description: "Coordinate agents, tools, approvals, and handoffs in one network.", icon: Network },
    { title: "Real-time operations", description: "Track every run, exception, queue, and service-level target.", icon: Activity },
    { title: "Human governance", description: "Keep approvals, policy gates, and escalation controls where they matter.", icon: Fingerprint },
    { title: "Evidence trails", description: "Inspect why an action occurred and what changed during execution.", icon: ScrollText },
    { title: "Continuous optimization", description: "Use run history to improve reliability, speed, and outcomes.", icon: Sparkles },
  ],
  architecture: [
    { title: "Experience layer", description: "Dashboards, workflow builder, human approvals, alerts, and reporting.", icon: Workflow },
    { title: "Orchestration layer", description: "Agent routing, policy evaluation, retries, and escalation controls.", icon: Network },
    { title: "Execution layer", description: "Bounded agents interacting with applications, APIs, and data systems.", icon: Database },
    { title: "Evidence layer", description: "Run history, source references, decision context, and verification.", icon: ShieldCheck },
  ],
};

export function Platform() {
  return <InfoPage eyebrow="Platform" title="One system for learning, running, and improving operations." description="I-IN-TEAM turns institutional process knowledge into a coordinated network of agents, controls, and evidence." cards={cards.platform} />;
}
export function Capabilities() {
  return <InfoPage eyebrow="Capabilities" title="Operational intelligence that moves work forward." description="Workflow discovery, agent coordination, governance, and measurable improvement inside one observable system." cards={cards.capabilities} />;
}
export function Architecture() {
  return <InfoPage eyebrow="Architecture" title="An operating network, not a collection of bots." description="Experience, orchestration, execution, and evidence remain separated so the system stays scalable and governable." cards={cards.architecture} />;
}
export function About() {
  return <InfoPage eyebrow="About" title="A stronger relationship between people, process, and intelligent systems." description="I-IN-TEAM amplifies institutional knowledge without hiding how decisions are made." cards={[
    { title: "Observe first", description: "Understand the real workflow before attempting to automate it.", icon: BrainCircuit },
    { title: "Keep humans in control", description: "Preserve oversight and accountability at the correct decision points.", icon: Fingerprint },
    { title: "Improve through evidence", description: "Use execution history to make the network measurably better.", icon: ScrollText },
  ]} />;
}
export function Blog() {
  return <InfoPage eyebrow="Insights" title="Field notes on intelligent operations." description="Research and implementation guidance for agent-enabled teams." cards={[
    { title: "Why agent networks need evidence layers", description: "Designing autonomous operations without sacrificing auditability.", icon: ScrollText },
    { title: "From SOP to executable workflow", description: "How team knowledge becomes structured orchestration.", icon: Workflow },
    { title: "Human approval is a system feature", description: "Why governance belongs inside the workflow.", icon: ShieldCheck },
  ]} />;
}
export function Careers() {
  return <InfoPage eyebrow="Careers" title="Help build the infrastructure teams will operate on next." description="We value people who think across systems, AI, operations, security, and human factors." cards={[
    { title: "Agent systems", description: "Design bounded, observable, tool-using agents.", icon: BrainCircuit },
    { title: "Platform engineering", description: "Build reliable orchestration and execution infrastructure.", icon: Network },
    { title: "Governance and security", description: "Create systems that remain accountable under autonomy.", icon: KeyRound },
  ]} />;
}
export function PrivacyPolicy() {
  return <InfoPage eyebrow="Legal" title="Privacy policy" description="Prototype privacy overview for product evaluation." cards={[
    { title: "Data minimization", description: "Collect only information required for approved workflows.", icon: ShieldCheck },
    { title: "Customer governance", description: "Retention and access controls remain organization-defined.", icon: KeyRound },
    { title: "Prototype notice", description: "The current demo does not submit or persist contact information.", icon: ScrollText },
  ]} />;
}
export function TermsOfService() {
  return <InfoPage eyebrow="Legal" title="Terms of service" description="Prototype terms overview for product evaluation." cards={[
    { title: "Authorized use", description: "Organizations define approved workflows, systems, and controls.", icon: ShieldCheck },
    { title: "Operational responsibility", description: "Production use requires validated integrations and oversight.", icon: Globe2 },
    { title: "Prototype status", description: "This experience does not execute external business actions.", icon: ScrollText },
  ]} />;
}
export function Security() {
  return <InfoPage eyebrow="Security" title="Autonomy with boundaries." description="Operational speed should not come at the cost of security, accountability, or human control." cards={[
    { title: "Least privilege", description: "Agents receive only the permissions required for the current task.", icon: KeyRound },
    { title: "Identity-bound actions", description: "Every action is attributed to a role, workflow, and execution context.", icon: Fingerprint },
    { title: "Evidence-preserving logs", description: "Decisions, retries, approvals, and outcomes remain traceable.", icon: ScrollText },
    { title: "Policy gates", description: "Sensitive operations can require deterministic controls and authorization.", icon: ShieldCheck },
  ]} />;
}
export function Integrations() {
  return <InfoPage eyebrow="Integrations" title="Operate across the systems your team already uses." description="Connect agents to applications, APIs, data stores, and browser workflows through governed integration profiles." cards={[
    { title: "Business applications", description: "Coordinate work across CRM, support, collaboration, and project systems.", icon: Globe2 },
    { title: "Data infrastructure", description: "Read and write governed information across databases and warehouses.", icon: Database },
    { title: "Custom APIs", description: "Connect internal services through structured authentication and policies.", icon: Network },
    { title: "Browser workflows", description: "Automate approved web processes when native APIs are unavailable.", icon: Workflow },
  ]} />;
}
export function Documentation() {
  return <InfoPage eyebrow="Documentation" title="Build with the operating model in view." description="Implementation guidance for agents, workflows, controls, integrations, and evidence." cards={[
    { title: "Quick start", description: "Create an organization, map a workflow, add agents, and run a controlled test.", icon: Sparkles },
    { title: "Agent design", description: "Define purpose, inputs, tools, permissions, and escalation behavior.", icon: BrainCircuit },
    { title: "Workflow orchestration", description: "Connect triggers, tasks, approvals, retries, and outputs.", icon: GitBranch },
    { title: "Audit and monitoring", description: "Inspect run history, evidence, timing, and exceptions.", icon: Activity },
  ]} />;
}

export function Contact() {
  const [submitted, setSubmitted] = useState(false);
  return (
    <PageShell eyebrow="Contact" title="Map the first workflow with us." description="Tell us where repetitive execution, coordination gaps, or limited visibility are slowing your team down.">
      <div className="container mx-auto px-4 py-16">
        <Surface className="mx-auto max-w-2xl">
          {submitted ? (
            <div className="py-12 text-center"><h2 className="text-3xl font-black text-cyan-400">Request received.</h2><p className="mt-4 text-slate-400">This prototype stores no submission data.</p></div>
          ) : (
            <form onSubmit={(event) => { event.preventDefault(); setSubmitted(true); }} className="space-y-5">
              <div className="grid gap-5 md:grid-cols-2"><input required placeholder="Name" className="rounded-xl border border-slate-700 bg-slate-950 p-3" /><input required type="email" placeholder="Work email" className="rounded-xl border border-slate-700 bg-slate-950 p-3" /></div>
              <input required placeholder="Organization" className="w-full rounded-xl border border-slate-700 bg-slate-950 p-3" />
              <textarea required placeholder="Which workflow should I-IN-TEAM transform?" className="min-h-36 w-full rounded-xl border border-slate-700 bg-slate-950 p-3" />
              <Button type="submit" className="w-full bg-cyan-500 font-semibold text-slate-950 hover:bg-cyan-400">Request discovery session</Button>
            </form>
          )}
        </Surface>
      </div>
    </PageShell>
  );
}

export function Agents() {
  const agents = ["Intake Analyst", "Operations Coordinator", "Compliance Reviewer", "Resolution Verifier"];
  return (
    <PageShell eyebrow="Agents" title="Specialized agents. One coordinated network." description="Each agent has a defined role, bounded permissions, observable performance, and explicit handoff conditions.">
      <div className="container mx-auto grid gap-6 px-4 py-16 md:grid-cols-2 xl:grid-cols-4">
        {agents.map((name, index) => <Surface key={name}><div className="flex items-center justify-between"><div className="rounded-2xl bg-cyan-400/10 p-3"><Bot className="text-cyan-400" /></div><span className={index === 2 ? "text-xs text-amber-300" : "text-xs text-emerald-300"}>{index === 2 ? "Approval gated" : "Active"}</span></div><h2 className="mt-6 text-xl font-bold">{name}</h2><div className="mt-5 space-y-3 text-sm"><div className="flex justify-between"><span className="text-slate-500">Success</span><span>{99 - index * 0.4}%</span></div><div className="flex justify-between"><span className="text-slate-500">Avg. latency</span><span>{(1.2 + index * 0.7).toFixed(1)}s</span></div><div className="flex justify-between"><span className="text-slate-500">Tasks today</span><span>{386 - index * 61}</span></div></div></Surface>)}
      </div>
    </PageShell>
  );
}

export function Workflows() {
  const workflows = [
    ["Customer escalation resolution", "Live", "Intake → classify → retrieve context → approval → resolution → verification"],
    ["Vendor onboarding", "Live", "Collect documents → validate → risk review → provision systems"],
    ["Executive briefing assembly", "Draft", "Collect signals → synthesize → verify sources → generate briefing"],
  ] as const;
  const [, setLocation] = useLocation();
  return (
    <PageShell eyebrow="Workflows" title="Turn operating knowledge into executable systems." description="Build, test, publish, and improve workflows without losing visibility into each decision or handoff.">
      <div className="container mx-auto space-y-5 px-4 py-16">
        {workflows.map(([name, status, flow]) => <Surface key={name}><div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between"><div><div className="flex items-center gap-3"><GitBranch className="text-cyan-400" /><h2 className="text-2xl font-bold">{name}</h2><span className={status === "Live" ? "rounded-full bg-emerald-500/15 px-3 py-1 text-xs text-emerald-300" : "rounded-full bg-amber-500/15 px-3 py-1 text-xs text-amber-300"}>{status}</span></div><p className="mt-4 text-slate-400">{flow}</p></div><Button onClick={() => setLocation("/demo")} variant="outline" className="border-cyan-500 text-cyan-400">Open prototype <ArrowRight className="ml-2 h-4 w-4" /></Button></div></Surface>)}
      </div>
    </PageShell>
  );
}

const steps = [
  ["01", "Capture request", "Intake Analyst", "Complete"],
  ["02", "Classify intent", "Intake Analyst", "Complete"],
  ["03", "Retrieve account context", "Operations Coordinator", "Complete"],
  ["04", "Evaluate policy", "Compliance Reviewer", "Approval"],
  ["05", "Execute resolution", "Operations Coordinator", "Queued"],
  ["06", "Verify outcome", "Resolution Verifier", "Queued"],
] as const;

export function Demo() {
  const [tab, setTab] = useState<"overview" | "workflow" | "agents" | "audit">("overview");
  const [selected, setSelected] = useState(3);
  const [running, setRunning] = useState(false);
  const [runCount, setRunCount] = useState(1482);
  const run = () => { setRunning(true); window.setTimeout(() => { setRunCount((value) => value + 1); setRunning(false); }, 900); };
  return (
    <PageShell eyebrow="Interactive prototype" title="I-IN-TEAM control room" description="Explore workflow orchestration, agent performance, human approvals, and auditable execution.">
      <div className="container mx-auto px-4 py-10">
        <div className="mb-6 flex flex-wrap gap-2 rounded-2xl border border-slate-800 bg-slate-900/80 p-2">{(["overview", "workflow", "agents", "audit"] as const).map((item) => <button key={item} onClick={() => setTab(item)} className={tab === item ? "rounded-xl bg-cyan-400 px-4 py-2 text-sm font-bold capitalize text-slate-950" : "rounded-xl px-4 py-2 text-sm font-semibold capitalize text-slate-400"}>{item}</button>)}</div>
        {tab === "overview" && <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-4">{[["Active workflows", "12", GitBranch], ["Agents online", "28", Bot], ["Success rate", "99.2%", CheckCircle2], ["Median cycle", "4m 12s", Clock3]].map(([label, value, Icon]) => <Surface key={String(label)}><Icon className="text-cyan-400" /><div className="mt-5 text-3xl font-black">{value}</div><div className="mt-2 text-sm text-slate-400">{label}</div></Surface>)}</div>}
        {tab === "workflow" && <div className="grid gap-6 xl:grid-cols-[1fr_340px]"><Surface><div className="flex flex-wrap items-center justify-between gap-4"><h2 className="text-2xl font-bold">Customer escalation resolution</h2><div className="flex gap-2"><Button variant="outline" onClick={() => setSelected(0)}><RotateCcw className="mr-2 h-4 w-4" />Reset</Button><Button onClick={run} disabled={running} className="bg-cyan-500 font-bold text-slate-950"><Play className="mr-2 h-4 w-4" />{running ? "Running…" : "Run workflow"}</Button></div></div><div className="mt-8 space-y-3">{steps.map(([id, title, agent, status], index) => <button key={id} onClick={() => setSelected(index)} className={selected === index ? "flex w-full items-center gap-4 rounded-xl border border-cyan-400/50 bg-cyan-400/10 p-4 text-left" : "flex w-full items-center gap-4 rounded-xl border border-slate-800 bg-slate-950/60 p-4 text-left"}><span className="rounded-lg bg-slate-800 p-3 text-cyan-400">{id}</span><span className="flex-1"><strong className="block">{title}</strong><small className="text-slate-500">{agent}</small></span><small className="text-slate-400">{status}</small></button>)}</div></Surface><Surface><span className="text-xs font-bold uppercase tracking-[0.2em] text-cyan-400">Selected step</span><h2 className="mt-3 text-xl font-bold">{steps[selected][1]}</h2><p className="mt-3 leading-7 text-slate-400">This node receives validated context, applies bounded logic, records evidence, and advances only when its completion criteria are satisfied.</p></Surface></div>}
        {tab === "agents" && <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-4">{["Intake Analyst", "Operations Coordinator", "Compliance Reviewer", "Resolution Verifier"].map((name, index) => <Surface key={name}><Bot className="text-cyan-400" /><h2 className="mt-5 text-xl font-bold">{name}</h2><p className="mt-3 text-slate-400">{index === 2 ? "Approval-gated policy specialist" : "Active network agent"}</p></Surface>)}</div>}
        {tab === "audit" && <Surface><div className="flex items-center justify-between"><div><span className="text-xs font-bold uppercase tracking-[0.2em] text-cyan-400">Audit trail</span><h2 className="mt-2 text-2xl font-bold">Run #WF-{runCount}</h2></div><div className="flex items-center gap-2 rounded-xl border border-slate-800 bg-slate-950 px-4 py-2 text-sm text-slate-400"><Search className="h-4 w-4" />Search events</div></div><div className="mt-8 divide-y divide-slate-800">{[["09:41:02", "Workflow triggered", "Customer portal"], ["09:41:04", "Intent classified", "Intake Analyst"], ["09:41:06", "Context retrieved", "Operations Coordinator"], ["09:41:08", "Policy gate evaluated", "Compliance Reviewer"], ["09:42:17", "Human approval recorded", "Operations lead"]].map(([time, event, actor]) => <div key={time} className="grid gap-3 py-5 md:grid-cols-[100px_1.5fr_1fr]"><code className="text-slate-500">{time}</code><strong>{event}</strong><span className="text-slate-400">{actor}</span></div>)}</div></Surface>}
      </div>
    </PageShell>
  );
}
