import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import {
  About,
  Agents,
  Architecture,
  Blog,
  Capabilities,
  Careers,
  Contact,
  Demo,
  Documentation,
  Integrations,
  Platform,
  PrivacyPolicy,
  Security,
  TermsOfService,
  Workflows,
} from "./pages/PrototypePages";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/platform" component={Platform} />
      <Route path="/capabilities" component={Capabilities} />
      <Route path="/architecture" component={Architecture} />
      <Route path="/about" component={About} />
      <Route path="/blog" component={Blog} />
      <Route path="/careers" component={Careers} />
      <Route path="/contact" component={Contact} />
      <Route path="/privacy" component={PrivacyPolicy} />
      <Route path="/terms" component={TermsOfService} />
      <Route path="/agents" component={Agents} />
      <Route path="/workflows" component={Workflows} />
      <Route path="/security" component={Security} />
      <Route path="/integrations" component={Integrations} />
      <Route path="/demo" component={Demo} />
      <Route path="/documentation" component={Documentation} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
