[CmdletBinding()]
param(
    [string]$ProjectPath = 'D:\Projects\Velvet_Vendetta\unity_base',
    [string]$ReviewPath = '',
    [string]$UnityEditor = 'D:\Unity\Editors\6000.3.25f1-x86_64\Editor\Unity.exe'
)

# Staging and inspection only. Never writes into ProjectPath or launches Unity.
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'Stage-Act0-Hardening.ps1')
$bundle = [IO.Path]::GetFullPath($PSScriptRoot)
$project = [IO.Path]::GetFullPath($ProjectPath).TrimEnd([IO.Path]::DirectorySeparatorChar)
if (-not (Test-Path -LiteralPath (Join-Path $project 'Assets') -PathType Container)) {
    throw "Unity Assets folder not found: $project"
}
if ([string]::IsNullOrWhiteSpace($ReviewPath)) {
    $ReviewPath = Join-Path $bundle ('review-' + [DateTime]::Now.ToString('yyyyMMdd-HHmmss') + '-' + [Guid]::NewGuid().ToString('N').Substring(0, 6))
}
$review = [IO.Path]::GetFullPath($ReviewPath).TrimEnd([IO.Path]::DirectorySeparatorChar)
Assert-ExternalReviewPath -ReviewPath $review -ProjectPath $project
if (Test-Path -LiteralPath $review) { throw 'ReviewPath already exists. Choose a new empty path.' }

function Join-SafePath([string]$Root, [string]$Relative) {
    if ([string]::IsNullOrWhiteSpace($Relative) -or [IO.Path]::IsPathRooted($Relative) -or $Relative.Contains(':')) {
        throw "Unsafe relative path: $Relative"
    }
    $relativeNative = $Relative.Replace('/', [IO.Path]::DirectorySeparatorChar)
    $rootFull = [IO.Path]::GetFullPath($Root).TrimEnd([IO.Path]::DirectorySeparatorChar)
    $candidate = [IO.Path]::GetFullPath((Join-Path $rootFull $relativeNative))
    if (-not $candidate.StartsWith($rootFull + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) {
        throw "Path escapes root: $Relative"
    }
    return $candidate
}
function Copy-ReviewFile([string]$Source, [string]$Destination) {
    $parent = [IO.Path]::GetDirectoryName($Destination)
    Assert-ExternalReviewPath -ReviewPath $parent -ProjectPath $project
    [void][IO.Directory]::CreateDirectory($parent)
    Assert-ExternalReviewPath -ReviewPath $parent -ProjectPath $project
    Assert-Act0UnlinkedAncestors $Destination
    [IO.File]::Copy($Source, $Destination, $false)
}
function Read-Guid([string]$Path) {
    foreach ($line in [IO.File]::ReadLines($Path)) {
        if ($line -match '^guid:\s*([0-9a-fA-F]{32})\s*$') { return $Matches[1].ToLowerInvariant() }
    }
    return ''
}
function Assert-NotLinked([IO.FileSystemInfo]$Item) {
    if (($Item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
        throw "Linked path requires separate review; comparison stopped: $($Item.FullName)"
    }
}
function Assert-UnlinkedAncestors([string]$Path) {
    Assert-Act0UnlinkedAncestors $Path
}
function Get-ProjectFiles([string]$Directory) {
    # Explicit traversal avoids silently following junctions or omitting inaccessible paths.
    foreach ($item in Get-ChildItem -LiteralPath $Directory -Force -ErrorAction Stop) {
        Assert-NotLinked $item
        if ($item.PSIsContainer) { Get-ProjectFiles $item.FullName } else { $item }
    }
}

$manifest = Get-Content -LiteralPath (Join-Path $bundle 'manifest.json') -Raw | ConvertFrom-Json
if ($manifest.format -ne 1) { throw 'Unsupported handoff manifest version.' }
$cloudRoot = Join-Path $bundle 'cloud'
Assert-UnlinkedAncestors $review
Assert-UnlinkedAncestors $project
Assert-UnlinkedAncestors $cloudRoot
$seen = @{}
foreach ($entry in $manifest.files) {
    if ($seen.ContainsKey($entry.path)) { throw "Duplicate manifest path: $($entry.path)" }
    $seen[$entry.path] = $true
    $source = Join-SafePath $cloudRoot $entry.path
    Assert-UnlinkedAncestors $source
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "Missing payload: $($entry.path)" }
    Assert-NotLinked (Get-Item -LiteralPath $source)
    if ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256) {
        throw "Payload hash mismatch: $($entry.path)"
    }
}

# Read the project completely before staging anything. All project writes are prohibited.
Assert-NotLinked (Get-Item -LiteralPath $project)
$assetsRoot = Join-Path $project 'Assets'
Assert-NotLinked (Get-Item -LiteralPath $assetsRoot)
# Traverse before creating staging files; reject linked or inaccessible content.
[void]@(Get-ProjectFiles $assetsRoot)
$includeSource = {
    param($File)
    if (@('.cs', '.meta', '.unity', '.prefab', '.asmdef', '.asmref', '.inputactions') -contains $File.Extension.ToLowerInvariant()) {
        return $true
    }
    if ($File.Extension -ne '.asset') { return $false }
    $stream = [IO.File]::OpenRead($File.FullName)
    try {
        $header = New-Object byte[] 5
        $count = $stream.Read($header, 0, 5)
        return ($count -eq 5 -and [Text.Encoding]::ASCII.GetString($header) -eq '%YAML')
    } finally { $stream.Dispose() }
}
Assert-ExternalReviewPath -ReviewPath $review -ProjectPath $project
[void][IO.Directory]::CreateDirectory($review)
Assert-ExternalReviewPath -ReviewPath $review -ProjectPath $project
$incomingRoot = Join-Path $review 'incoming'
$snapshotRoot = Join-Path $review 'existing-source-snapshot'
$snapshotAssets = Join-Path $snapshotRoot 'Assets'
$snapshotEntries = @(Copy-VerifiedAct0Snapshot -SourceDirectory $assetsRoot -SnapshotDirectory $snapshotAssets -ProjectPath $project -IncludeFile $includeSource)
$snapshotHashes = @(
    foreach ($entry in $snapshotEntries) {
        [pscustomobject]@{ path = 'Assets/' + $entry.RelativePath; sha256 = $entry.SHA256.ToLowerInvariant(); bytes = $entry.Bytes }
    }
)
$snapshotHashByPath = @{}
foreach ($entry in $snapshotHashes) { $snapshotHashByPath[$entry.path] = $entry.sha256 }
$existingFiles = @(Get-Act0SnapshotFiles -SourceDirectory $snapshotRoot)
$snapshotPrefix = $snapshotRoot + [IO.Path]::DirectorySeparatorChar
$filesReport = @()
$incomingGuids = @{}
foreach ($entry in $manifest.files) {
    $source = Join-SafePath $cloudRoot $entry.path
    $incomingFile = Join-SafePath $incomingRoot $entry.path
    Copy-ReviewFile $source $incomingFile
    if ((Get-FileHash -LiteralPath $incomingFile -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256) {
        throw "Payload changed while staging: $($entry.path)"
    }
    $destination = Join-SafePath $project $entry.path
    $state = 'new-path'
    $existingHash = ''
    if (Test-Path -LiteralPath $destination -PathType Container) {
        $state = 'file-directory-conflict'
    } elseif ($snapshotHashByPath.ContainsKey($entry.path)) {
        $existingHash = $snapshotHashByPath[$entry.path]
        $state = 'different-existing-file'
        if ($existingHash -eq $entry.sha256) { $state = 'identical' }
    }
    $filesReport += [pscustomobject]@{
        path = $entry.path; status = $state; incoming_sha256 = $entry.sha256; existing_sha256 = $existingHash
    }
    if ($entry.path.EndsWith('.meta', [StringComparison]::OrdinalIgnoreCase)) {
        $guid = Read-Guid $incomingFile
        if ($guid) { $incomingGuids[$guid] = $entry.path }
    }
}

$guidReport = @()
$entrypoints = @()
$legacyFiles = @()
$assemblies = @()
$sceneNames = @()
$typeIndex = @{}
$scriptGuids = @{}
$legacyPattern = 'Act0(FuneralDirector|OpeningSequence|PrototypeBootstrap|Input|Interaction|InteractionScanner|PhoneUI|ThirdPersonCameraRig)|Prototype_?Player_?Motor'
foreach ($file in $existingFiles) {
    $relative = $file.FullName.Substring($snapshotPrefix.Length).Replace([IO.Path]::DirectorySeparatorChar, '/')
    $inspectionPath = $file.FullName
    if ($file.Extension -eq '.meta') {
        $guid = Read-Guid $inspectionPath
        if ($guid -and $incomingGuids.ContainsKey($guid) -and $incomingGuids[$guid] -ne $relative) {
            $guidReport += [pscustomobject]@{ guid = $guid; incoming = $incomingGuids[$guid]; existing = $relative }
        }
        if ($file.Name.EndsWith('.cs.meta', [StringComparison]::OrdinalIgnoreCase) -and $guid) {
            $scriptGuids[$guid] = $relative.Substring(0, $relative.Length - 5)
        }
    }
    if ($file.Extension -eq '.asmdef' -or $file.Extension -eq '.asmref') { $assemblies += $relative }
    if ($file.Extension -eq '.unity' -and @('World_OldKentahten', 'INT_FuneralHome', 'INT_PlayerHome') -contains $file.BaseName) {
        $sceneNames += $relative
    }
    if ($file.Extension -eq '.cs') {
        $namespace = ''
        $lineNumber = 0
        if ($file.BaseName -match $legacyPattern) { $legacyFiles += $relative }
        foreach ($line in [IO.File]::ReadLines($inspectionPath)) {
            $lineNumber++
            if ($line -match '\bnamespace\s+([A-Za-z_][A-Za-z0-9_.]*)') { $namespace = $Matches[1] }
            if ($line -match '\bRuntimeInitializeOnLoadMethod\b') {
                $entrypoints += [pscustomobject]@{ path = $relative; line = $lineNumber; declaration = $line.Trim() }
            }
            if ($line -match '\b(class|struct|interface|enum)\s+([A-Za-z_][A-Za-z0-9_]*)') {
                $identity = $namespace + '.' + $Matches[2]
                if (-not $typeIndex.ContainsKey($identity)) { $typeIndex[$identity] = @() }
                $typeIndex[$identity] += $relative
            }
        }
    }
}
$typeReport = @()
foreach ($entry in $manifest.files) {
    if (-not $entry.path.EndsWith('.cs')) { continue }
    $namespace = ''
    foreach ($line in [IO.File]::ReadLines((Join-SafePath $incomingRoot $entry.path))) {
        if ($line -match '\bnamespace\s+([A-Za-z_][A-Za-z0-9_.]*)') { $namespace = $Matches[1] }
        if ($line -match '\b(class|struct|interface|enum)\s+([A-Za-z_][A-Za-z0-9_]*)') {
            $identity = $namespace + '.' + $Matches[2]
            if ($typeIndex.ContainsKey($identity)) {
                foreach ($existing in $typeIndex[$identity]) {
                    $typeReport += [pscustomobject]@{ type = $identity; incoming = $entry.path; existing = $existing }
                }
            }
        }
    }
}
$references = @()
foreach ($file in $existingFiles) {
    if (@('.unity', '.prefab') -notcontains $file.Extension) { continue }
    $relative = $file.FullName.Substring($snapshotPrefix.Length).Replace([IO.Path]::DirectorySeparatorChar, '/')
    $lineNumber = 0
    foreach ($line in [IO.File]::ReadLines((Join-SafePath $snapshotRoot $relative))) {
        $lineNumber++
        if ($line -match 'm_Script:.*guid:\s*([0-9a-fA-F]{32})') {
            $guid = $Matches[1].ToLowerInvariant()
            if ($scriptGuids.ContainsKey($guid)) {
                $references += [pscustomobject]@{ asset = $relative; line = $lineNumber; script = $scriptGuids[$guid]; guid = $guid }
            }
        }
    }
}
$report = [ordered]@{
    project = $project
    editor = $UnityEditor
    editor_exists = (Test-Path -LiteralPath $UnityEditor -PathType Leaf)
    source_base_commit = $manifest.base_commit
    project_modified = $false
    unity_launched = $false
    files = @($filesReport)
    duplicate_incoming_guids = @($guidReport)
    possible_type_collisions = @($typeReport)
    runtime_initializers = @($entrypoints)
    legacy_prototype_files = @($legacyFiles)
    serialized_script_references = @($references)
    scene_name_conflicts = @($sceneNames)
    assembly_boundaries = @($assemblies)
    snapshot_files = @($snapshotHashes)
    limits = @('Type/entry-point scanning is heuristic; Unity compilation remains required.',
        'The source snapshot excludes art binaries, packages, project settings, git metadata and player saves. It is not a full project backup.',
        'Before merging, checkpoint the complete Windows repository and player save files.',
        'Choose one startup path and reconcile old scene/prefab attachments before importing or pressing Play.',
        'Preserve existing metadata GUIDs when updating assets at existing paths.',
        'No earlier-prototype save migration is included.',
        'Snapshot checks detect observed source changes but do not lock the project; unsaved Editor changes are absent.')
}
function Assert-CurrentSnapshot {
    Assert-ExternalReviewPath -ReviewPath $review -ProjectPath $project
    $sourceFiles = @(Get-Act0SnapshotFiles -SourceDirectory $assetsRoot -IncludeFile $includeSource)
    $stagedFiles = @(Get-Act0SnapshotFiles -SourceDirectory $snapshotRoot)
    if ($sourceFiles.Count -ne $snapshotHashes.Count -or $stagedFiles.Count -ne $snapshotHashes.Count) {
        throw 'Source or staged inventory changed before report publication.'
    }
    foreach ($file in $sourceFiles) {
        $relative = 'Assets/' + $file.FullName.Substring($assetsRoot.Length + 1).Replace([IO.Path]::DirectorySeparatorChar, '/')
        if (-not $snapshotHashByPath.ContainsKey($relative) -or
            (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant() -ne $snapshotHashByPath[$relative]) {
            throw "Source changed before report publication: $relative"
        }
    }
    foreach ($file in $stagedFiles) {
        $relative = $file.FullName.Substring($snapshotPrefix.Length).Replace([IO.Path]::DirectorySeparatorChar, '/')
        if (-not $snapshotHashByPath.ContainsKey($relative) -or
            (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant() -ne $snapshotHashByPath[$relative]) {
            throw "Snapshot changed before report publication: $relative"
        }
    }
}
Assert-CurrentSnapshot
$reportPaths = @{}
foreach ($name in @('comparison.json', 'files.csv')) {
    $path = Join-Path $review ($name + '.pending')
    Assert-Act0UnlinkedAncestors $path
    if (Test-Path -LiteralPath $path) { throw "Pending report already exists: $path" }
    $reportPaths[$name] = $path
}
$report | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $reportPaths['comparison.json'] -Encoding UTF8
$filesReport | Export-Csv -LiteralPath $reportPaths['files.csv'] -NoTypeInformation -Encoding UTF8
$archiveHashes = @{}
foreach ($name in $reportPaths.Keys) {
    $archiveHashes[$name] = (Get-FileHash -LiteralPath $reportPaths[$name] -Algorithm SHA256).Hash.ToLowerInvariant()
}
foreach ($entry in $snapshotHashes) { $archiveHashes['existing-source-snapshot/' + $entry.path] = $entry.sha256 }

Add-Type -AssemblyName System.IO.Compression.FileSystem
$returnPath = Join-Path $review 'windows-comparison.zip'
$pendingZip = $returnPath + '.pending'
Assert-ExternalReviewPath -ReviewPath $review -ProjectPath $project
Assert-Act0UnlinkedAncestors $pendingZip
$archive = [IO.Compression.ZipFile]::Open($pendingZip, [IO.Compression.ZipArchiveMode]::Create)
try {
    foreach ($name in $reportPaths.Keys) {
        [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive, $reportPaths[$name], $name)
    }
    foreach ($entry in $snapshotHashes) {
        $snapshotFile = Join-SafePath $snapshotRoot $entry.path
        Assert-Act0UnlinkedAncestors $snapshotFile
        [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,
            $snapshotFile, ('existing-source-snapshot/' + $entry.path))
    }
} finally { $archive.Dispose() }
Assert-CurrentSnapshot
# Verify the compressed bytes too, before publishing a return artifact.
$archive = [IO.Compression.ZipFile]::OpenRead($pendingZip)
try {
    if ($archive.Entries.Count -ne $archiveHashes.Count) { throw 'Return ZIP entry-count mismatch.' }
    $seenEntries = @{}
    foreach ($entry in $archive.Entries) {
        if ($seenEntries.ContainsKey($entry.FullName) -or -not $archiveHashes.ContainsKey($entry.FullName)) {
            throw "Unexpected or duplicate return ZIP entry: $($entry.FullName)"
        }
        $seenEntries[$entry.FullName] = $true
        $stream = $entry.Open()
        $sha = [Security.Cryptography.SHA256]::Create()
        try { $hash = [BitConverter]::ToString($sha.ComputeHash($stream)).Replace('-', '').ToLowerInvariant() }
        finally { $sha.Dispose(); $stream.Dispose() }
        if ($hash -ne $archiveHashes[$entry.FullName]) { throw "Return ZIP hash mismatch: $($entry.FullName)" }
    }
} finally { $archive.Dispose() }

Assert-ExternalReviewPath -ReviewPath $review -ProjectPath $project
foreach ($name in $reportPaths.Keys) {
    Assert-Act0UnlinkedAncestors $reportPaths[$name]
    if ((Get-FileHash -LiteralPath $reportPaths[$name] -Algorithm SHA256).Hash.ToLowerInvariant() -ne $archiveHashes[$name]) {
        throw "Pending report changed before publication: $name"
    }
}
foreach ($name in $reportPaths.Keys) {
    [IO.File]::Move($reportPaths[$name], (Join-Path $review $name))
}
[IO.File]::Move($pendingZip, $returnPath)
Write-Output "Review staged: $review"
Write-Output "Return this file for source comparison: $returnPath"
Write-Output "Incoming files: $($filesReport.Count). Existing Unity source/reference files snapshotted: $($snapshotHashes.Count)."
Write-Output 'The Windows project is unchanged. Unity was not launched. Read comparison.json before planning the merge.'
