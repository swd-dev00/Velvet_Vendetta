# Adapted from the supplied hardening helper. Does not import assets or run Unity.
# Hash/inventory checks detect observed changes; they do not lock the source tree.
function Assert-Act0UnlinkedAncestors {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Path)

    $cursor = [IO.Path]::GetFullPath($Path)
    while (-not [string]::IsNullOrWhiteSpace($cursor)) {
        $item = $null
        try { $item = Get-Item -LiteralPath $cursor -Force -ErrorAction Stop }
        catch [System.Management.Automation.ItemNotFoundException] { }
        catch { throw "Cannot validate ancestor '$cursor': $($_.Exception.Message)" }
        if ($null -ne $item -and (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0)) {
            throw "Linked/reparse-point ancestor: $cursor"
        }
        $parent = [IO.Path]::GetDirectoryName($cursor)
        if ([string]::IsNullOrWhiteSpace($parent) -or $parent -eq $cursor) { break }
        $cursor = $parent
    }
}

function Assert-ExternalReviewPath {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ReviewPath,
        [Parameter(Mandatory)][string]$ProjectPath
    )
    $reviewFull = [IO.Path]::GetFullPath($ReviewPath)
    $projectFull = [IO.Path]::GetFullPath($ProjectPath)
    $reviewCmp = $reviewFull.TrimEnd([char[]]@('\', '/'))
    $projectCmp = $projectFull.TrimEnd([char[]]@('\', '/'))
    $rootCmp = [IO.Path]::GetPathRoot($reviewFull).TrimEnd([char[]]@('\', '/'))
    $comparison = [StringComparison]::OrdinalIgnoreCase
    if ($reviewCmp.Equals($rootCmp, $comparison)) {
        throw "ReviewPath must not be a filesystem root: $reviewFull"
    }
    if ($reviewCmp.Equals($projectCmp, $comparison) -or
        $reviewCmp.StartsWith($projectCmp + [IO.Path]::DirectorySeparatorChar, $comparison)) {
        throw "ReviewPath must be outside the Unity project: $reviewFull"
    }
    Assert-Act0UnlinkedAncestors $projectFull
    Assert-Act0UnlinkedAncestors $reviewFull
}

function Get-Act0SnapshotFiles {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$SourceDirectory,
        [scriptblock]$IncludeFile = { param($File) $true }
    )
    Assert-Act0UnlinkedAncestors $SourceDirectory
    foreach ($item in Get-ChildItem -LiteralPath $SourceDirectory -Force -ErrorAction Stop) {
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw "Snapshot contains a linked path: $($item.FullName)"
        }
        if ($item.PSIsContainer) {
            Get-Act0SnapshotFiles -SourceDirectory $item.FullName -IncludeFile $IncludeFile
        } elseif (& $IncludeFile $item) { $item }
    }
}

function Copy-VerifiedAct0Snapshot {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$SourceDirectory,
        [Parameter(Mandatory)][string]$SnapshotDirectory,
        [Parameter(Mandatory)][string]$ProjectPath,
        [scriptblock]$IncludeFile = { param($File) $true }
    )
    $source = [IO.Path]::GetFullPath($SourceDirectory).TrimEnd([char[]]@('\', '/'))
    $target = [IO.Path]::GetFullPath($SnapshotDirectory).TrimEnd([char[]]@('\', '/'))
    $project = [IO.Path]::GetFullPath($ProjectPath).TrimEnd([char[]]@('\', '/'))
    $comparison = [StringComparison]::OrdinalIgnoreCase
    if (-not ($source.Equals($project, $comparison) -or
        $source.StartsWith($project + [IO.Path]::DirectorySeparatorChar, $comparison))) {
        throw 'SourceDirectory must be inside the Unity project.'
    }
    Assert-ExternalReviewPath -ReviewPath $target -ProjectPath $ProjectPath
    Assert-Act0UnlinkedAncestors $source
    if (-not (Test-Path -LiteralPath $source -PathType Container)) {
        throw "Source snapshot directory not found: $source"
    }
    if (Test-Path -LiteralPath $target) {
        if (-not (Test-Path -LiteralPath $target -PathType Container) -or
            @(Get-ChildItem -LiteralPath $target -Force -ErrorAction Stop).Count -gt 0) {
            throw "Snapshot directory must be empty to avoid stale files: $target"
        }
    }
    $files = @(Get-Act0SnapshotFiles -SourceDirectory $source -IncludeFile $IncludeFile)
    $before = @{}
    foreach ($file in $files) {
        $relative = $file.FullName.Substring($source.Length + 1).Replace([IO.Path]::DirectorySeparatorChar, '/')
        if ($before.ContainsKey($relative)) { throw "Case-insensitive source path collision: $relative" }
        $before[$relative] = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256 -ErrorAction Stop).Hash
    }

    Assert-ExternalReviewPath -ReviewPath $target -ProjectPath $ProjectPath
    [void][IO.Directory]::CreateDirectory($target)
    Assert-ExternalReviewPath -ReviewPath $target -ProjectPath $ProjectPath
    foreach ($relative in @($before.Keys | Sort-Object)) {
        $sourceFile = Join-Path $source $relative
        $stagedFile = Join-Path $target $relative
        $stagedParent = [IO.Path]::GetDirectoryName($stagedFile)
        Assert-Act0UnlinkedAncestors $sourceFile
        Assert-ExternalReviewPath -ReviewPath $stagedParent -ProjectPath $ProjectPath
        [void][IO.Directory]::CreateDirectory($stagedParent)
        Assert-ExternalReviewPath -ReviewPath $stagedParent -ProjectPath $ProjectPath
        Assert-Act0UnlinkedAncestors $stagedFile
        [IO.File]::Copy($sourceFile, $stagedFile, $false)
        $stagedHash = (Get-FileHash -LiteralPath $stagedFile -Algorithm SHA256 -ErrorAction Stop).Hash
        $sourceAfter = (Get-FileHash -LiteralPath $sourceFile -Algorithm SHA256 -ErrorAction Stop).Hash
        if ($before[$relative] -ne $stagedHash -or $before[$relative] -ne $sourceAfter) {
            throw "Source changed during staging or copy did not match: $relative"
        }
    }

    # Build the manifest from staged bytes; recheck each source file and inventory.
    $stagedFiles = @(Get-Act0SnapshotFiles -SourceDirectory $target)
    if ($stagedFiles.Count -ne $before.Count) { throw 'Snapshot file-count mismatch.' }
    $manifest = @(
        foreach ($file in $stagedFiles) {
            $relative = $file.FullName.Substring($target.Length + 1).Replace([IO.Path]::DirectorySeparatorChar, '/')
            if (-not $before.ContainsKey($relative)) { throw "Unexpected staged file: $relative" }
            $hash = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256 -ErrorAction Stop).Hash
            if ($hash -ne $before[$relative]) { throw "Staged file changed after copy: $relative" }
            $sourceFile = Join-Path $source $relative
            Assert-Act0UnlinkedAncestors $sourceFile
            $sourceNow = (Get-FileHash -LiteralPath $sourceFile -Algorithm SHA256 -ErrorAction Stop).Hash
            if ($sourceNow -ne $before[$relative]) { throw "Source changed during final snapshot verification: $relative" }
            [pscustomobject]@{ RelativePath = $relative; SHA256 = $hash; Bytes = [long]$file.Length }
        }
    )
    $sourceNowFiles = @(Get-Act0SnapshotFiles -SourceDirectory $source -IncludeFile $IncludeFile)
    if ($sourceNowFiles.Count -ne $before.Count) { throw 'Source file inventory changed during staging.' }
    foreach ($file in $sourceNowFiles) {
        $relative = $file.FullName.Substring($source.Length + 1).Replace([IO.Path]::DirectorySeparatorChar, '/')
        if (-not $before.ContainsKey($relative)) { throw "Source file inventory changed during staging: $relative" }
    }
    Assert-ExternalReviewPath -ReviewPath $target -ProjectPath $ProjectPath
    return @($manifest | Sort-Object RelativePath)
}
