VELVET VENDETTA / ACT 0 TRANSFER AND MERGE HANDOFF

This archive contains the uncommitted cloud Unity implementation, not a merged
Windows project. Nothing in it imports assets or launches Unity automatically.
Do not extract it into a Unity Assets folder. Keep the staging directory outside
the Unity project so Unity does not compile the staged copies.

1. Extract this archive outside D:\Projects\Velvet_Vendetta\unity_base.
2. From the extracted directory, run:

   & .\Stage-Act0.ps1 -ProjectPath 'D:\Projects\Velvet_Vendetta\unity_base'

   This verifies payload hashes, stages incoming files, copies existing Unity
   source/scene/reference files for comparison, and writes comparison.json.
   It never writes to the Windows project or launches Unity. It fails on
   inaccessible files or linked paths instead of silently skipping them.
   Keep Stage-Act0-Hardening.ps1 beside Stage-Act0.ps1; the staging script loads
   it automatically before creating directories. Use a fresh ReviewPath each run.

3. Attach the generated review-*/windows-comparison.zip for source review.
   It includes comparison.json and the existing source snapshot, including
   input-action assets and text YAML configuration assets. Unsaved Editor scene
   changes are absent from the disk snapshot.
   Before any real merge, checkpoint/back up the complete Windows repository,
   including uncommitted/untracked content and player save data. The stage
   snapshot is a source comparison aid, not a full project backup.

4. Reconcile the bootstrap and existing gameplay systems. Review:
   - GameBootstrap.cs: base/, cloud/, and the Windows source snapshot give the
     three versions. Keep the existing Windows .meta GUID for existing assets.
   - Act0PrototypeBootstrap, Act0OpeningSequence and Act0FuneralDirector, plus
     old player, camera, interaction and UI components.
   - RuntimeInitializeOnLoadMethod hooks AND scene/prefab component references.
     Distinct class names do not prevent duplicate worlds, players or cameras.
   - Full type identities and local asmdef/asmref boundaries.
   - Incoming GUID collisions and same-path/different-GUID metadata.
   - World_OldKentahten / INT_FuneralHome / INT_PlayerHome scene-name collisions.
   - Active input backend, shaders/material inclusion and existing save format.

The cloud bootstrap unconditionally creates its own Act0Director on startup.
The director creates services, player, camera and UI. Do not enable both old and
new world startup paths. Importing cloud code alone is not a safe finished merge.

KNOWN INTEGRATION LIMITS

- Cloud Act0Director assigns its exterior field only when generating the fallback
  World_OldKentahten scene. Reusing an existing authored scene with that name
  needs adaptation before startup; otherwise that field can be null.
- Generated materials use Shader.Find. Check standalone shader inclusion and
  rendering in a real PC build.
- The new save envelope uses velvet-act0-v1.json in Application.persistentDataPath.
  Migration from the earlier prototype's save format is not implemented.
- Target Windows Editor version/path below were reported by the user; this cloud
  session could not independently query that installation.

VALIDATION AFTER THE MERGE

First use the already-open Editor to resolve compile errors and inspect the
scene. Given the reported low free RAM, avoid running a second Unity process.
The imported code exposes these menu items:
  Velvet Vendetta > Act 0 > Open Opening Scene
  Velvet Vendetta > Act 0 > Validate Opening
  Velvet Vendetta > Act 0 > Validate Additive Scenes and Walkable Path (Play Mode)

Once the correct checkout is integrated, the Editor is closed, and sufficient
memory is available, the exact PowerShell batch command is:

& 'D:\Unity\Editors\6000.3.25f1-x86_64\Editor\Unity.exe' `
  -batchmode `
  -projectPath 'D:\Projects\Velvet_Vendetta\unity_base' `
  -executeMethod VelvetVendetta.Editor.Act0PlayModeValidation.ValidateInPlayModeBatch `
  -logFile 'D:\Projects\Velvet_Vendetta\act0-validation.log'

Omit -quit; the asynchronous validator exits itself. It requires the included
Act0PlayModeValidation.cs and Assets/_VelvetVendetta/Scenes/00_Bootstrap.unity,
plus the rest of the integrated runtime code. It checks additive persistence,
entity identity, spawn clearance and walkable interaction approaches; it does
not replace the keyboard/controller funeral-to-free-roam playthrough.

CLOUD EVIDENCE (NOT WINDOWS EDITOR VALIDATION)

Runtime and editor C# compiled against Unity 2021 reference assemblies: 0 errors.
92 story, 35 world-memory, 99 editor-authored, 93 service and 16 identity checks
passed under .NET; relevant Unity lifecycle, JSON and storage calls used shims.
28 asset/folder GUIDs passed local uniqueness/reference checks. Unity 6 import,
actual controls/rendering/physics, and the Windows standalone build remain unrun.

HANDOFF VERIFICATION

The patch was applied to a scratch copy of the recorded cloud baseline and
reproduced all 50 payload hashes. Stage-Act0.ps1 passed 100 checks under PowerShell
7.4.6 on Linux fixtures, including preservation of existing files, GUID/type/scene
conflict detection, exact snapshot hashes, and rejection of corrupt payloads,
unsafe staging paths and linked directories. These are staging-tool checks;
the script has not been executed against the real Windows checkout.

The supplied Stage-Act0-Hardening.ps1 helper is integrated and adapted to retain
the source-only Assets filter. Existing path ancestors are checked before and
after directory creation, including source directories. Snapshot hashes come
from staged bytes and are compared with source hashes before, after and at the
end of copying. Re-enumeration catches changes to the selected file inventory.
Reports and scans use the verified copies. Source/snapshot checks run again
before publication; ZIP entry hashes are checked before the return ZIP is named
windows-comparison.zip. A failed run may leave .pending files; they are not a
completed handoff. These checks detect observed changes, not an atomic locked
snapshot. Unsaved Editor changes are absent.

The integrated helper also passed 55 focused assertions under PowerShell 7.4.6
on Linux, covering source/staged mutations, inventory changes, links introduced
during staging, and non-overwriting copies. The five Windows helper checks were
reported by the user for the standalone patch. The integrated script has not
been run on Windows; those checks do not establish Unity playability.

Eight full-script failure scenarios passed 48 additional assertions: late source
edits/additions/deletions, staged-file changes, pending-report changes, and ZIP
entry tampering were rejected without publishing final reports or a return ZIP.
Pending reports are rehashed immediately before publication as well.

This revision changes only Stage-Act0.ps1, Stage-Act0-Hardening.ps1 and README.txt.
All 50 Unity payload files remain byte-identical to the previous handoff.

CONTENTS

cloud/             Exact changed/new cloud Unity files, including .meta files.
base/              Original tracked GameBootstrap.cs for three-way review.
cloud-act0.patch   Reviewable git patch rooted at the repository (unity_base/...).
manifest.json      Paths, baseline revision, file sizes and SHA-256 hashes.
Stage-Act0.ps1     Read-only project inspection and external staging utility.
Stage-Act0-Hardening.ps1  External-path protection and verified snapshot helper.

The patch is not auto-applied. The separately modified Windows tree has to be
reviewed first. The stage script's type/reference scan is a review aid, not a C#
parser or a substitute for importing/compiling in Unity.
