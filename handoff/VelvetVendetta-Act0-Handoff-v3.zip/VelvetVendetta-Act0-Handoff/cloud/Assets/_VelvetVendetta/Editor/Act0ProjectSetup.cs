#if UNITY_EDITOR
using System;
using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace VelvetVendetta.Editor
{
    /// <summary>
    /// Local development helpers. The Windows build is a standalone Unity player;
    /// Xbox/GDK builds remain the responsibility of a licensed platform toolchain.
    /// No package, input, signing, or platform settings are changed by these menus.
    /// </summary>
    public static class Act0ProjectSetup
    {
        public const string OpeningScenePath = "Assets/_VelvetVendetta/Scenes/00_Bootstrap.unity";
        private const string MenuRoot = "Velvet Vendetta/Act 0/";

        [MenuItem(MenuRoot + "Open Opening Scene", false, 10)]
        public static void OpenOpeningScene()
        {
            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;

            if (File.Exists(OpeningScenePath))
            {
                EditorSceneManager.OpenScene(OpeningScenePath, OpenSceneMode.Single);
            }
            else
            {
                EnsureAssetFolder("Assets/_VelvetVendetta/Scenes");
                Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
                if (!EditorSceneManager.SaveScene(scene, OpeningScenePath))
                    throw new InvalidOperationException("Could not save the opening scene at " + OpeningScenePath);
                AssetDatabase.Refresh();
            }

            Debug.Log("[Velvet Vendetta] Opening scene ready. Press Play to begin Act 0. "
                + "The runtime bootstrap creates the world, camera, and player when Play starts.");
        }

        [MenuItem(MenuRoot + "Open Opening Scene", true)]
        private static bool CanOpenOpeningScene()
        {
            return !EditorApplication.isPlayingOrWillChangePlaymode && !EditorApplication.isCompiling;
        }

        [MenuItem(MenuRoot + "Build Windows Development Player", false, 30)]
        public static void BuildWindowsDevelopmentPlayer()
        {
            if (!File.Exists(OpeningScenePath))
            {
                EditorUtility.DisplayDialog("Opening scene missing",
                    "Use Velvet Vendetta > Act 0 > Open Opening Scene first, then build again.", "OK");
                return;
            }

            if (!BuildPipeline.IsBuildTargetSupported(BuildTargetGroup.Standalone, BuildTarget.StandaloneWindows64))
            {
                EditorUtility.DisplayDialog("Windows build support required",
                    "Install Windows Build Support for this Unity Editor version through Unity Hub. "
                    + "This command builds a Windows standalone development player; it does not create a GDK or Xbox package.", "OK");
                return;
            }

            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
            string outputDirectory = EditorUtility.SaveFolderPanel("Choose Windows development build folder", "", "VelvetVendetta-PC");
            if (string.IsNullOrEmpty(outputDirectory)) return;

            BuildPlayerOptions options = new BuildPlayerOptions
            {
                scenes = new[] { OpeningScenePath },
                locationPathName = Path.Combine(outputDirectory, "VelvetVendetta.exe"),
                target = BuildTarget.StandaloneWindows64,
                options = BuildOptions.Development | BuildOptions.AllowDebugging
            };

            BuildReport report = BuildPipeline.BuildPlayer(options);
            if (report.summary.result == BuildResult.Succeeded)
            {
                Debug.Log("[Velvet Vendetta] Windows standalone development build succeeded: "
                    + report.summary.outputPath + ". This is a local PC playtest build, not a GDK/Xbox package.");
                EditorUtility.RevealInFinder(report.summary.outputPath);
            }
            else
            {
                Debug.LogError("[Velvet Vendetta] Windows development build " + report.summary.result
                    + ". Review the Unity Console and build report for details.");
            }
        }

        [MenuItem(MenuRoot + "Build Windows Development Player", true)]
        private static bool CanBuildWindowsDevelopmentPlayer()
        {
            return !EditorApplication.isPlayingOrWillChangePlaymode && !EditorApplication.isCompiling;
        }

        private static void EnsureAssetFolder(string path)
        {
            string[] segments = path.Split('/');
            string current = segments[0];
            for (int index = 1; index < segments.Length; index++)
            {
                string next = current + "/" + segments[index];
                if (!AssetDatabase.IsValidFolder(next)) AssetDatabase.CreateFolder(current, segments[index]);
                current = next;
            }
        }
    }
}
#endif
