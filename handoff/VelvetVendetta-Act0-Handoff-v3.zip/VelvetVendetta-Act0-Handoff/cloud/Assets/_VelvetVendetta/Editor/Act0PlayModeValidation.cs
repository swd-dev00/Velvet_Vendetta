#if UNITY_EDITOR
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using VelvetVendetta.Act0;
using VelvetVendetta.Core;
using VelvetVendetta.Gameplay;

namespace VelvetVendetta.Editor
{
    /// <summary>Real Play Mode scene/physics smoke checks, without advancing or replacing a player save.</summary>
    [InitializeOnLoad]
    public static class Act0PlayModeValidation
    {
        private const string BatchKey = "VelvetVendetta.Act0.PlayModeValidation";
        private static bool running;

        static Act0PlayModeValidation() { EditorApplication.update += MonitorBatch; }

        [MenuItem("Velvet Vendetta/Act 0/Validate Additive Scenes and Walkable Path", false, 21)]
        public static void ValidateLive()
        {
            Act0Director director = UnityEngine.Object.FindObjectOfType<Act0Director>();
            if (!EditorApplication.isPlaying || director == null || director.Player == null)
                throw new InvalidOperationException("Enter Play Mode and wait for the opening menu before running this check.");
            if (!running) director.StartCoroutine(Run(director, null));
        }

        [MenuItem("Velvet Vendetta/Act 0/Validate Additive Scenes and Walkable Path", true)]
        private static bool CanValidateLive() { return EditorApplication.isPlaying && !running; }

        // Do not pass -quit: this entry exits after its asynchronous Play Mode checks finish.
        public static void ValidateInPlayModeBatch()
        {
            if (!Application.isBatchMode)
                throw new InvalidOperationException("Use the Play Mode menu for interactive validation.");
            if (!File.Exists(Act0ProjectSetup.OpeningScenePath))
                throw new InvalidOperationException("Create 00_Bootstrap with Act 0 > Open Opening Scene first.");
            SessionState.SetString(BatchKey, "waiting");
            SessionState.SetFloat(BatchKey + ".started", (float)EditorApplication.timeSinceStartup);
            EditorSceneManager.OpenScene(Act0ProjectSetup.OpeningScenePath, OpenSceneMode.Single);
            EditorApplication.isPlaying = true;
        }

        private static void MonitorBatch()
        {
            string state = SessionState.GetString(BatchKey, "");
            if (string.IsNullOrEmpty(state)) return;
            if (EditorApplication.timeSinceStartup - SessionState.GetFloat(BatchKey + ".started", 0) > 120)
            {
                SessionState.EraseString(BatchKey);
                Debug.LogError("[Velvet Vendetta] Play Mode smoke validation timed out.");
                EditorApplication.Exit(1);
                return;
            }
            if (state == "exiting" && !EditorApplication.isPlayingOrWillChangePlaymode)
            {
                int exitCode = SessionState.GetInt(BatchKey + ".result", 1);
                SessionState.EraseString(BatchKey);
                EditorApplication.Exit(exitCode);
                return;
            }
            if (state != "waiting" || !EditorApplication.isPlaying) return;
            Act0Director director = UnityEngine.Object.FindObjectOfType<Act0Director>();
            if (director == null || director.Player == null || director.Mode == Act0Mode.Loading) return;
            SessionState.SetString(BatchKey, "running");
            director.StartCoroutine(Run(director, passed =>
            {
                SessionState.SetInt(BatchKey + ".result", passed ? 0 : 1);
                SessionState.SetString(BatchKey, "exiting");
                EditorApplication.isPlaying = false;
            }));
        }

        private sealed class Snapshot
        {
            public Act0Director Director;
            public GameServices Services;
            public WorldManager Worlds;
            public ThirdPersonPlayer Player;
            public Act0Story Story;
            public WorldState World;
            public SocialMemory Memory;
            public string History;
            public Vector3 Position;
            public Quaternion Rotation;
            public Scene PlayerScene;
            public HashSet<string> Cells;
            public int Checks;
            public readonly List<string> Errors = new List<string>();

            public void Check(bool condition, string message)
            {
                if (!condition) throw new InvalidOperationException(message);
                Checks++;
            }
            public string Serialize()
            {
                return JsonUtility.ToJson(new GameSave { act0 = Services.Story.State,
                    world = Services.World, memory = Services.Memory });
            }
            public void CheckPersistentState()
            {
                Check(Player == Director.Player && ReferenceEquals(Story, Services.Story)
                    && ReferenceEquals(World, Services.World) && ReferenceEquals(Memory, Services.Memory),
                    "An additive operation replaced a persistent player or state service.");
                Check(Player.gameObject.scene == PlayerScene && Player.transform.position == Position
                    && Player.transform.rotation == Rotation, "An additive operation moved the persistent player.");
                Check(History == Serialize(), "An additive operation changed saved narrative/world/social history.");
                EntityIdentity identity;
                Check(EntityIdentity.TryGet("player.local", out identity)
                    && identity.gameObject == Player.gameObject, "The persistent player identity was lost.");
            }
        }

        private static IEnumerator Run(Act0Director director, Action<bool> completed)
        {
            running = true;
            bool wasEnabled = director.enabled;
            Act0Hud hud = UnityEngine.Object.FindObjectOfType<Act0Hud>();
            bool hudEnabled = hud != null && hud.enabled;
            // Disabling a MonoBehaviour leaves its coroutines running. No pause/menu/save action is invoked.
            director.enabled = false;
            if (hud != null) hud.enabled = false;
            var snapshot = new Snapshot { Director = director, Services = director.Services,
                Worlds = director.Services.WorldManager, Player = director.Player,
                Story = director.Services.Story, World = director.Services.World, Memory = director.Services.Memory,
                Position = director.Player.transform.position, Rotation = director.Player.transform.rotation,
                PlayerScene = director.Player.gameObject.scene };
            snapshot.History = snapshot.Serialize();
            Application.LogCallback log = (message, stack, type) =>
            {
                if (type == LogType.Error || type == LogType.Exception || type == LogType.Assert)
                    snapshot.Errors.Add(message);
            };
            Application.logMessageReceived += log;
            Exception failure = null;
            try
            {
                while (snapshot.Worlds.IsBusy) yield return null;
                snapshot.Cells = new HashSet<string>(snapshot.Worlds.LoadedIds);
                yield return Guard(Checks(snapshot), error => failure = error);
                yield return Guard(RestoreCells(snapshot), error =>
                {
                    if (failure == null) failure = error;
                });
                // Include deferred destruction/material cleanup from the final scene unload.
                yield return null;
                try
                {
                    snapshot.CheckPersistentState();
                    snapshot.Check(snapshot.Errors.Count == 0, "Unity logged errors during the smoke check: "
                        + string.Join("; ", snapshot.Errors.ToArray()));
                }
                catch (Exception error) { if (failure == null) failure = error; }
            }
            finally
            {
                Application.logMessageReceived -= log;
                if (director != null) director.enabled = wasEnabled;
                if (hud != null) hud.enabled = hudEnabled;
                running = false;
            }
            if (failure == null)
                Debug.Log("[Velvet Vendetta] Play Mode smoke validation passed: " + snapshot.Checks
                    + " checks. Additive reload preserved player/history, loaded IDs are unique, and Act 0 "
                    + "interaction approaches connect through walkable greybox geometry. No console errors "
                    + "occurred during these checks. This does not certify a full input, camera, or dialogue playthrough.");
            else Debug.LogError("[Velvet Vendetta] Play Mode smoke validation failed: " + failure.Message);
            if (completed != null) completed(failure == null);
        }

        private static IEnumerator Checks(Snapshot snapshot)
        {
            WorldManager worlds = snapshot.Worlds;
            snapshot.Check(worlds.IsLoaded(WorldManager.OldKentahten), "The exterior did not bootstrap.");
            Coroutine first = worlds.StartCoroutine(worlds.LoadCell(WorldManager.PlayerHome));
            yield return worlds.LoadCell(WorldManager.PlayerHome);
            yield return first;
            snapshot.Check(worlds.IsLoaded(WorldManager.PlayerHome), worlds.LastError ?? "Player home did not load.");
            int matchingScenes = 0;
            for (int i = 0; i < SceneManager.sceneCount; i++)
                if (SceneManager.GetSceneAt(i).name == WorldManager.PlayerHome) matchingScenes++;
            snapshot.Check(matchingScenes == 1, "Concurrent requests created duplicate home scenes.");
            snapshot.CheckPersistentState();
            yield return worlds.UnloadCell(WorldManager.PlayerHome);
            snapshot.Check(!worlds.IsLoaded(WorldManager.PlayerHome), worlds.LastError ?? "Player home did not unload.");
            snapshot.CheckPersistentState();
            yield return worlds.LoadCell(WorldManager.PlayerHome);
            snapshot.Check(worlds.IsLoaded(WorldManager.PlayerHome), worlds.LastError ?? "Player home did not reload.");
            yield return worlds.LoadCell(WorldManager.FuneralHome);
            snapshot.Check(worlds.IsLoaded(WorldManager.FuneralHome), worlds.LastError ?? "Funeral interior did not load.");
            Physics.SyncTransforms();
            List<string> identityErrors = EntityIdentity.ValidateLoaded();
            snapshot.Check(identityErrors.Count == 0, string.Join("; ", identityErrors.ToArray()));
            snapshot.CheckPersistentState();
            yield return ValidateWalkableApproaches(snapshot);
        }

        private static IEnumerator RestoreCells(Snapshot snapshot)
        {
            foreach (string id in new List<string>(snapshot.Worlds.LoadedIds))
                if (!snapshot.Cells.Contains(id)) yield return snapshot.Worlds.UnloadCell(id);
            foreach (string id in snapshot.Cells)
                if (!snapshot.Worlds.IsLoaded(id)) yield return snapshot.Worlds.LoadCell(id);
            snapshot.Check(new HashSet<string>(snapshot.Worlds.LoadedIds).SetEquals(snapshot.Cells),
                "The smoke test could not restore the initial set of loaded cells.");
        }

        // Flatten nested enumerators so a failing assertion still restores scenes and input.
        private static IEnumerator Guard(IEnumerator routine, Action<Exception> failed)
        {
            var stack = new Stack<IEnumerator>();
            stack.Push(routine);
            try
            {
                while (stack.Count > 0)
                {
                    object current = null;
                    bool moved = false;
                    Exception failure = null;
                    try { moved = stack.Peek().MoveNext(); if (moved) current = stack.Peek().Current; }
                    catch (Exception error) { failure = error; }
                    if (failure != null) { failed(failure); yield break; }
                    if (!moved)
                    {
                        IDisposable disposable = stack.Pop() as IDisposable;
                        if (disposable != null) disposable.Dispose();
                    }
                    else if (current is IEnumerator) stack.Push((IEnumerator)current);
                    else yield return current;
                }
            }
            finally
            {
                while (stack.Count > 0)
                {
                    IDisposable disposable = stack.Pop() as IDisposable;
                    if (disposable != null) disposable.Dispose();
                }
            }
        }

        private static IEnumerator ValidateWalkableApproaches(Snapshot snapshot)
        {
            var pending = new List<Act0Point>();
            foreach (Act0World world in UnityEngine.Object.FindObjectsOfType<Act0World>())
                foreach (Act0Point point in world.Points) pending.Add(point);
            snapshot.Check(pending.Count >= 13, "Required greybox interaction endpoints are missing.");
            var grid = new WalkGrid(snapshot.Player.transform);
            snapshot.Check(grid.CanStand(Act0World.FuneralSpawn), "The funeral arrival position overlaps solid geometry.");
            snapshot.Check(grid.CanStand(Act0World.HomeSpawn), "The home arrival position overlaps solid geometry.");
            var queue = new Queue<Vector2Int>();
            var visited = new HashSet<Vector2Int>();
            Vector2Int start = grid.Coordinate(Act0World.FuneralSpawn);
            queue.Enqueue(start);
            visited.Add(start);
            Vector2Int[] directions = { Vector2Int.up, Vector2Int.down, Vector2Int.left, Vector2Int.right };
            int processed = 0;
            while (queue.Count > 0 && pending.Count > 0)
            {
                Vector2Int at = queue.Dequeue();
                Vector3 position = grid.Position(at);
                if (!grid.CanStand(position)) continue;
                for (int i = pending.Count - 1; i >= 0; i--)
                {
                    Act0Point point = pending[i];
                    if (Vector3.Distance(position, point.Position) <= Mathf.Min(1.5f, point.Radius * .8f)
                        && grid.CanSee(position + Vector3.up * 1.2f, point.Position + Vector3.up * 1.2f))
                    {
                        snapshot.Check(true, point.Label);
                        pending.RemoveAt(i);
                    }
                }
                foreach (Vector2Int direction in directions)
                {
                    Vector2Int next = at + direction;
                    if (next.x >= 4 && next.x <= 252 && next.y >= 4 && next.y <= 204 && visited.Add(next))
                        queue.Enqueue(next);
                }
                if (++processed % 512 == 0) yield return null;
            }
            var missing = new List<string>();
            foreach (Act0Point point in pending) missing.Add(point.Label);
            snapshot.Check(pending.Count == 0, "No unobstructed walking/interaction approach from arrival: "
                + string.Join(", ", missing.ToArray()));
        }

        private sealed class WalkGrid
        {
            private readonly Transform player;
            private readonly Collider[] overlaps = new Collider[32];
            private readonly RaycastHit[] sightHits = new RaycastHit[32];
            public WalkGrid(Transform playerTransform) { player = playerTransform; }
            public Vector2Int Coordinate(Vector3 point) { return new Vector2Int(Mathf.RoundToInt(point.x * 2), Mathf.RoundToInt(point.z * 2)); }
            public Vector3 Position(Vector2Int at) { return new Vector3(at.x * .5f, 0, at.y * .5f); }
            public bool CanStand(Vector3 position)
            {
                int count = Physics.OverlapCapsuleNonAlloc(position + Vector3.up * .38f,
                    position + Vector3.up * 1.48f, .32f, overlaps, ~0, QueryTriggerInteraction.Ignore);
                if (count == overlaps.Length) return false;
                for (int i = 0; i < count; i++)
                    if (!overlaps[i].transform.IsChildOf(player)) return false;
                return Physics.Raycast(position + Vector3.up * .05f, Vector3.down, .3f, ~0, QueryTriggerInteraction.Ignore);
            }
            public bool CanSee(Vector3 from, Vector3 to)
            {
                Vector3 delta = to - from;
                int count = Physics.RaycastNonAlloc(from, delta.normalized, sightHits, delta.magnitude,
                    ~0, QueryTriggerInteraction.Ignore);
                if (count == sightHits.Length) return false;
                for (int i = 0; i < count; i++)
                    if (!sightHits[i].transform.IsChildOf(player)) return false;
                return true;
            }
        }
    }
}
#endif
