#if UNITY_EDITOR
using System;
using System.IO;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;
using VelvetVendetta.Act0;
using VelvetVendetta.Core;

namespace VelvetVendetta.Editor
{
    /// <summary>
    /// Run from the editor menu or with -executeMethod
    /// VelvetVendetta.Editor.Act0Validation.ValidateOpening.
    /// These checks do not touch the player's save or edit project settings.
    /// They test narrative rules and Unity JSON serialization, not rendering,
    /// collisions, controller hardware, or platform certification.
    /// </summary>
    public static class Act0Validation
    {
        [MenuItem("Velvet Vendetta/Act 0/Validate Opening", false, 20)]
        public static void ValidateOpening()
        {
            if (!File.Exists(Act0ProjectSetup.OpeningScenePath))
                throw new InvalidOperationException("[Velvet Vendetta] Opening scene is missing. "
                    + "Use Act 0 > Open Opening Scene to create it.");

            Scene activeScene = SceneManager.GetActiveScene();
            if (activeScene.path != Act0ProjectSetup.OpeningScenePath)
                Debug.LogWarning("[Velvet Vendetta] The opening scene exists but is not active. "
                    + "Use Act 0 > Open Opening Scene before the Play Mode smoke test.");

            List<string> identityErrors = EntityIdentity.ValidateLoaded();
            if (identityErrors.Count != 0)
                throw new InvalidOperationException("[Velvet Vendetta] Entity identity validation failed:\n"
                    + string.Join("\n", identityErrors.ToArray()));

            int passed = RunStoryChecks() + RunFoundationChecks() + RunNarrativeChecks();
            if (EditorApplication.isPlaying) passed += ValidateRuntimeServices();
            Debug.Log("[Velvet Vendetta] Act 0 validation passed: " + passed
                + " checks; " + EntityIdentity.SnapshotLoaded().Count + " loaded entity IDs inspected. "
                + "Optional discoveries can be skipped, time advances, departure works on foot, "
                + "narrative references are valid, and typed world/social/story state survives JSON round-trip. "
                + (EditorApplication.isPlaying ? "Live service registrations and scene catalog passed. "
                    : "Run this command again in Play Mode to check live service registrations. ")
                + "Rendering, collisions, controller hardware, and platform builds require their own playtests.");
        }

        [MenuItem("Velvet Vendetta/Act 0/Validate Opening", true)]
        private static bool CanValidateOpening()
        {
            return !EditorApplication.isCompiling;
        }

        private static int ValidateRuntimeServices()
        {
            GameServices services = GameServices.Instance;
            if (services == null || services.World == null || services.Memory == null || services.Story == null
                || services.WorldManager == null || services.Observations == null)
                throw new InvalidOperationException("[Velvet Vendetta] Required runtime services have not been registered. "
                    + "Wait for the opening bootstrap to finish, then validate again.");
            int checkedServices = 6;
            var ids = new HashSet<string>(StringComparer.Ordinal);
            foreach (WorldCellDefinition cell in services.WorldManager.Catalog)
            {
                if (cell == null || string.IsNullOrWhiteSpace(cell.Id) || string.IsNullOrWhiteSpace(cell.SceneName)
                    || !ids.Add(cell.Id))
                    throw new InvalidOperationException("[Velvet Vendetta] Invalid or duplicate world cell definition.");
                if (cell.StreamByProximity && (cell.Minimum.x > cell.Maximum.x || cell.Minimum.y > cell.Maximum.y
                    || cell.LoadMargin < 0 || cell.UnloadMargin < cell.LoadMargin))
                    throw new InvalidOperationException("[Velvet Vendetta] Invalid streaming bounds on " + cell.Id);
                checkedServices++;
            }
            if (!ids.Contains(WorldManager.OldKentahten) || !ids.Contains(WorldManager.FuneralHome)
                || !ids.Contains(WorldManager.PlayerHome))
                throw new InvalidOperationException("[Velvet Vendetta] A required opening world/interior cell is not registered.");
            return checkedServices + 1;
        }

        public static int RunNarrativeChecks()
        {
            int passed = 0;
            Action<bool, string> check = (condition, description) =>
            {
                if (!condition) throw new InvalidOperationException("[Narrative validation] " + description);
                passed++;
            };
            check(Act0Sequence.Validate().Count == 0, "Authored opportunities contain invalid references or prerequisites.");
            check(Act0Sequence.Validate(new[] { new NarrativeOpportunity { id = "unknown-target", target = (Act0Target)999 } }).Count > 0,
                "Unknown target IDs were accepted.");
            check(Act0Sequence.Validate(new[] { new NarrativeOpportunity { id = "unknown-fact", prerequisites = new[] { "fact:Missing" } } }).Count > 0,
                "Unknown fact prerequisites were accepted.");
            check(Act0Sequence.Validate(new[] { new NarrativeOpportunity { id = "unknown-node", prerequisites = new[] { "node:Missing" } } }).Count > 0,
                "Unknown node prerequisites were accepted.");
            check(Act0Sequence.Validate(new[] {
                new NarrativeOpportunity { id = "optional-card", optional = true },
                new NarrativeOpportunity { id = "release", prerequisites = new[] { "node:optional-card" } }
            }).Count > 0, "A required stage could depend on an optional discovery.");
            check(Act0Sequence.Validate(new[] { new NarrativeOpportunity { id = "bad-window", startsAt = 50, endsAt = 10 } }).Count > 0,
                "An impossible opportunity time window was accepted.");
            check(Act0Sequence.Validate(new[] { new NarrativeOpportunity { id = "bad-event", onMissedEvent = "unknown" } }).Count > 0,
                "An unknown missed-event reference was accepted.");
            return passed;
        }

        public static int RunStoryChecks()
        {
            int passed = 0;
            Action<bool, string> check = (condition, description) =>
            {
                if (!condition) throw new InvalidOperationException("[Act 0 validation] " + description);
                passed++;
            };
            Action<Act0Story> roundTrip = source =>
            {
                string json = JsonUtility.ToJson(source.State);
                Act0State loaded = JsonUtility.FromJson<Act0State>(json);
                check(Act0Story.IsValidState(loaded), "A partial or completed story failed save validation.");
                check(JsonUtility.ToJson(new Act0Story(loaded).State) == json,
                    "Unity JSON round-trip changed narrative state, choices, or position.");
            };
            Act0Story story = new Act0Story();
            check(!story.Choose(Act0Target.Maya, "embrace"), "An unstarted game accepted a choice.");
            story.Start("  Morgan  ", "funeral");
            check(story.State.started && story.State.name == "Morgan" && story.State.origin == "funeral"
                && story.State.gameTime == 0, "Funeral start lost its name, origin, or arrival time.");
            story.Start("Overwrite", "home");
            check(story.State.name == "Morgan", "Starting an active story replaced progress without a reset.");
            string before = JsonUtility.ToJson(story.State);
            check(story.Interact(Act0Target.Maya) != null, "Maya's arrival conversation is missing.");
            check(JsonUtility.ToJson(story.State) == before, "Reading available dialogue changed persistent history.");
            check(!story.Choose(Act0Target.Card, "keep"), "The optional card could be collected before the burial.");
            story.ReachLocation(Act0Target.Departure);
            check(!story.State.completed, "The departure route completed the act before the funeral schedule.");
            story.ReachLocation(Act0Target.Entrance);
            check(story.State.enteredFuneral && story.State.phase == Act0Phase.Viewing,
                "Entering the funeral home required an optional parking-lot conversation.");
            roundTrip(story);
            check(story.Choose(Act0Target.SUV, "inspect") && story.State.clues.Contains("black-suv"),
                "Intentional SUV inspection did not record the observation.");
            check(story.Choose(Act0Target.Casket, "notice") && story.State.clues.Contains("missing-watch")
                && story.State.phase == Act0Phase.Viewing, "Viewing the deceased did not preserve its optional clue.");
            check(story.Choose(Act0Target.Maya, "embrace") && story.State.mayaTrust == 2,
                "The personal conversation failed to record its response.");
            check(story.Choose(Act0Target.Darius, "ask-history") && story.Choose(Act0Target.Mourner, "ask-wednesday"),
                "The business associate or unknown mourner conversation is unavailable.");
            check(story.Choose(Act0Target.Service, "last-conversation") && story.State.phase == Act0Phase.Wake
                && story.State.gameTime >= 240 && story.State.Choice("service") == "last-conversation",
                "The Wednesday eulogy option did not record a response and reach the gathering.");
            check(!story.Choose(Act0Target.Service, "last-conversation"), "A finished eulogy could be repeated.");
            check(!story.Choose(Act0Target.Ruth, "confront"), "Ruth's receipt confrontation unlocked before finding evidence.");
            check(story.Choose(Act0Target.Office, "watch") && story.Choose(Act0Target.Office, "ledger")
                && story.State.phase == Act0Phase.Wake, "Optional office evidence blocked or advanced required flow.");
            check(!story.Choose(Act0Target.Office, "watch") && !story.Choose(Act0Target.Office, "ledger"),
                "An optional office observation could be recorded twice.");
            check(story.Choose(Act0Target.Ruth, "confront") && story.State.ruthTrust == -2
                && story.State.clues.Contains("county-collector"), "Ruth's confrontation lost its consequences.");
            roundTrip(story);
            story.ReachLocation(Act0Target.Grave);
            check(story.State.burialAttended && story.State.phase >= Act0Phase.Burial,
                "Reaching the burial gathering did not record attendance.");
            check(story.Choose(Act0Target.Grave, "promise") && story.State.phase == Act0Phase.Departure,
                "The optional graveside farewell did not leave the departure route available.");
            check(story.Choose(Act0Target.Card, "share") && story.State.clues.Contains("black-card")
                && story.State.Choice("card") == "share", "The optional black-card choice was not recorded.");
            check(story.State.mayaTrust == 5, "Sharing the card lost its relationship consequence.");
            roundTrip(story);
            story.Move(85f, 0f, 74f, false);
            story.ReachLocation(Act0Target.Departure);
            check(story.State.completed && story.State.phase == Act0Phase.FreeRoam && !story.State.driving,
                "Physical departure on foot did not complete Act 0.");
            before = JsonUtility.ToJson(story.State);
            story.Depart();
            check(before == JsonUtility.ToJson(story.State), "Crossing the departure route twice duplicated completion.");
            check(story.Choose(Act0Target.Garage, "introduce") && story.Choose(Act0Target.Velvet, "note"),
                "Post-prologue exploration interactions are unavailable.");
            story.Move(90f, 0f, 75f, false);
            check(story.State.completed && story.State.playerX == 90f, "The player could not move after completion.");
            roundTrip(story);
            before = JsonUtility.ToJson(story.State);
            story.Move(float.NaN, 0, 0, false);
            check(before == JsonUtility.ToJson(story.State), "Invalid coordinates corrupted the save.");

            Act0Story optionalSkip = new Act0Story();
            optionalSkip.Start("Sam", "funeral");
            optionalSkip.ReachLocation(Act0Target.Entrance);
            optionalSkip.Tick(120);
            check(optionalSkip.State.phase == Act0Phase.Service, "The service waited for an optional conversation.");
            optionalSkip.Tick(120);
            check(optionalSkip.State.phase == Act0Phase.Wake && !optionalSkip.Choose(Act0Target.Service, "family"),
                "A missed eulogy remained available after its time window.");
            optionalSkip.ReachLocation(Act0Target.Grave);
            optionalSkip.Move(86f, 0, 75f, false);
            optionalSkip.ReachLocation(Act0Target.Departure);
            check(optionalSkip.State.completed && optionalSkip.State.burialAttended
                && optionalSkip.State.clues.Count == 0 && optionalSkip.State.Choice("service") == null
                && optionalSkip.State.Choice("maya") == null && optionalSkip.State.Choice("ruth") == null
                && optionalSkip.State.Choice("card") == null,
                "Skipping optional NPCs, SUV, watch, office, eulogy, or card blocked departure.");
            roundTrip(optionalSkip);

            Act0Story home = new Act0Story();
            home.Start("Jordan", "home");
            check(home.State.gameTime == 180 && home.State.phase == Act0Phase.Service
                && !home.State.enteredFuneral && home.State.playerZ > 60f,
                "The home start did not account for a late arrival.");
            home.Tick(60);
            home.ReachLocation(Act0Target.Entrance);
            check(home.State.phase == Act0Phase.Wake && home.State.enteredFuneral,
                "Arriving late rewound the funeral schedule.");
            home.Tick(120);
            check(home.State.phase == Act0Phase.Burial, "The burial waited for mandatory NPC interactions.");
            roundTrip(home);
            home.ReachLocation(Act0Target.Grave);
            home.ReachLocation(Act0Target.Departure);
            check(home.State.completed && !home.State.clues.Contains("black-card"),
                "The home-start route required an optional card or vehicle.");
            double time = home.State.gameTime;
            home.Tick(-10); home.Tick(float.NaN);
            check(home.State.gameTime == time, "Invalid clock deltas changed narrative time.");

            foreach (Act0Phase phase in Enum.GetValues(typeof(Act0Phase)))
            {
                check(Enum.IsDefined(typeof(Act0Target), Act0Story.ObjectiveTarget(phase)),
                    "A narrative phase references an unknown objective entity.");
                check(!string.IsNullOrWhiteSpace(Act0Story.Objective(phase))
                    && !string.IsNullOrWhiteSpace(Act0Story.PhaseTitle(phase)),
                    "A narrative phase has no usable objective or title.");
            }
            check(!Act0Story.IsValidState(new Act0State { version = 99 }), "An unsupported save version was accepted.");
            check(!Act0Story.IsValidState(new Act0State { playerX = float.PositiveInfinity }),
                "A non-finite saved player position was accepted.");
            check(!Act0Story.IsValidState(new Act0State { gameTime = double.NaN }),
                "An invalid saved narrative time was accepted.");
            check(!Act0Story.IsValidState(new Act0State { clues = null }), "Missing save collections were accepted.");
            check(!Act0Story.IsValidState(new Act0State { phase = (Act0Phase)99 }),
                "A save with an unknown narrative stage was accepted.");
            check(!Act0Story.IsValidState(new Act0State { completed = true }),
                "An arrival save could incorrectly mark Act 0 complete.");
            story.Reset(); story.Start("Alex", "funeral");
            check(!story.State.completed && story.State.phase == Act0Phase.Arrival && story.State.clues.Count == 0,
                "Beginning a new story retained the previous completed history.");
            return passed;
        }

        [Serializable]
        private sealed class FoundationSnapshot
        {
            public WorldState world = new WorldState();
            public SocialMemory memory = new SocialMemory();
        }

        public static int RunFoundationChecks()
        {
            int passed = 0;
            Action<bool, string> check = (condition, description) =>
            {
                if (!condition) throw new InvalidOperationException("[Foundation validation] " + description);
                passed++;
            };
            var snapshot = new FoundationSnapshot();
            snapshot.world.SetBool("Funeral.Arrived", true);
            snapshot.world.SetInt("Validation.Count", 2);
            snapshot.world.SetFloat("Validation.Distance", 12.5f);
            snapshot.world.SetString("Validation.Location", "OldKentahten");
            snapshot.world.SetTimestamp("Funeral.ArrivalTime", 181.25);
            snapshot.world.SetEntityId("Validation.Associate", "npc.darius");
            snapshot.memory.RecordClaim("npc.darius", "npc.elias", "YearsKnown", WorldFact.Int("YearsKnown", 2), 182);
            snapshot.memory.RecordClaim("npc.ruth", "npc.elias", "YearsKnown", WorldFact.Int("YearsKnown", 15), 185);
            var observation = snapshot.memory.RecordObservation("player", "vehicle.black-suv", "Funeral.BlackSUVObserved",
                186, "Funeral parking lot", .85f);
            snapshot.memory.RecordKnowledge("npc.ruth", "vehicle.black-suv", "Funeral.BlackSUVObserved",
                WorldFact.Bool("Funeral.BlackSUVObserved", true), 187, MemorySourceType.Hearsay,
                TruthStatus.Unknown, .6f, observation.id);
            check(snapshot.memory.claims.Count == 2 && snapshot.memory.claims[0].value.intValue == 2
                && snapshot.memory.claims[1].value.intValue == 15,
                "Contradictory claims overwrote one another.");
            check(!snapshot.world.Has("YearsKnown") && !snapshot.world.Has("Funeral.BlackSUVObserved"),
                "Social history changed objective truth without a world-state update.");
            check(snapshot.memory.knowledge[0].sourceType == MemorySourceType.Hearsay
                && snapshot.memory.knowledge[0].truth == TruthStatus.Unknown
                && snapshot.memory.knowledge[0].sourceRecordId == observation.id,
                "Knowledge did not preserve provenance and uncertainty.");
            WorldFact copy = snapshot.world.Get("Validation.Count");
            copy.intValue = 99;
            check(snapshot.world.GetInt("Validation.Count") == 2, "Editing a returned fact mutated the stored world state.");
            bool wrongTypeRejected = false;
            try { snapshot.world.SetString("Validation.Count", "two"); }
            catch (InvalidOperationException) { wrongTypeRejected = true; }
            check(wrongTypeRejected, "A world fact changed its declared type.");

            FoundationSnapshot restored = JsonUtility.FromJson<FoundationSnapshot>(JsonUtility.ToJson(snapshot));
            check(restored != null && restored.world != null && restored.memory != null,
                "The world/social-memory serialization envelope did not reload.");
            check(restored.world.GetBool("Funeral.Arrived") && restored.world.GetInt("Validation.Count") == 2
                && restored.world.GetFloat("Validation.Distance") == 12.5f
                && restored.world.GetString("Validation.Location") == "OldKentahten"
                && restored.world.GetTimestamp("Funeral.ArrivalTime") == 181.25
                && restored.world.GetEntityId("Validation.Associate") == "npc.darius",
                "World-state JSON round-trip lost typed facts.");
            check(restored.memory.claims.Count == 2 && restored.memory.claims[0].speakerId == "npc.darius"
                && restored.memory.claims[0].value.intValue == 2 && restored.memory.claims[1].value.intValue == 15
                && restored.memory.claims[0].id != restored.memory.claims[1].id,
                "Social-memory JSON round-trip lost distinct conflicting statements.");
            check(restored.memory.observations.Count == 1 && restored.memory.observations[0].observerId == "player"
                && restored.memory.observations[0].subjectId == "vehicle.black-suv"
                && restored.memory.observations[0].context == "Funeral parking lot"
                && restored.memory.observations[0].confidence == .85f,
                "Observation JSON round-trip lost observer, subject, context, or confidence.");
            check(restored.memory.knowledge.Count == 1 && restored.memory.knowledge[0].sourceRecordId == observation.id
                && restored.memory.knowledge[0].sourceType == MemorySourceType.Hearsay,
                "Knowledge JSON round-trip lost its source.");
            Act0Story story = new Act0Story();
            story.Start("Snapshot", "home");
            story.Move(24, 0, 70, false);
            GameSave gameSave = new GameSave { act0 = story.State, world = snapshot.world, memory = snapshot.memory };
            GameSave loadedSave = SaveManager.Deserialize(JsonUtility.ToJson(gameSave));
            check(loadedSave != null && loadedSave.act0.playerX == 24 && loadedSave.act0.gameTime == 180
                && loadedSave.world.GetBool("Funeral.Arrived") && loadedSave.memory.claims.Count == 2,
                "The real save-envelope deserializer lost partial Act 0 or world/social history.");
            gameSave.version = 999;
            check(SaveManager.Deserialize(JsonUtility.ToJson(gameSave)) == null,
                "The save boundary accepted an unsupported envelope version.");
            gameSave.version = 1;
            string validEnvelope = JsonUtility.ToJson(gameSave);
            foreach (string key in new[] { "Act0.Completed", "Funeral.Arrived", "Funeral.ArrivalTime",
                "Act0.TitleShown", "Narrative.Missed.funeral-service", "Narrative.MissedAt.funeral-service" })
            {
                GameSave malformed = JsonUtility.FromJson<GameSave>(validEnvelope);
                malformed.world.facts.RemoveAll(fact => fact.key == key);
                malformed.world.facts.Add(WorldFact.String(key, "wrong type"));
                check(SaveManager.Deserialize(JsonUtility.ToJson(malformed)) == null,
                    "The save boundary accepted a wrong runtime fact type for " + key + ".");
            }
            GameSave invalidEvent = JsonUtility.FromJson<GameSave>(validEnvelope);
            invalidEvent.world.SetBool("Narrative.MissedEvent.funeral-service", true);
            check(SaveManager.Deserialize(JsonUtility.ToJson(invalidEvent)) == null,
                "The save boundary accepted a non-string missed-event reference.");
            GameSave invalidConfidence = JsonUtility.FromJson<GameSave>(validEnvelope);
            invalidConfidence.memory.claims[0].confidence = 2;
            check(SaveManager.Deserialize(JsonUtility.ToJson(invalidConfidence)) == null,
                "The save boundary accepted a social claim with out-of-range confidence.");
            GameSave duplicateId = JsonUtility.FromJson<GameSave>(validEnvelope);
            duplicateId.memory.observations[0].id = duplicateId.memory.claims[0].id;
            check(SaveManager.Deserialize(JsonUtility.ToJson(duplicateId)) == null,
                "The save boundary accepted duplicate IDs across social record kinds.");
            GameSave invalidSubject = JsonUtility.FromJson<GameSave>(validEnvelope);
            invalidSubject.memory.knowledge[0].subjectId = "";
            check(SaveManager.Deserialize(JsonUtility.ToJson(invalidSubject)) == null,
                "The save boundary accepted a knowledge record without a subject identity.");
            return passed;
        }

    }
}
#endif
