using System;
using UnityEngine;
using VelvetVendetta.Act0;

namespace VelvetVendetta.Core
{
    // Composition root; plain C# state lives here rather than inside streamed scene objects.
    public sealed class GameServices : MonoBehaviour
    {
        public static GameServices Instance { get; private set; }
        public WorldState World { get; private set; }
        public SocialMemory Memory { get; private set; }
        public Act0Story Story { get; private set; }
        public WorldManager WorldManager { get; private set; }
        public ObservationService Observations { get; private set; }
        public string SaveStatus { get; private set; }
        private bool dirty;
        private float saveTimer;

        public void Initialize(WorldManager worldManager)
        {
            Instance = this;
            WorldManager = worldManager;
            GameSave saved = SaveManager.Load(out string status);
            SaveStatus = status;
            World = saved == null ? new WorldState() : saved.world;
            Memory = saved == null ? new SocialMemory() : saved.memory;
            Story = new Act0Story(saved == null ? null : saved.act0);
            Observations = new ObservationService(World, Memory);
            Story.Changed += StateChanged;
            Story.ChoiceMade += OnChoice;
        }

        public void NewGame(string name, string origin)
        {
            Story.Changed -= StateChanged;
            Story.ChoiceMade -= OnChoice;
            World = new WorldState();
            Memory = new SocialMemory();
            Observations = new ObservationService(World, Memory);
            Story = new Act0Story();
            Story.Changed += StateChanged;
            Story.ChoiceMade += OnChoice;
            Story.Start(name, origin);
            World.SetBool("Funeral.WentHomeFirst", origin == "home");
            if (origin != "home") RecordArrival();
            SaveNow();
        }

        public void RecordArrival()
        {
            if (World.GetBool("Funeral.Arrived")) return;
            World.SetBool("Funeral.Arrived", true);
            World.SetTimestamp("Funeral.ArrivalTime", Story.State.gameTime);
            World.SetBool("Funeral.ArrivedLate", Story.State.gameTime >= 120);
            dirty = true;
        }

        public void EnterFuneralHome()
        {
            RecordArrival();
            World.SetBool("Funeral.EnteredFuneralHome", true);
            Story.ReachLocation(Act0Target.Entrance);
            dirty = true;
        }

        public void EnterOffice()
        {
            if (World.GetBool("Funeral.PrivateOfficeEntered")) return;
            World.SetBool("Funeral.PrivateOfficeEntered", true);
            dirty = true;
        }

        public void Tick(float delta)
        {
            Story.Tick(delta);
            foreach (NarrativeOpportunity opportunity in Act0Sequence.Opportunities)
            {
                if (!opportunity.endsAt.HasValue || Story.State.Choice(opportunity.target.ToString().ToLowerInvariant()) != null)
                    continue;
                string missed = "Narrative.Missed." + opportunity.id;
                if (World.GetBool(missed)) continue;
                if (Act0Sequence.Evaluate(opportunity, Story.State.gameTime, key => World.GetBool(key), null)
                    != OpportunityAvailability.Expired) continue;
                World.SetBool(missed, true);
                World.SetString("Narrative.MissedEvent." + opportunity.id, opportunity.onMissedEvent);
                World.SetTimestamp("Narrative.MissedAt." + opportunity.id, Story.State.gameTime);
                dirty = true;
            }
            saveTimer += delta;
            if (saveTimer >= 5 && dirty) SaveNow();
        }

        public void SetPlayerPosition(Vector3 position)
        {
            if (!Story.State.started) return;
            Story.Move(position.x, position.y, position.z, false);
            dirty = true;
        }

        public void SaveNow()
        {
            if (Story == null || !Story.State.started) return;
            SyncFacts();
            bool saved = SaveManager.Save(new GameSave { act0 = Story.State, world = World, memory = Memory }, out string status);
            SaveStatus = status;
            dirty = !saved;
            saveTimer = 0;
        }

        private void StateChanged() { SyncFacts(); dirty = true; }
        private void SyncFacts()
        {
            if (Story == null) return;
            World.SetBool("Funeral.BurialAttended", Story.State.burialAttended);
            World.SetBool("Funeral.Departed", Story.State.completed);
            World.SetBool("Act0.Completed", Story.State.completed);
        }

        private void OnChoice(Act0Target target, string choice)
        {
            double time = Story.State.gameTime;
            string entity = EntityId(target);
            // Responses are append-only testimony, independent of objective facts.
            Memory.RecordClaim("player.local", entity, "Response." + target,
                WorldFact.String("Response." + target, choice), time, MemorySourceType.PlayerResponse);
            switch (target)
            {
                case Act0Target.Maya:
                case Act0Target.Ruth:
                case Act0Target.Darius:
                case Act0Target.Mourner:
                    World.SetBool("Funeral.SpokeWith." + target, true);
                    if (target == Act0Target.Darius)
                        AddClaimOnce(entity, "Darius.KnewEliasYears", WorldFact.Int("Darius.KnewEliasYears", 2));
                    if (target == Act0Target.Ruth)
                        AddClaimOnce(entity, "Darius.KnewEliasYears", WorldFact.Int("Darius.KnewEliasYears", 15));
                    if (target == Act0Target.Mourner)
                        AddClaimOnce(entity, "Elias.LastMeeting", WorldFact.String("Elias.LastMeeting", "Wednesday"));
                    break;
                case Act0Target.SUV:
                    World.SetBool("Funeral.BlackSUVApproached", true);
                    Observations.Observe("player.local", entity, "Funeral.BlackSUVObserved", time, "Funeral parking lot");
                    break;
                case Act0Target.Casket:
                    World.SetBool("Funeral.ViewedDeceased", true);
                    if (choice == "notice" || choice == "remember")
                        Observations.Observe("player.local", "npc.elias", "Funeral.MissingWatchObserved", time, "Viewing room");
                    break;
                case Act0Target.Service:
                    World.SetBool("Funeral.SatForService", true);
                    World.SetBool("Funeral.SpokeAtEulogy", choice != "silent" && choice != "silence");
                    World.SetBool("Funeral.MentionedWednesday", choice == "last-conversation");
                    if (choice != "silent" && choice != "silence")
                    {
                        ClaimRecord spoken = Memory.RecordClaim("player.local", "npc.elias", "Eulogy.Theme",
                            WorldFact.String("Eulogy.Theme", choice), time, MemorySourceType.Statement);
                        Memory.RecordKnowledge(EntityId(Act0Target.Ruth), "npc.elias", "Eulogy.Theme",
                            spoken.value, time, MemorySourceType.DirectObservation, TruthStatus.Unknown, 1, spoken.id);
                    }
                    break;
                case Act0Target.Office:
                    EnterOffice();
                    Observations.Observe("player.local", entity, "Funeral.OfficeMaterialObserved", time, "Private office");
                    if (choice == "watch")
                        Observations.Observe("player.local", "npc.elias", "Funeral.MissingWatchObserved", time, "Office receipt");
                    break;
                case Act0Target.Card:
                    if (choice == "keep" || choice == "share" || choice == "take")
                        Observations.Observe("player.local", entity, "Funeral.BlackCardCollected", time, "Cemetery gate");
                    break;
            }
            dirty = true;
            SaveNow();
        }

        private void AddClaimOnce(string speaker, string topic, WorldFact value)
        {
            if (Memory.claims.Exists(record => record.speakerId == speaker && record.topic == topic)) return;
            ClaimRecord claim = Memory.RecordClaim(speaker, "npc.elias", topic, value, Story.State.gameTime);
            Memory.RecordKnowledge("player.local", "npc.elias", topic, value, Story.State.gameTime,
                MemorySourceType.Statement, TruthStatus.Unknown, .65f, claim.id);
        }

        public static string EntityId(Act0Target target) { return "act0." + target.ToString().ToLowerInvariant(); }
        private void OnApplicationPause(bool paused) { if (paused) SaveNow(); }
        private void OnApplicationQuit() { SaveNow(); }
        private void OnDestroy()
        {
            if (Story != null) { Story.Changed -= StateChanged; Story.ChoiceMade -= OnChoice; }
            if (Instance == this) Instance = null;
        }
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetInstance() { Instance = null; }
    }

    public sealed class ObservationService
    {
        private readonly WorldState world;
        private readonly SocialMemory memory;
        public ObservationService(WorldState world, SocialMemory memory) { this.world = world; this.memory = memory; }
        public void Observe(string observer, string subject, string fact, double time, string context)
        {
            if (world.GetBool(fact)) return;
            world.SetBool(fact, true);
            ObservationRecord observation = memory.RecordObservation(observer, subject, fact, time, context);
            memory.RecordKnowledge(observer, subject, fact, observation.value, time,
                MemorySourceType.DirectObservation, TruthStatus.True, 1, observation.id);
        }
    }
}
