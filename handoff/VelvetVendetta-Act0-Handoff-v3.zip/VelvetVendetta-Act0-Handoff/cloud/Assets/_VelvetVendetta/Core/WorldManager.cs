using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace VelvetVendetta.Core
{
    /// <summary>Stable scene identity and optional X/Z streaming bounds, independent of story beats.</summary>
    [Serializable]
    public sealed class WorldCellDefinition
    {
        public string Id;
        public string SceneName;
        public bool IsInterior;
        public bool AllowRuntimeFallback;
        public bool StreamByProximity;
        public Vector2 Minimum;
        public Vector2 Maximum;
        public float LoadMargin = 10f;
        public float UnloadMargin = 20f;

        public WorldCellDefinition(string id, bool interior = false, bool runtimeFallback = false)
        {
            Id = id;
            SceneName = id;
            IsInterior = interior;
            AllowRuntimeFallback = runtimeFallback;
        }

        public bool Contains(Vector3 position, float margin)
        {
            return position.x >= Minimum.x - margin && position.x <= Maximum.x + margin &&
                   position.z >= Minimum.y - margin && position.z <= Maximum.y + margin;
        }
    }

    /// <summary>
    /// Persistent additive loader. Current greyboxes use real runtime scenes until authored
    /// scenes with the same IDs are added to Build Settings. Player/services never move here.
    /// </summary>
    public sealed class WorldManager : MonoBehaviour
    {
        public const string OldKentahten = "World_OldKentahten";
        public const string FuneralHome = "INT_FuneralHome";
        public const string PlayerHome = "INT_PlayerHome";

        private sealed class Operation
        {
            public bool Loading;
            public bool Complete;
        }

        private sealed class Cell
        {
            public WorldCellDefinition Definition;
            public Scene Scene;
            public Operation Operation;
            public bool StreamWanted;
            public bool Reconciling;
            public bool StreamFailed;
        }

        private readonly Dictionary<string, Cell> cells = new Dictionary<string, Cell>(StringComparer.Ordinal);
        private readonly List<WorldCellDefinition> catalog = new List<WorldCellDefinition>();
        private Action<string, Scene> createFallback;
        private bool initialized;
        private bool transitioning;

        public string LastError { get; private set; }
        public bool IsBusy { get { return transitioning || HasPendingCellOperations(); } }
        public IReadOnlyList<WorldCellDefinition> Catalog { get { return catalog.AsReadOnly(); } }
        public event Action<string, Scene> Loaded;
        public event Action<string> Unloaded;

        public IEnumerable<string> LoadedIds
        {
            get
            {
                // A snapshot remains safe while a transition unloads its previous cells.
                List<string> result = new List<string>();
                foreach (KeyValuePair<string, Cell> pair in cells)
                    if (SceneReady(pair.Value)) result.Add(pair.Key);
                return result;
            }
        }

        /// <param name="fallback">
        /// Creates a greybox root in the supplied scene. Move the root with
        /// SceneManager.MoveGameObjectToScene before constructing its children.
        /// Only explicitly permitted current cells may use this callback.
        /// </param>
        public void Initialize(Action<string, Scene> fallback)
        {
            createFallback = fallback;
            if (initialized) return;
            initialized = true;
            string[] worldIds =
            {
                OldKentahten, "World_Downtown", "World_Southside", "World_University",
                "World_EastEnd", "World_Industrial", "World_HorseCountry", "World_Hollows",
                "World_Reservoir", "World_Airport", "World_Interstate", "World_CountyRoads"
            };
            foreach (string id in worldIds)
                RegisterCell(new WorldCellDefinition(id, false, id == OldKentahten));

            RegisterCell(new WorldCellDefinition(FuneralHome, true, true)
            {
                StreamByProximity = true,
                Minimum = new Vector2(9f, 9f), Maximum = new Vector2(51f, 29f)
            });
            RegisterCell(new WorldCellDefinition(PlayerHome, true, true)
            {
                StreamByProximity = true,
                Minimum = new Vector2(12f, 66f), Maximum = new Vector2(24f, 79f)
            });
        }

        public bool RegisterCell(WorldCellDefinition definition)
        {
            if (definition == null || string.IsNullOrWhiteSpace(definition.Id) ||
                string.IsNullOrWhiteSpace(definition.SceneName))
            {
                LastError = "World cells require a stable ID and scene name.";
                return false;
            }
            if (cells.ContainsKey(definition.Id))
            {
                LastError = "World cell is already registered: " + definition.Id;
                return false;
            }
            cells.Add(definition.Id, new Cell { Definition = definition });
            catalog.Add(definition);
            return true;
        }

        public bool IsLoaded(string id)
        {
            Cell cell;
            return id != null && cells.TryGetValue(id, out cell) && SceneReady(cell);
        }

        public bool TryGetScene(string id, out Scene scene)
        {
            Cell cell;
            if (id != null && cells.TryGetValue(id, out cell) && SceneReady(cell))
            {
                scene = cell.Scene;
                return true;
            }
            scene = default(Scene);
            return false;
        }

        public IEnumerator LoadCell(string id)
        {
            Cell cell;
            if (id == null || !cells.TryGetValue(id, out cell))
            {
                LastError = "Unknown world cell: " + (id ?? "<null>");
                yield break;
            }
            while (cell.Operation != null && !cell.Operation.Complete)
            {
                Operation pending = cell.Operation;
                while (!pending.Complete) yield return null;
                // Concurrent callers share the same result, including a failed load.
                if (pending.Loading) yield break;
            }
            if (SceneReady(cell)) yield break;

            Operation operation = new Operation { Loading = true };
            cell.Operation = operation;
            LastError = null;
            try
            {
                Scene scene = FindScene(cell.Definition.SceneName);
                if (!scene.IsValid() || !scene.isLoaded)
                {
                    if (Application.CanStreamedLevelBeLoaded(cell.Definition.SceneName))
                    {
                        AsyncOperation loading = BeginLoad(cell.Definition.SceneName);
                        if (loading == null) yield break;
                        while (!loading.isDone) yield return null;
                        scene = FindScene(cell.Definition.SceneName);
                    }
                    else if (cell.Definition.AllowRuntimeFallback && createFallback != null)
                    {
                        bool created = CreateFallback(cell.Definition.Id, out scene);
                        if (!created)
                        {
                            // A failed builder must not leave a partially playable cell behind.
                            if (scene.IsValid() && scene.isLoaded)
                            {
                                foreach (GameObject root in scene.GetRootGameObjects()) root.SetActive(false);
                                AsyncOperation cleanup = BeginUnload(scene);
                                if (cleanup != null) while (!cleanup.isDone) yield return null;
                            }
                            yield break;
                        }
                    }
                    else
                    {
                        LastError = "Scene is not available in Build Settings: " + cell.Definition.SceneName;
                        yield break;
                    }
                }
                if (!scene.IsValid() || !scene.isLoaded)
                {
                    LastError = "World cell did not finish loading: " + id;
                    yield break;
                }
                cell.Scene = scene;
                cell.StreamFailed = false;
                NotifyLoaded(id, scene);
            }
            finally
            {
                operation.Complete = true;
            }
        }

        public IEnumerator UnloadCell(string id)
        {
            Cell cell;
            if (id == null || !cells.TryGetValue(id, out cell))
            {
                LastError = "Unknown world cell: " + (id ?? "<null>");
                yield break;
            }
            while (cell.Operation != null && !cell.Operation.Complete)
            {
                Operation pending = cell.Operation;
                while (!pending.Complete) yield return null;
                if (!pending.Loading) yield break;
            }
            if (!SceneReady(cell)) yield break;

            Operation operation = new Operation();
            cell.Operation = operation;
            LastError = null;
            try
            {
                AsyncOperation unloading = BeginUnload(cell.Scene);
                if (unloading == null) yield break;
                while (!unloading.isDone) yield return null;
                if (SceneReady(cell))
                {
                    LastError = "World cell could not be unloaded: " + id;
                    yield break;
                }
                cell.Scene = default(Scene);
                NotifyUnloaded(id);
            }
            finally
            {
                operation.Complete = true;
            }
        }

        /// <summary>Load before unloading; unavailable future cells preserve the current playable area.</summary>
        public IEnumerator TransitionTo(string id)
        {
            while (transitioning) yield return null;
            transitioning = true;
            try
            {
                yield return LoadCell(id);
                if (!IsLoaded(id)) yield break;
                Cell destination = cells[id];
                // An interior transition keeps its surrounding exterior resident.
                if (destination.Definition.IsInterior) yield break;
                // A proximity load already in flight must settle before the unload snapshot.
                // Its reconciler sees transitioning and cannot schedule another operation.
                while (HasPendingCellOperations()) yield return null;
                List<string> previous = new List<string>(LoadedIds);
                foreach (string previousId in previous)
                    if (previousId != id) yield return UnloadCell(previousId);
            }
            finally
            {
                transitioning = false;
            }
        }

        public void UpdatePlayerLocation(Vector3 position) { Tick(position); }

        public void Tick(Vector3 position)
        {
            if (!initialized || transitioning || !HasLoadedExterior()) return;
            foreach (Cell cell in cells.Values)
            {
                WorldCellDefinition definition = cell.Definition;
                if (!definition.StreamByProximity) continue;
                bool desired = cell.StreamWanted;
                if (definition.Contains(position, definition.LoadMargin)) desired = true;
                else if (!definition.Contains(position, Mathf.Max(definition.LoadMargin, definition.UnloadMargin))) desired = false;
                if (desired != cell.StreamWanted)
                {
                    cell.StreamWanted = desired;
                    cell.StreamFailed = false;
                }
                if (!cell.Reconciling && !cell.StreamFailed && desired != SceneReady(cell))
                    StartCoroutine(Reconcile(cell));
            }
        }

        private IEnumerator Reconcile(Cell cell)
        {
            cell.Reconciling = true;
            try
            {
                while (!transitioning && cell.StreamWanted != SceneReady(cell))
                {
                    bool request = cell.StreamWanted;
                    if (request) yield return LoadCell(cell.Definition.Id);
                    else yield return UnloadCell(cell.Definition.Id);
                    if (SceneReady(cell) != request)
                    {
                        // Retry after leaving/re-entering the area, or an explicit LoadCell call.
                        cell.StreamFailed = true;
                        yield break;
                    }
                }
            }
            finally
            {
                cell.Reconciling = false;
            }
        }

        private static bool SceneReady(Cell cell)
        {
            return cell.Scene.IsValid() && cell.Scene.isLoaded;
        }

        private bool HasPendingCellOperations()
        {
            foreach (Cell cell in cells.Values)
                if (cell.Reconciling || (cell.Operation != null && !cell.Operation.Complete)) return true;
            return false;
        }

        private bool HasLoadedExterior()
        {
            foreach (Cell cell in cells.Values)
                if (!cell.Definition.IsInterior && SceneReady(cell)) return true;
            return false;
        }

        private static Scene FindScene(string sceneName)
        {
            Scene scene = SceneManager.GetSceneByPath(sceneName);
            return scene.IsValid() ? scene : SceneManager.GetSceneByName(sceneName);
        }

        private AsyncOperation BeginLoad(string sceneName)
        {
            try
            {
                AsyncOperation result = SceneManager.LoadSceneAsync(sceneName, LoadSceneMode.Additive);
                if (result == null) LastError = "Could not begin loading scene: " + sceneName;
                return result;
            }
            catch (Exception exception) { LastError = "Could not load " + sceneName + ": " + exception.Message; return null; }
        }

        private AsyncOperation BeginUnload(Scene scene)
        {
            try
            {
                AsyncOperation result = SceneManager.UnloadSceneAsync(scene);
                if (result == null) LastError = "Could not begin unloading scene: " + scene.name;
                return result;
            }
            catch (Exception exception) { LastError = "Could not unload " + scene.name + ": " + exception.Message; return null; }
        }

        private bool CreateFallback(string id, out Scene scene)
        {
            scene = default(Scene);
            try
            {
                scene = SceneManager.CreateScene(id);
                createFallback(id, scene);
                if (scene.rootCount == 0)
                    throw new InvalidOperationException("The greybox builder did not create a scene root.");
                return true;
            }
            catch (Exception exception)
            {
                LastError = "Could not build " + id + ": " + exception.Message;
                return false;
            }
        }

        private void NotifyLoaded(string id, Scene scene)
        {
            Action<string, Scene> listeners = Loaded;
            if (listeners == null) return;
            foreach (Delegate listener in listeners.GetInvocationList())
            {
                try { ((Action<string, Scene>)listener)(id, scene); }
                catch (Exception exception) { LastError = "Loaded callback failed for " + id + ": " + exception.Message; }
            }
        }

        private void NotifyUnloaded(string id)
        {
            Action<string> listeners = Unloaded;
            if (listeners == null) return;
            foreach (Delegate listener in listeners.GetInvocationList())
            {
                try { ((Action<string>)listener)(id); }
                catch (Exception exception) { LastError = "Unloaded callback failed for " + id + ": " + exception.Message; }
            }
        }
    }
}
