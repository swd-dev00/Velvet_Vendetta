using System;
using System.Collections.Generic;

namespace VelvetVendetta.Core
{
    public enum TruthStatus { Unknown, True, False }
    public enum MemorySourceType { Statement, DirectObservation, PlayerResponse, Document, Hearsay, Inference }

    [Serializable]
    public sealed class ClaimRecord
    {
        public string id;
        public string speakerId;
        public string subjectId;
        public string topic;
        public WorldFact value;
        public double gameTime;
        public MemorySourceType sourceType;
        public TruthStatus truth;
        public float confidence;

        public ClaimRecord() { }

        public ClaimRecord(string speaker, string subject, string topic, WorldFact value, double gameTime,
            MemorySourceType sourceType = MemorySourceType.Statement, TruthStatus truth = TruthStatus.Unknown, float confidence = 1)
        {
            SocialMemory.Validate(speaker, subject, topic, value, gameTime, sourceType, truth, confidence);
            id = Guid.NewGuid().ToString("N");
            speakerId = speaker; subjectId = subject; this.topic = topic; this.value = value.Copy();
            this.gameTime = gameTime; this.sourceType = sourceType; this.truth = truth; this.confidence = confidence;
        }
    }

    [Serializable]
    public sealed class ObservationRecord
    {
        public string id;
        public string observerId;
        public string subjectId;
        public string topic;
        public WorldFact value;
        public double gameTime;
        public string context;
        public MemorySourceType sourceType;
        public TruthStatus truth;
        public float confidence;

        public ObservationRecord() { }

        public ObservationRecord(string observer, string subject, string topic, WorldFact value, double gameTime,
            string context = "", float confidence = 1)
        {
            SocialMemory.Validate(observer, subject, topic, value, gameTime,
                MemorySourceType.DirectObservation, TruthStatus.Unknown, confidence);
            id = Guid.NewGuid().ToString("N");
            observerId = observer; subjectId = subject; this.topic = topic; this.value = value.Copy();
            this.gameTime = gameTime; this.context = context ?? string.Empty; this.confidence = confidence;
            sourceType = MemorySourceType.DirectObservation; truth = TruthStatus.Unknown;
        }
    }

    /// <summary>An entity's belief can disagree with objective state or another entity's belief.</summary>
    [Serializable]
    public sealed class KnowledgeRecord
    {
        public string id;
        public string observerId;
        public string subjectId;
        public string topic;
        public WorldFact value;
        public double gameTime;
        public string sourceRecordId;
        public MemorySourceType sourceType;
        public TruthStatus truth;
        public float confidence;

        public KnowledgeRecord() { }

        public KnowledgeRecord(string observer, string subject, string topic, WorldFact value, double gameTime,
            MemorySourceType sourceType, TruthStatus truth = TruthStatus.Unknown, float confidence = 1, string sourceRecordId = "")
        {
            SocialMemory.Validate(observer, subject, topic, value, gameTime, sourceType, truth, confidence);
            id = Guid.NewGuid().ToString("N");
            observerId = observer; subjectId = subject; this.topic = topic; this.value = value.Copy();
            this.gameTime = gameTime; this.sourceType = sourceType; this.truth = truth; this.confidence = confidence;
            this.sourceRecordId = sourceRecordId ?? string.Empty;
        }
    }

    /// <summary>Append-only social history. Recording information never updates objective WorldState.</summary>
    [Serializable]
    public sealed class SocialMemory
    {
        public List<ClaimRecord> claims = new List<ClaimRecord>();
        public List<ObservationRecord> observations = new List<ObservationRecord>();
        public List<KnowledgeRecord> knowledge = new List<KnowledgeRecord>();

        public ClaimRecord RecordClaim(string speaker, string subject, string topic, WorldFact value, double time,
            MemorySourceType sourceType = MemorySourceType.Statement, TruthStatus truth = TruthStatus.Unknown, float confidence = 1)
        {
            var record = new ClaimRecord(speaker, subject, topic, value, time, sourceType, truth, confidence);
            if (claims == null) claims = new List<ClaimRecord>();
            claims.Add(record);
            return record;
        }

        public ObservationRecord RecordObservation(string observer, string subject, string topic, double time,
            string context = "", float confidence = 1)
        { return RecordObservation(observer, subject, topic, WorldFact.Bool(topic, true), time, context, confidence); }

        public ObservationRecord RecordObservation(string observer, string subject, string topic, WorldFact value,
            double time, string context = "", float confidence = 1)
        {
            var record = new ObservationRecord(observer, subject, topic, value, time, context, confidence);
            if (observations == null) observations = new List<ObservationRecord>();
            observations.Add(record);
            return record;
        }

        public KnowledgeRecord RecordKnowledge(string observer, string subject, string topic, WorldFact value, double time,
            MemorySourceType sourceType, TruthStatus truth = TruthStatus.Unknown, float confidence = 1, string sourceRecordId = "")
        {
            var record = new KnowledgeRecord(observer, subject, topic, value, time, sourceType, truth, confidence, sourceRecordId);
            if (knowledge == null) knowledge = new List<KnowledgeRecord>();
            knowledge.Add(record);
            return record;
        }

        internal static void Validate(string actor, string subject, string topic, WorldFact value, double time,
            MemorySourceType sourceType, TruthStatus truth, float confidence)
        {
            WorldFact.RequireText(actor, nameof(actor));
            WorldFact.RequireText(subject, nameof(subject));
            WorldFact.RequireText(topic, nameof(topic));
            if (value == null) throw new ArgumentNullException(nameof(value));
            WorldFact.RequireTime(time);
            if (!Enum.IsDefined(typeof(MemorySourceType), sourceType)) throw new ArgumentOutOfRangeException(nameof(sourceType));
            if (!Enum.IsDefined(typeof(TruthStatus), truth)) throw new ArgumentOutOfRangeException(nameof(truth));
            if (float.IsNaN(confidence) || float.IsInfinity(confidence) || confidence < 0 || confidence > 1)
                throw new ArgumentOutOfRangeException(nameof(confidence), "Confidence must be between zero and one.");
        }
    }
}
