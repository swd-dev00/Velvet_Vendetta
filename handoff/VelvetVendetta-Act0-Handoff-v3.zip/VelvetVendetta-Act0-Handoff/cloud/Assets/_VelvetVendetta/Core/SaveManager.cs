using System;
using System.IO;
using System.Collections.Generic;
using UnityEngine;
using VelvetVendetta.Act0;

namespace VelvetVendetta.Core
{
    [Serializable]
    public sealed class GameSave
    {
        public int version = 1;
        public Act0State act0;
        public WorldState world;
        public SocialMemory memory;
    }

    public static class SaveManager
    {
        public static string SavePath { get { return Path.Combine(Application.persistentDataPath, "velvet-act0-v1.json"); } }
        public static GameSave Load(out string status)
        {
            status = "No saved homecoming";
            foreach (string path in new[] { SavePath, SavePath + ".bak" })
            {
                if (!File.Exists(path)) continue;
                try
                {
                    GameSave save = Deserialize(File.ReadAllText(path));
                    if (save == null) { status = "Unreadable save retained; a new story is available"; continue; }
                    status = path == SavePath ? "Saved homecoming found" : "Recovered the previous save";
                    return save;
                }
                catch (Exception exception) when (exception is IOException || exception is UnauthorizedAccessException || exception is ArgumentException)
                { status = "Save could not be read; original file retained"; }
            }
            return null;
        }

        public static GameSave Deserialize(string json)
        {
            try
            {
                GameSave save = JsonUtility.FromJson<GameSave>(json);
                if (save == null || save.version != 1 || !Act0Story.IsValidState(save.act0)
                    || save.world == null || save.world.facts == null || save.memory == null
                    || save.memory.claims == null || save.memory.observations == null || save.memory.knowledge == null)
                    return null;
                // Reconstruct through typed setters to reject malformed tags, values and duplicate keys.
                WorldState checkedWorld = new WorldState();
                foreach (WorldFact fact in save.world.facts)
                {
                    if (fact == null || checkedWorld.Has(fact.key)) return null;
                    if (Array.IndexOf(Act0Sequence.KnownFactKeys, fact.key) >= 0 || fact.key == "Act0.TitleShown")
                    {
                        WorldFactType expected = fact.key == "Funeral.ArrivalTime" ? WorldFactType.Timestamp : WorldFactType.Bool;
                        if (fact.type != expected) return null;
                    }
                    if (fact.key != null && fact.key.StartsWith("Narrative.Missed.", StringComparison.Ordinal)
                        && fact.type != WorldFactType.Bool) return null;
                    if (fact.key != null && fact.key.StartsWith("Narrative.MissedEvent.", StringComparison.Ordinal)
                        && fact.type != WorldFactType.String) return null;
                    if (fact.key != null && fact.key.StartsWith("Narrative.MissedAt.", StringComparison.Ordinal)
                        && fact.type != WorldFactType.Timestamp) return null;
                    checkedWorld.Set(fact);
                }
                save.world = checkedWorld;
                if (save.memory.claims.Exists(record => record == null || record.value == null)
                    || save.memory.observations.Exists(record => record == null || record.value == null)
                    || save.memory.knowledge.Exists(record => record == null || record.value == null)) return null;
                var recordIds = new HashSet<string>(StringComparer.Ordinal);
                foreach (ClaimRecord record in save.memory.claims)
                {
                    if (string.IsNullOrWhiteSpace(record.id) || !recordIds.Add(record.id)) return null;
                    SocialMemory.Validate(record.speakerId, record.subjectId, record.topic, record.value,
                        record.gameTime, record.sourceType, record.truth, record.confidence);
                    record.value.Copy();
                }
                foreach (ObservationRecord record in save.memory.observations)
                {
                    if (string.IsNullOrWhiteSpace(record.id) || !recordIds.Add(record.id)) return null;
                    SocialMemory.Validate(record.observerId, record.subjectId, record.topic, record.value,
                        record.gameTime, record.sourceType, record.truth, record.confidence);
                    record.value.Copy();
                }
                foreach (KnowledgeRecord record in save.memory.knowledge)
                {
                    if (string.IsNullOrWhiteSpace(record.id) || !recordIds.Add(record.id)) return null;
                    SocialMemory.Validate(record.observerId, record.subjectId, record.topic, record.value,
                        record.gameTime, record.sourceType, record.truth, record.confidence);
                    record.value.Copy();
                }
                return save;
            }
            catch (ArgumentException) { return null; }
            catch (InvalidOperationException) { return null; }
        }

        public static bool Save(GameSave save, out string status)
        {
            try
            {
                Directory.CreateDirectory(Application.persistentDataPath);
                string temp = SavePath + ".tmp";
                File.WriteAllText(temp, JsonUtility.ToJson(save, true));
                if (File.Exists(SavePath))
                {
                    File.Copy(SavePath, SavePath + ".bak", true);
                    File.Delete(SavePath);
                }
                File.Move(temp, SavePath);
                status = "Progress saved";
                return true;
            }
            catch (Exception exception) when (exception is IOException || exception is UnauthorizedAccessException || exception is ArgumentException)
            {
                status = "Saving unavailable — progress remains in this session";
                return false;
            }
        }
    }
}
