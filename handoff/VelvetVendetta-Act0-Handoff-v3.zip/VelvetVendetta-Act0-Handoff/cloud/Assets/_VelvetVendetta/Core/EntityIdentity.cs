using System;
using System.Collections.Generic;
using UnityEngine;

namespace VelvetVendetta.Core
{
    /// <summary>
    /// Persistent identity for entities referenced by saves and unloaded scenes.
    /// Authored objects retain their serialized GUID. Generated objects call Initialize
    /// with a deterministic ID from the world definition before entering gameplay.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class EntityIdentity : MonoBehaviour
    {
        [SerializeField, Tooltip("Persistent identity. Do not change after saves reference this entity. Generated entities should call Initialize.")]
        private string stableId;

        private string registeredId;
        private static readonly Dictionary<string, EntityIdentity> Registry =
            new Dictionary<string, EntityIdentity>(StringComparer.Ordinal);

        public string StableId { get { return stableId; } }

        /// <summary>
        /// Assign a deterministic identity to a generated entity. A duplicate never
        /// replaces the existing canonical owner; validation reports both objects.
        /// Returns false while another enabled entity owns this ID.
        /// </summary>
        public bool Initialize(string id)
        {
            if (string.IsNullOrWhiteSpace(id))
                throw new ArgumentException("A persistent entity ID cannot be empty.", "id");

            Unregister();
            stableId = id;
            return !isActiveAndEnabled || Register();
        }

        public static bool TryGet(string id, out EntityIdentity entity)
        {
            entity = null;
            if (string.IsNullOrEmpty(id)) return false;
            EntityIdentity found;
            if (!Registry.TryGetValue(id, out found)) return false;
            if (found == null || !found.isActiveAndEnabled)
            {
                Registry.Remove(id);
                return false;
            }
            entity = found;
            return true;
        }

        /// <summary>A copy prevents callers from mutating the canonical registry.</summary>
        public static Dictionary<string, EntityIdentity> SnapshotRegistered()
        {
            return new Dictionary<string, EntityIdentity>(Registry, StringComparer.Ordinal);
        }

        /// <summary>
        /// Includes inactive objects and persistent runtime objects in loaded scenes.
        /// Prefab assets and editor previews are excluded by requiring a loaded scene.
        /// </summary>
        public static List<EntityIdentity> SnapshotLoaded()
        {
            var loaded = new List<EntityIdentity>();
            foreach (EntityIdentity entity in Resources.FindObjectsOfTypeAll<EntityIdentity>())
            {
                if (entity == null || !entity.gameObject.scene.IsValid() || !entity.gameObject.scene.isLoaded)
                    continue;
#if UNITY_EDITOR
                if (UnityEditor.SceneManagement.EditorSceneManager.IsPreviewScene(entity.gameObject.scene)) continue;
#endif
                loaded.Add(entity);
            }
            return loaded;
        }

        /// <summary>Inspect loaded identities without rewriting IDs or opening assets.</summary>
        public static List<string> ValidateLoaded()
        {
            var errors = new List<string>();
            var seen = new Dictionary<string, EntityIdentity>(StringComparer.Ordinal);
            foreach (EntityIdentity entity in SnapshotLoaded())
            {
                if (string.IsNullOrWhiteSpace(entity.stableId))
                {
                    errors.Add("Missing persistent entity ID: " + Describe(entity));
                    continue;
                }
                EntityIdentity first;
                if (seen.TryGetValue(entity.stableId, out first))
                    errors.Add("Duplicate persistent entity ID '" + entity.stableId + "': "
                        + Describe(first) + " and " + Describe(entity));
                else
                    seen.Add(entity.stableId, entity);
            }
            return errors;
        }

        private static string Describe(EntityIdentity entity)
        {
            string path = entity.name;
            Transform parent = entity.transform.parent;
            while (parent != null)
            {
                path = parent.name + "/" + path;
                parent = parent.parent;
            }
            return entity.gameObject.scene.name + ":" + path;
        }

        private void OnEnable() { Register(); }
        private void OnDisable() { Unregister(); }
        private void OnDestroy() { Unregister(); }

        private bool Register()
        {
            if (string.IsNullOrWhiteSpace(stableId)) return false;
            EntityIdentity existing;
            if (Registry.TryGetValue(stableId, out existing) && existing != null && existing != this)
                return false;
            Registry[stableId] = this;
            registeredId = stableId;
            return true;
        }

        private void Unregister()
        {
            if (string.IsNullOrEmpty(registeredId)) return;
            EntityIdentity owner;
            if (Registry.TryGetValue(registeredId, out owner) && owner == this)
                Registry.Remove(registeredId);
            registeredId = null;
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ClearRegistry()
        {
            Registry.Clear();
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        private static void RegisterLoadedEntities()
        {
            // Also restores registrations when domain reload is disabled in the editor.
            foreach (EntityIdentity entity in SnapshotLoaded())
                if (entity.isActiveAndEnabled) entity.Register();
        }

#if UNITY_EDITOR
        private void Reset() { EnsureAuthoredId(); }
        private void OnValidate() { EnsureAuthoredId(); }
        private void EnsureAuthoredId()
        {
            if (string.IsNullOrWhiteSpace(stableId)) stableId = Guid.NewGuid().ToString("N");
        }
#endif
    }
}
