using System;
using System.Collections.Generic;

namespace VelvetVendetta.Core
{
    public enum WorldFactType { Bool, Int, Float, String, Timestamp, EntityId }

    /// <summary>A tagged value with explicit fields so Unity JsonUtility can preserve its type.</summary>
    [Serializable]
    public sealed class WorldFact
    {
        public string key;
        public WorldFactType type;
        public bool boolValue;
        public int intValue;
        public float floatValue;
        public string stringValue;
        public double timestampValue;
        public string entityIdValue;

        public WorldFact() { }

        private WorldFact(string key, WorldFactType type)
        {
            RequireText(key, nameof(key));
            this.key = key;
            this.type = type;
        }

        public static WorldFact Bool(string key, bool value)
        { return new WorldFact(key, WorldFactType.Bool) { boolValue = value }; }

        public static WorldFact Int(string key, int value)
        { return new WorldFact(key, WorldFactType.Int) { intValue = value }; }

        public static WorldFact Float(string key, float value)
        {
            if (float.IsNaN(value) || float.IsInfinity(value)) throw new ArgumentOutOfRangeException(nameof(value));
            return new WorldFact(key, WorldFactType.Float) { floatValue = value };
        }

        public static WorldFact String(string key, string value)
        { return new WorldFact(key, WorldFactType.String) { stringValue = value ?? string.Empty }; }

        public static WorldFact Timestamp(string key, double value)
        {
            RequireTime(value);
            return new WorldFact(key, WorldFactType.Timestamp) { timestampValue = value };
        }

        public static WorldFact EntityId(string key, string value)
        {
            RequireText(value, nameof(value));
            return new WorldFact(key, WorldFactType.EntityId) { entityIdValue = value };
        }

        public WorldFact Copy()
        {
            switch (type)
            {
                case WorldFactType.Bool: return Bool(key, boolValue);
                case WorldFactType.Int: return Int(key, intValue);
                case WorldFactType.Float: return Float(key, floatValue);
                case WorldFactType.String: return String(key, stringValue);
                case WorldFactType.Timestamp: return Timestamp(key, timestampValue);
                case WorldFactType.EntityId: return EntityId(key, entityIdValue);
                default: throw new ArgumentOutOfRangeException(nameof(type), "Unknown world fact type.");
            }
        }

        internal static void RequireText(string value, string parameter)
        {
            if (string.IsNullOrWhiteSpace(value)) throw new ArgumentException("A stable nonempty identifier is required.", parameter);
        }

        internal static void RequireTime(double value)
        {
            if (double.IsNaN(value) || double.IsInfinity(value) || value < 0)
                throw new ArgumentOutOfRangeException(nameof(value), "Game time must be finite and nonnegative.");
        }
    }

    /// <summary>Objective facts only. Observations and conflicting statements belong to SocialMemory.</summary>
    [Serializable]
    public sealed class WorldState
    {
        public List<WorldFact> facts = new List<WorldFact>();

        public WorldState() { }

        public WorldState(IEnumerable<WorldFact> initialFacts)
        {
            if (initialFacts == null) return;
            foreach (WorldFact fact in initialFacts)
            {
                if (fact == null) throw new ArgumentException("Facts cannot contain null records.", nameof(initialFacts));
                if (Has(fact.key)) throw new ArgumentException("Duplicate world fact: " + fact.key, nameof(initialFacts));
                Set(fact);
            }
        }

        public bool Has(string key) { return Find(key) != null; }

        public bool TryGet(string key, out WorldFact value)
        {
            WorldFact found = Find(key);
            value = found == null ? null : found.Copy();
            return found != null;
        }

        public WorldFact Get(string key)
        {
            WorldFact found = Find(key);
            if (found == null) throw new KeyNotFoundException("Unknown world fact: " + key);
            return found.Copy();
        }

        public void Set(WorldFact value)
        {
            if (value == null) throw new ArgumentNullException(nameof(value));
            WorldFact copy = value.Copy();
            if (facts == null) facts = new List<WorldFact>();
            int index = facts.FindIndex(fact => fact != null && fact.key == copy.key);
            if (index >= 0)
            {
                if (facts[index].type != copy.type)
                    throw new InvalidOperationException("Cannot change the type of world fact " + copy.key + ".");
                facts[index] = copy;
            }
            else facts.Add(copy);
        }

        public void SetBool(string key, bool value) { Set(WorldFact.Bool(key, value)); }
        public void SetInt(string key, int value) { Set(WorldFact.Int(key, value)); }
        public void SetFloat(string key, float value) { Set(WorldFact.Float(key, value)); }
        public void SetString(string key, string value) { Set(WorldFact.String(key, value)); }
        public void SetTimestamp(string key, double value) { Set(WorldFact.Timestamp(key, value)); }
        public void SetEntityId(string key, string value) { Set(WorldFact.EntityId(key, value)); }

        public bool GetBool(string key, bool fallback = false)
        { WorldFact value = FindTyped(key, WorldFactType.Bool); return value == null ? fallback : value.boolValue; }
        public int GetInt(string key, int fallback = 0)
        { WorldFact value = FindTyped(key, WorldFactType.Int); return value == null ? fallback : value.intValue; }
        public float GetFloat(string key, float fallback = 0)
        { WorldFact value = FindTyped(key, WorldFactType.Float); return value == null ? fallback : value.floatValue; }
        public string GetString(string key, string fallback = "")
        { WorldFact value = FindTyped(key, WorldFactType.String); return value == null ? fallback : value.stringValue; }
        public double GetTimestamp(string key, double fallback = 0)
        { WorldFact value = FindTyped(key, WorldFactType.Timestamp); return value == null ? fallback : value.timestampValue; }
        public string GetEntityId(string key, string fallback = "")
        { WorldFact value = FindTyped(key, WorldFactType.EntityId); return value == null ? fallback : value.entityIdValue; }

        public List<WorldFact> Snapshot()
        {
            var result = new List<WorldFact>();
            if (facts != null) foreach (WorldFact fact in facts) result.Add(fact.Copy());
            return result;
        }

        private WorldFact Find(string key)
        {
            WorldFact.RequireText(key, nameof(key));
            return facts == null ? null : facts.Find(fact => fact != null && fact.key == key);
        }

        private WorldFact FindTyped(string key, WorldFactType type)
        {
            WorldFact value = Find(key);
            if (value != null && value.type != type)
                throw new InvalidOperationException("World fact " + key + " has type " + value.type + ", not " + type + ".");
            return value;
        }
    }
}
