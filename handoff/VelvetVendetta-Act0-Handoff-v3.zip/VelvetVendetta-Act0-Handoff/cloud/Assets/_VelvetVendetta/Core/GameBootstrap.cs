using UnityEngine;
using VelvetVendetta.Act0;

namespace VelvetVendetta.Core
{
    public sealed class GameBootstrap : MonoBehaviour
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        private static void Boot()
        {
            if (GameObject.Find("VelvetVendetta") != null)
                return;

            GameObject root = new GameObject("VelvetVendetta");
            DontDestroyOnLoad(root);
            root.AddComponent<GameBootstrap>();
        }

        private void Awake()
        {
            DontDestroyOnLoad(gameObject);
            if (GetComponent<Act0Director>() == null) gameObject.AddComponent<Act0Director>();
            Debug.Log("[Velvet Vendetta] Game bootstrap online.");
        }
    }
}
