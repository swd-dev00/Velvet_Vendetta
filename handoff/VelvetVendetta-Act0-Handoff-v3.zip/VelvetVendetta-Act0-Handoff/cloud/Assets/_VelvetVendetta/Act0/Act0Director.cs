using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using VelvetVendetta.Core;
using VelvetVendetta.Gameplay;

namespace VelvetVendetta.Act0
{
    public enum Act0Mode { Loading, Title, Intro, Playing, Dialogue, Paused, Journal, Phone, Complete, ConfirmRestart }

    // Wires input, presentation, locations and the pure story model. Rules live in Act0Story;
    // history and persistence live in GameServices; scenery belongs to additive cells.
    public sealed class Act0Director : MonoBehaviour
    {
        public GameServices Services { get; private set; }
        public Act0Mode Mode { get; private set; }
        public Dialogue ActiveDialogue { get; private set; }
        public int SelectedChoice { get; private set; }
        public string Prompt { get { return interactions == null || interactions.Current == null ? "" : interactions.Current.Prompt; } }
        public string Location { get; private set; }
        public float IntroSeconds { get; private set; }
        public string Toast { get { return toastTimer > 0 ? toast : ""; } }
        public ThirdPersonPlayer Player { get { return player; } }
        private ThirdPersonPlayer player;
        private ThirdPersonCamera followCamera;
        private InteractionController interactions;
        private InteractionContext interactionContext;
        private Act0World exterior;
        private Act0Target dialogueTarget;
        private Act0Phase lastPhase;
        private string pendingName = "Alex", pendingOrigin = "funeral", toast;
        private float toastTimer, positionTimer, completeTimer;
        private bool ready;
        private Vector3 previousPosition;

        private IEnumerator Start()
        {
            Mode = Act0Mode.Loading;
            var worldObject = new GameObject("WorldManager");
            worldObject.transform.SetParent(transform, false);
            WorldManager worlds = worldObject.AddComponent<WorldManager>();
            var serviceObject = new GameObject("GameServices");
            serviceObject.transform.SetParent(transform, false);
            Services = serviceObject.AddComponent<GameServices>();
            Services.Initialize(worlds);
            worlds.Initialize(BuildCell);
            yield return worlds.LoadCell(WorldManager.OldKentahten);
            yield return worlds.LoadCell(WorldManager.FuneralHome);

            var playerObject = new GameObject("Player");
            playerObject.transform.SetParent(transform, false);
            playerObject.AddComponent<EntityIdentity>().Initialize("player.local");
            player = playerObject.AddComponent<ThirdPersonPlayer>();
            player.Initialize(SavedPosition());
            var cameraObject = new GameObject("Player camera");
            cameraObject.transform.SetParent(transform, false);
            Camera camera = cameraObject.AddComponent<Camera>();
            camera.tag = "MainCamera";
            camera.fieldOfView = 55;
            camera.nearClipPlane = .08f;
            camera.farClipPlane = 180;
            camera.clearFlags = CameraClearFlags.SolidColor;
            camera.backgroundColor = new Color(.42f, .45f, .43f);
            if (FindObjectOfType<AudioListener>() == null) cameraObject.AddComponent<AudioListener>();
            followCamera = cameraObject.AddComponent<ThirdPersonCamera>();
            followCamera.Follow(player.transform, false);
            interactionContext = new InteractionContext { ActorId = "player.local" };
            RefreshContext();
            interactions = playerObject.AddComponent<InteractionController>();
            interactions.Initialize(interactionContext, camera);
            var ui = new GameObject("UI");
            ui.transform.SetParent(transform, false);
            ui.AddComponent<Act0Hud>().Initialize(this);
            Physics.SyncTransforms();
            previousPosition = player.transform.position;
            lastPhase = Services.Story.State.phase;
            Location = exterior.DistrictAt(previousPosition);
            ready = true;
            Mode = Act0Mode.Title;
        }

        private void BuildCell(string id, Scene scene)
        {
            var root = new GameObject(id);
            SceneManager.MoveGameObjectToScene(root, scene);
            Act0World world = root.AddComponent<Act0World>();
            if (id == WorldManager.OldKentahten) { world.Build(); exterior = world; }
            else world.BuildInterior(id);
            root.AddComponent<EntityIdentity>().Initialize("location." + id);
            foreach (Act0Point point in world.Points)
            {
                Act0Point captured = point;
                var endpoint = new GameObject(point.Label);
                endpoint.transform.SetParent(root.transform, false);
                endpoint.transform.position = point.Position;
                endpoint.AddComponent<InteractionTarget>().Initialize(GameServices.EntityId(point.Target),
                    point.Label, Kind(point.Target), point.Radius, context => Interact(captured.Target));
            }
            // The deceased can be referenced by testimony even when this room is unloaded.
            if (id == WorldManager.FuneralHome)
            {
                var deceased = new GameObject("Elias Mercer identity");
                deceased.transform.SetParent(root.transform, false);
                deceased.AddComponent<EntityIdentity>().Initialize("npc.elias");
            }
        }

        private static InteractionKind Kind(Act0Target target)
        {
            switch (target)
            {
                case Act0Target.Maya: case Act0Target.Ruth: case Act0Target.Darius: case Act0Target.Mourner:
                    return InteractionKind.Talk;
                case Act0Target.Card: return InteractionKind.PickUp;
                case Act0Target.Entrance: case Act0Target.Home: return InteractionKind.Open;
                case Act0Target.Service: return InteractionKind.Sit;
                case Act0Target.Grave: case Act0Target.Departure: return InteractionKind.Use;
                default: return InteractionKind.Inspect;
            }
        }

        private void Update()
        {
            if (!ready) return;
            PlayerInput.Read();
            float delta = Mathf.Min(Time.unscaledDeltaTime, .1f);
            toastTimer -= delta;
            if (Mode == Act0Mode.Title || Mode == Act0Mode.ConfirmRestart || Mode == Act0Mode.Paused)
            {
                HandleMenuInput();
                player.Stop();
                return;
            }
            // Conversations, exploration, the phone and the journal do not stop the funeral clock.
            Services.Tick(delta);
            RefreshContext();
            if (Services.Story.State.phase != lastPhase)
            {
                lastPhase = Services.Story.State.phase;
                Notify(Act0Story.Objective(lastPhase));
            }
            if (Mode == Act0Mode.Intro)
            {
                IntroSeconds -= delta;
                player.Stop();
                if (IntroSeconds <= 0 || PlayerInput.Confirm) Resume();
                return;
            }
            if (Mode == Act0Mode.Dialogue || Mode == Act0Mode.Journal || Mode == Act0Mode.Phone)
            {
                HandleMenuInput();
                player.Stop();
                return;
            }
            if (PlayerInput.Pause) { PauseGame(); return; }
            if (PlayerInput.Journal) { OpenJournal(); return; }
            player.Tick(PlayerInput.Move, followCamera.Heading, PlayerInput.Sprint, delta);
            Vector3 position = player.transform.position;
            Services.WorldManager.Tick(position);
            CheckLocations(previousPosition, position);
            previousPosition = position;
            Location = exterior.DistrictAt(position);
            interactions.Scan();
            if (PlayerInput.Confirm && Mode == Act0Mode.Playing) interactions.TryInteract();
            positionTimer += delta;
            if (positionTimer >= .4f) { Services.SetPlayerPosition(position); positionTimer = 0; }
            if (Mode == Act0Mode.Complete)
            {
                completeTimer -= delta;
                if (completeTimer <= 0 || PlayerInput.Confirm) Resume();
            }
        }

        private void LateUpdate()
        {
            if (!ready) return;
            bool orbit = Mode == Act0Mode.Playing || Mode == Act0Mode.Complete;
            followCamera.Tick(orbit ? PlayerInput.Look : Vector2.zero, !orbit,
                Mathf.Min(Time.unscaledDeltaTime, .1f), PlayerInput.UsingGamepad);
        }

        private void CheckLocations(Vector3 previous, Vector3 position)
        {
            if (position.x > 10 && position.x < 50 && position.z > 27 && position.z < 40)
                Services.RecordArrival();
            if (position.x > 11 && position.x < 49 && position.z > 10.5f && position.z < 27)
                if (!Services.World.GetBool("Funeral.EnteredFuneralHome")) Services.EnterFuneralHome();
            if (position.x > 40 && position.x < 49 && position.z > 20 && position.z < 26.5f)
                Services.EnterOffice();
            if (Vector3.Distance(position, new Vector3(86.4f, 0, 21.2f)) < 5)
                Services.Story.ReachLocation(Act0Target.Grave);
            if (previous.z <= 60 && position.z > 60 && Services.World.GetBool("Funeral.Arrived"))
            {
                Services.Story.ReachLocation(Act0Target.Departure);
                if (Services.Story.State.completed && !Services.World.GetBool("Act0.TitleShown"))
                {
                    Services.World.SetBool("Act0.TitleShown", true);
                    SetMode(Act0Mode.Complete);
                    completeTimer = 8;
                    Services.SetPlayerPosition(position);
                    Services.SaveNow();
                }
            }
        }

        private void Interact(Act0Target target)
        {
            if (Mode != Act0Mode.Playing) return;
            if (target == Act0Target.Entrance) Services.EnterFuneralHome();
            if (target == Act0Target.Grave) Services.Story.ReachLocation(target);
            ActiveDialogue = Services.Story.Interact(target);
            if (ActiveDialogue == null) return;
            dialogueTarget = target;
            SetMode(Act0Mode.Dialogue);
            player.Stop();
        }

        public void SelectChoice(int index) { SelectedChoice = Mathf.Clamp(index, 0, MenuCount() - 1); }

        private void HandleMenuInput()
        {
            if (PlayerInput.Navigate != 0)
                SelectedChoice = (SelectedChoice + PlayerInput.Navigate + MenuCount()) % MenuCount();
            if (PlayerInput.Back || PlayerInput.Pause) { CancelMenu(); return; }
            if (PlayerInput.Confirm) ActivateSelection();
        }

        private int MenuCount()
        {
            switch (Mode)
            {
                case Act0Mode.Title: return Services.Story.State.started ? 3 : 2;
                case Act0Mode.ConfirmRestart: return 2;
                case Act0Mode.Paused: return 5;
                case Act0Mode.Dialogue: return ActiveDialogue == null ? 1 : ActiveDialogue.choices.Count;
                default: return 1;
            }
        }

        public void ActivateSelection()
        {
            switch (Mode)
            {
                case Act0Mode.Title:
                    int option = SelectedChoice;
                    if (Services.Story.State.started) { if (option == 0) { ContinueGame(); break; } option--; }
                    NewGame("Alex", option == 0 ? "funeral" : "home");
                    break;
                case Act0Mode.ConfirmRestart:
                    if (SelectedChoice == 0) ConfirmRestart(); else CancelMenu();
                    break;
                case Act0Mode.Dialogue:
                    DialogueChoice choice = ActiveDialogue.choices[SelectedChoice];
                    if (choice.id != "close" && !Services.Story.Choose(dialogueTarget, choice.id))
                        Notify("The gathering has moved on. You can still join the mourners outside.");
                    Services.SaveNow();
                    ActiveDialogue = null;
                    Resume();
                    break;
                case Act0Mode.Paused:
                    switch (SelectedChoice)
                    {
                        case 0: Resume(); break;
                        case 1: OpenJournal(); break;
                        case 2: OpenPhone(); break;
                        case 3: SaveProgress(); break;
                        case 4: ReturnToTitle(); break;
                    }
                    break;
                default: Resume(); break;
            }
        }

        public void NewGame(string name, string origin)
        {
            pendingName = name;
            pendingOrigin = origin;
            if (Services.Story.State.started) { SetMode(Act0Mode.ConfirmRestart); return; }
            BeginNewGame();
        }
        public void ConfirmRestart() { BeginNewGame(); }
        private void BeginNewGame()
        {
            Services.NewGame(pendingName, pendingOrigin);
            RefreshContext();
            player.Teleport(SavedPosition());
            previousPosition = player.transform.position;
            Services.WorldManager.Tick(previousPosition);
            followCamera.Follow(player.transform, true);
            lastPhase = Services.Story.State.phase;
            IntroSeconds = 5;
            SetMode(Act0Mode.Intro);
        }
        public void ContinueGame()
        {
            player.Teleport(SavedPosition());
            previousPosition = player.transform.position;
            Services.WorldManager.Tick(previousPosition);
            followCamera.Follow(player.transform, false);
            Resume();
        }
        public void Resume() { SetMode(Act0Mode.Playing); }
        public void PauseGame() { SaveProgress(); SetMode(Act0Mode.Paused); }
        public void OpenJournal() { SetMode(Act0Mode.Journal); }
        public void OpenPhone() { SetMode(Act0Mode.Phone); }
        public void ReturnToTitle() { SaveProgress(); SetMode(Act0Mode.Title); }
        public void CancelMenu()
        {
            if (Mode == Act0Mode.Title) return;
            if (Mode == Act0Mode.ConfirmRestart) { SetMode(Act0Mode.Title); return; }
            ActiveDialogue = null;
            Resume();
        }
        public void SaveProgress()
        {
            Services.SetPlayerPosition(player.transform.position);
            Services.SaveNow();
            Notify(Services.SaveStatus);
        }
        private void SetMode(Act0Mode mode) { Mode = mode; SelectedChoice = 0; }
        private void Notify(string text) { toast = text; toastTimer = 5; }
        private Vector3 SavedPosition()
        { Act0State state = Services.Story.State; return new Vector3(state.playerX, state.playerY, state.playerZ); }
        private void RefreshContext()
        {
            interactionContext.World = Services.World;
            interactionContext.Memory = Services.Memory;
            interactionContext.GameTime = Services.Story.State.gameTime;
        }
    }
}
