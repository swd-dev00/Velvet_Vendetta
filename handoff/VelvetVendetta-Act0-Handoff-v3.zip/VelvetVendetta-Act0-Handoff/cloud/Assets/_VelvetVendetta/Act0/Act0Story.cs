using System;
using System.Collections.Generic;

namespace VelvetVendetta.Act0
{
    public enum Act0Phase { Arrival, Viewing, Service, Wake, Burial, Card, Departure, FreeRoam }
    public enum Act0Target { Maya, Casket, Service, Ruth, Office, Grave, Card, Car, Home, Garage, Velvet, Lookout, Entrance, Darius, Mourner, SUV, Departure }

    [Serializable]
    public sealed class JournalEntry
    {
        public string title;
        public string text;
        public JournalEntry(string title, string text) { this.title = title; this.text = text; }
    }

    [Serializable]
    public sealed class ChoiceRecord
    {
        public string target;
        public string choice;
        public ChoiceRecord(string target, string choice) { this.target = target; this.choice = choice; }
    }

    [Serializable]
    public sealed class Act0State
    {
        public int version = 1;
        public bool started;
        public string name = "Alex";
        public string origin = "funeral";
        public Act0Phase phase = Act0Phase.Arrival;
        public float playerX = 25.6f, playerY, playerZ = 31.2f;
        public float carX = 30.2f, carY, carZ = 31.2f;
        public bool driving;
        public List<string> clues = new List<string>();
        public List<JournalEntry> journal = new List<JournalEntry>();
        public int mayaTrust, ruthTrust;
        public List<ChoiceRecord> choices = new List<ChoiceRecord>();
        public bool completed;
        public double gameTime;
        public bool enteredFuneral;
        public bool burialAttended;

        public string Choice(string target)
        {
            ChoiceRecord found = choices.Find(item => item.target == target);
            return found == null ? null : found.choice;
        }
    }

    [Serializable]
    public sealed class DialogueChoice
    {
        public string id, label, hint;
        public DialogueChoice(string id, string label, string hint = "")
        { this.id = id; this.label = label; this.hint = hint; }
    }

    [Serializable]
    public sealed class Dialogue
    {
        public string speaker, role, title;
        public string[] text;
        public List<DialogueChoice> choices;
        public Dialogue(string speaker, string role, string title, string[] text, params DialogueChoice[] choices)
        {
            this.speaker = speaker; this.role = role; this.title = title; this.text = text;
            this.choices = new List<DialogueChoice>(choices.Length == 0
                ? new[] { new DialogueChoice("close", "Step away") } : choices);
        }
    }

    /// <summary>Pure story rules shared by the Unity prototype and executable regression checks.</summary>
    public sealed class Act0Story
    {
        public Act0State State { get; private set; }
        public event Action Changed;
        public event Action<Act0Target, string> ChoiceMade;

        public Act0Story(Act0State initial = null)
        { State = initial != null && IsValidState(initial) ? initial : new Act0State(); }

        public static string PhaseTitle(Act0Phase phase)
        {
            switch (phase)
            {
                case Act0Phase.Arrival: return "Homecoming";
                case Act0Phase.Viewing: return "An empty wrist";
                case Act0Phase.Service: return "What we remember";
                case Act0Phase.Wake: return "The things left unsaid";
                case Act0Phase.Burial: return "Fresh dirt";
                case Act0Phase.Card: return "A name in black";
                case Act0Phase.Departure: return "The road into Kentahten";
                default: return "The city is yours";
            }
        }

        public static string Objective(Act0Phase phase)
        {
            switch (phase)
            {
                case Act0Phase.Arrival: return "Enter the funeral home. People in the parking lot may have something to say.";
                case Act0Phase.Viewing: return "Take a moment in the viewing room, then sit for the service when ready.";
                case Act0Phase.Service: return "Take your place at the funeral service.";
                case Act0Phase.Wake: return "The gathering is underway. Talk, explore, or follow the road east to the cemetery.";
                case Act0Phase.Burial: return "The cemetery is ready. Say goodbye, then follow the departure road.";
                case Act0Phase.Card: return "An envelope waits by the gate. Take it or leave it, then follow the departure road.";
                case Act0Phase.Departure: return "Follow the departure road south into the free-roam area.";
                default: return "Explore Kentahten: home, the garage, Velvet Row, and the overlook.";
            }
        }

        public static Act0Target ObjectiveTarget(Act0Phase phase)
        {
            switch (phase)
            {
                case Act0Phase.Arrival: return Act0Target.Entrance;
                case Act0Phase.Viewing: return Act0Target.Service;
                case Act0Phase.Service: return Act0Target.Service;
                case Act0Phase.Wake: return Act0Target.Grave;
                case Act0Phase.Burial: return Act0Target.Grave;
                case Act0Phase.Card: return Act0Target.Card;
                case Act0Phase.Departure: return Act0Target.Departure;
                default: return Act0Target.Velvet;
            }
        }

        public void Start(string name, string origin)
        {
            if (State.started) return;
            State = new Act0State();
            State.started = true;
            string cleanedName = (name ?? "").Trim();
            State.name = cleanedName.Length == 0 ? "Alex" : cleanedName.Substring(0, Math.Min(40, cleanedName.Length));
            State.origin = origin == "home" ? "home" : "funeral";
            if (State.origin == "home")
            {
                State.playerX = 19.2f; State.playerZ = 72.4f;
                State.carX = 24.8f; State.carZ = 73.6f;
                State.gameTime = Act0Sequence.ServiceStartSeconds + 60;
                State.phase = Act0Phase.Service;
            }
            Note("Homecoming", State.origin == "home"
                ? "Back in Southside. The apartment Elias left you is quiet. The funeral has already begun at Mercer & Sons, north in Old Kentahten. You can still join it."
                : "You returned to Kentahten for your uncle Elias Mercer's funeral. The entrance is ahead. You can speak with the mourners or go straight inside.");
            Notify();
        }

        public void Reset() { State = new Act0State(); Notify(); }

        public Dialogue Interact(Act0Target target)
        {
            if (!State.started || target == Act0Target.Car) return null;
            Act0Phase phase = State.phase;
            switch (target)
            {
                case Act0Target.Entrance:
                    return new Dialogue("Mercer & Sons", "Funeral-home entrance", "A place has been kept", new[] {
                        State.gameTime >= 240 ? "The service has finished. Voices drift from the post-service gathering. The door is still open."
                        : State.gameTime >= 120 ? "A voice carries through the chapel. The service is underway; you can take a seat quietly."
                        : "Through the open doors are flowers, subdued voices, and a room full of people with their own memories of Elias."
                    }, State.enteredFuneral ? new DialogueChoice("close", "Continue inside") : new DialogueChoice("enter", "Enter the funeral home"));

                case Act0Target.SUV:
                    return new Dialogue("Black SUV", "Parking lot", "A vehicle that does not belong", new[] {
                        "A black SUV sits away from the other cars, its engine quiet and windows dark. A county parking permit rests on the dashboard."
                    }, Has("black-suv") ? new DialogueChoice("close", "Step away") : new DialogueChoice("inspect", "Remember the vehicle and its permit.", "An observation, not an explanation."));

                case Act0Target.Darius:
                    if (State.Choice("darius") != null) return new Dialogue("Darius Cole", "A business associate", "A practiced condolence", new[] {
                        "\"Call if you need anything with the paperwork.\" Darius gives you the same careful smile as before."
                    });
                    return new Dialogue("Darius Cole", "A business associate", "A recent acquaintance", new[] {
                        "\"Darius Cole. Your uncle and I worked together. Only two years, give or take, but enough to know a good man.\"",
                        "He says it before you ask. His eyes flick toward the private-office hallway."
                    }, new DialogueChoice("ask-business", "What kind of work did you do together?", "Record his account."),
                       new DialogueChoice("ask-history", "Only two years?", "Let him commit to the claim."),
                       new DialogueChoice("decline", "Thank you for coming.", "Keep the conversation short."));

                case Act0Target.Mourner:
                    if (State.Choice("mourner") != null) return new Dialogue("Unknown mourner", "An unfamiliar face", "Somewhere else to be", new[] {
                        "The mourner turns away from the conversation. A phone vibrates once in their hand."
                    });
                    return new Dialogue("Unknown mourner", "An unfamiliar face", "Waiting for someone", new[] {
                        "\"Elias hated Wednesdays. Too many promises due on the same day.\" The stranger stops as if they have said more than intended.",
                        "\"Sorry. You must be family.\" Their coat is dry despite the rain."
                    }, new DialogueChoice("ask-name", "I do not think we have met.", "Ask who they are."),
                       new DialogueChoice("ask-wednesday", "What happened on Wednesdays?", "Remember the remark."),
                       new DialogueChoice("observe", "Offer a nod and let them go.", "Remember the face."));

                case Act0Target.Departure:
                    return new Dialogue("The road into Kentahten", "Departure route", "Beyond the funeral", new[] {
                        State.phase >= Act0Phase.Burial ? "The funeral is behind you. Continue along this road into the city; your history goes with you."
                        : "The funeral is still underway. You can explore, or return when the service and gathering have finished."
                    });

                case Act0Target.Maya:
                    if (State.Choice("maya") == null) return new Dialogue("Maya Bell", "An old friend", "You made it home", new[] {
                        "\"" + State.name + ". I kept thinking you wouldn't come.\" Maya stands beneath the wet magnolia, one hand tucked into a borrowed black coat.",
                        "\"Ruth is inside. They kept a place for you. Elias always said you would find your way back.\"",
                        "A truck rolls past the funeral home. Maya watches it until it turns the corner."
                    }, new DialogueChoice("embrace", "Hug Maya. I should have come back sooner.", "Let an old friend back in."),
                       new DialogueChoice("ask", "Tell me what happened to him.", "Start asking questions."),
                       new DialogueChoice("distance", "I am just here for the funeral.", "Keep your distance."));
                    return new Dialogue("Maya Bell", "An old friend", "Still here", new[] {
                        State.Choice("card") == "share"
                            ? "\"Wednesday. Velvet Room. No signature.\" Maya glances toward town. \"Whatever this is, call me before you go.\""
                            : State.mayaTrust > 0 ? "\"You do not have to do today alone.\" Maya leaves the offer there, without asking for anything back."
                            : "Maya gives you room. \"My number is the same. In case that changes.\""
                    });

                case Act0Target.Casket:
                    if (!State.enteredFuneral || State.Choice("casket") != null || phase > Act0Phase.Wake) return new Dialogue("Viewing room", "Mercer & Sons", "A quiet room", new[] {
                        !State.enteredFuneral ? "The viewing room is inside the funeral home."
                        : "The flowers smell stronger now. There is nothing else to say here that the room has not already heard."
                    });
                    return new Dialogue("Elias Mercer", "Your uncle", "An empty wrist", new[] {
                        "The room is all flowers, polished wood, and the soft scrape of shoes. Your uncle looks smaller than you remember.",
                        "His left wrist is bare. For thirty years Elias wore the same silver watch, even when it stopped keeping time.",
                        "On the table, the family photograph has been turned toward the wall."
                    }, new DialogueChoice("remember", "Remember the man who taught you to drive.", "Hold on to a good memory."),
                       new DialogueChoice("notice", "Examine the mark where his watch used to be.", "Something is missing."));

                case Act0Target.Service:
                    if (!State.enteredFuneral || State.Choice("service") != null || phase > Act0Phase.Service) return new Dialogue("The chapel", "Funeral service", "A place has been kept", new[] {
                        !State.enteredFuneral ? "The seats are inside the funeral home. You can enter and sit without talking to anyone first."
                        : "The hymn sheets are still on the pews. The words people chose to say stay with you."
                    });
                    return new Dialogue("Reverend Ellis", "Funeral service", "What we remember", new[] {
                        "\"A city is made of the people who decide to stay, and the people who find their way home.\" The reverend lets the room settle.",
                        "Ruth sits perfectly straight. Maya keeps a space beside her. In the back row, an unfamiliar man leaves before the first hymn ends.",
                        "\"Would anyone like to share a memory of Elias?\""
                    }, new DialogueChoice("family", "Family: he always kept a place for me.", "The room will remember your voice."),
                       new DialogueChoice("work", "Work: he believed a promise should mean something."),
                       new DialogueChoice("loyalty", "Loyalty: he stood by people when it cost him."),
                       new DialogueChoice("last-conversation", "Our last conversation: he asked me about Wednesday.", "Mention Wednesday publicly."),
                       new DialogueChoice("silent", "Remain silent. Listen to everyone else.", "Grief does not owe anyone a performance."));

                case Act0Target.Ruth:
                    if (State.Choice("ruth") != null) return new Dialogue("Ruth Mercer", "Elias's sister", "Family matters", new[] {
                        phase < Act0Phase.Wake ? "\"I need to get through the service. We can talk again after.\""
                        : State.Choice("ruth") == "confront" ? "\"I told you what I know.\" Ruth folds the napkin again. She does not look at the private office."
                        : State.ruthTrust > 0 ? "\"The apartment key is still on the ring he left you. Southside. It is yours as long as you need it.\""
                        : "\"Drive carefully.\" There is a lifetime of things Ruth decides not to add."
                    });
                    var ruth = new Dialogue("Ruth Mercer", "Elias's sister", "A story with a seam", new[] {
                        "Ruth pours coffee nobody drinks. \"He went peacefully. At home. That is what matters.\"",
                        "\"Darius has been around forever. He drove Elias home from the county dinner fifteen years ago. I remember because it snowed.\"",
                        Has("office-watch") ? "The office receipt said his silver watch was handed in. Someone signed it out."
                        : Has("missing-watch") ? "You ask about the watch. Her hand stops halfway to the sugar bowl. \"He must have misplaced it.\""
                        : "Outside, somebody laughs too loudly, then falls quiet. Ruth asks whether you will stay in Kentahten."
                    }, new DialogueChoice("trust", "I will stay awhile. You should not handle this alone.", "Offer Ruth some trust."),
                       new DialogueChoice("press", "What was weighing on him?", "Ask about the contradiction."),
                       new DialogueChoice("deflect", "I have not decided how long I am staying.", "Keep your plans private."));
                    if (Has("office-watch")) ruth.choices.Insert(2, new DialogueChoice("confront", "The receipt says his watch was handed in. Who took it?", "Reveal your private-office intrusion."));
                    return ruth;

                case Act0Target.Office:
                    if (!State.enteredFuneral || phase > Act0Phase.Departure) return new Dialogue("Private office", "Staff only", "A closed door", new[] {
                        !State.enteredFuneral ? "The private office is down the hallway inside the funeral home."
                        : "The office has been locked for the evening. Whatever was left inside will have to wait."
                    });
                    var office = new Dialogue("Private office", "Optional investigation", "Someone has been here", new[] {
                        "The office door is ajar. Beneath a green lamp sit a personal-effects receipt and a folder marked COUNTY RECORDS.",
                        "The corridor is quiet. Looking through either means crossing a line nobody invited you to cross."
                    });
                    office.choices.Clear();
                    if (!Has("office-watch")) office.choices.Add(new DialogueChoice("watch", "Read the personal-effects receipt.", "Investigate the missing watch."));
                    if (!Has("parcel-1147")) office.choices.Add(new DialogueChoice("ledger", "Read the county-records folder.", "Find a lead Elias left unfinished."));
                    office.choices.Add(new DialogueChoice("close", "Leave everything where it is."));
                    return office;

                case Act0Target.Grave:
                    if (phase < Act0Phase.Wake || State.Choice("grave") != null || State.completed) return new Dialogue("Cemetery", "Old Kentahten", "Beneath the magnolias", new[] {
                        phase < Act0Phase.Wake ? "The chairs are arranged beside fresh earth. The service is still underway. The gathering here will follow."
                        : "ELIAS MERCER. The dates say almost nothing about the years between them."
                    });
                    return new Dialogue("Elias's grave", "The burial", "Fresh dirt", new[] {
                        "The last prayer disappears into the trees. One by one, people set their flowers down and return to their cars.",
                        "For a moment it is only you, the wet earth, and the distant sound of the interstate.",
                        "At the cemetery gate, an envelope is tucked into the stonework. Your name is written on it."
                    }, new DialogueChoice("promise", "I will find out what you were trying to do.", "Make a promise."),
                       new DialogueChoice("farewell", "I wish we had more time.", "Let yourself say goodbye."));

                case Act0Target.Card:
                    if (phase < Act0Phase.Burial || Has("black-card")) return new Dialogue("Cemetery gate", "Old Kentahten", "A quiet threshold", new[] {
                        Has("black-card") ? "The envelope is in your pocket. The embossed crown catches the light whenever you turn the card."
                        : "Rain gathers in the seams of the stone gate. There is nothing addressed to you here yet."
                    });
                    return new Dialogue("An unsigned invitation", "Evidence", "The black card", new[] {
                        "Inside the envelope: a heavy black card, an embossed crown, and your name. " + State.name + ".",
                        "YOUR UNCLE KNEW WHAT THIS CITY WAS BUILT ON. WEDNESDAY. THE VELVET ROOM. ASK FOR THE UPSTAIRS TABLE.",
                        "On the back, in Elias's handwriting: TRUST IS A DEBT. The ink is dry. This was written before he died."
                    }, new DialogueChoice("keep", "Pocket the card. Keep this to yourself.", "Carry the invitation into the city."),
                       new DialogueChoice("share", "Show Maya before she leaves.", "Give someone else a piece of the truth."));

                case Act0Target.Home:
                    return new Dialogue("Your apartment", "Southside", "A place to begin again", new[] {
                        phase == Act0Phase.Arrival && State.origin == "home"
                            ? "A half-unpacked suitcase sits beside the bed. Your funeral clothes hang from the door. Maya's message is waiting: I AM OUTSIDE MERCER & SONS. TAKE YOUR TIME."
                            : "Elias kept this small apartment for you. The fridge hums, the key fits, and nobody asks who you are trying to become.",
                        "The funeral home is north in Old Kentahten. Your car is parked by the curb."
                    }, State.Choice("home") == null ? new DialogueChoice("settle", "Put the apartment key on your own ring.", "Make a note of your new home.") : new DialogueChoice("close", "Step outside"));

                case Act0Target.Garage:
                    return new Dialogue("Denny Price", "Southside Garage", "Everybody comes through here", new[] {
                        phase == Act0Phase.FreeRoam ? "\"Elias's people, right? Heard you were back.\" Denny wipes his hands on a rag. \"Bring the car by tomorrow. First look is on me.\""
                        : "The shutters are half down. A handwritten sign reads: BACK AFTER THE SERVICE.",
                        "A parts delivery idles outside. This city keeps moving, even on a day like today."
                    }, phase == Act0Phase.FreeRoam && State.Choice("garage") == null
                        ? new DialogueChoice("introduce", "Introduce yourself. I could use a local garage.", "A first connection in Southside.") : new DialogueChoice("close", "Step away"));

                case Act0Target.Velvet:
                    return new Dialogue("The Velvet Room", "Downtown / Velvet Row", "A city after dark", new[] {
                        Has("black-card") ? "The name on the black card is above the door. The upstairs windows are dark. Wednesday is still ahead."
                        : "A velvet rope lies coiled beside the entrance. Somewhere upstairs, a piano is being tuned.",
                        "Behind you, traffic threads through government offices, late cafes, and apartments full of strangers. There is a whole life here to build."
                    }, phase == Act0Phase.FreeRoam && State.Choice("velvet") == null
                        ? Has("black-card") ? new DialogueChoice("note", "Remember the upstairs windows.", "Keep the Wednesday lead in your journal.")
                        : new DialogueChoice("note", "Take in Velvet Row.", "A place to return after dark.") : new DialogueChoice("close", "Step away"));

                default:
                    return new Dialogue("North County overlook", "The reservoir road", "Far enough to hear yourself", new[] {
                        "Beyond the guardrail: dark water, tree lines, and the city lights reflected beneath a low sky.",
                        State.completed ? Has("black-card")
                            ? "You arrived as a guest at a funeral. Tonight there is a key in your pocket, a name people remember, and an invitation nobody will explain."
                            : "You arrived as a guest at a funeral. Tonight the roads are open, and there is a place for you to begin again."
                        : "From here the city seems quiet. The road back is the same road you came on."
                    });
            }
        }

        public bool Choose(Act0Target target, string choice)
        {
            Dialogue dialogue = Interact(target);
            if (dialogue == null || choice == "close" || !dialogue.choices.Exists(item => item.id == choice)) return false;
            switch (target)
            {
                case Act0Target.Entrance:
                    State.enteredFuneral = true;
                    if (State.phase < Act0Phase.Viewing) State.phase = Act0Phase.Viewing;
                    ApplySchedule();
                    Note("Inside Mercer & Sons", State.gameTime >= 240
                        ? "You entered after the service. The post-service gathering is still open, and the cemetery is east of the funeral home."
                        : State.gameTime >= 120 ? "You entered after the service began. A seat is still available; nobody stops you from joining."
                        : "You stepped into the funeral home. The viewing, conversations, and private hallway are yours to explore.");
                    break;
                case Act0Target.SUV:
                    Clue("black-suv");
                    Note("The black SUV", "A black SUV was parked away from the other mourners' cars. You noticed a county permit on the dashboard. You do not know who arrived in it.");
                    break;
                case Act0Target.Darius:
                    Note("Darius's account", "Darius Cole claimed he had known Elias for approximately two years. "
                        + (choice == "ask-business" ? "Asked about work, he said they dealt in land and introductions."
                        : choice == "ask-history" ? "You asked him to confirm the length of the acquaintance. He repeated: two years, give or take."
                        : "You thanked him for attending and let the conversation end."));
                    break;
                case Act0Target.Mourner:
                    Note("An unfamiliar mourner", "A stranger said Elias hated Wednesdays because too many promises fell due. "
                        + (choice == "ask-name" ? "Asked for a name, they replied only: an old acquaintance."
                        : choice == "ask-wednesday" ? "You asked about Wednesday. They said you should ask someone who worked with him."
                        : "You remembered the face and let them go."));
                    break;
                case Act0Target.Maya:
                    State.mayaTrust += choice == "embrace" ? 2 : choice == "distance" ? -1 : 0;
                    Note("Maya at the gate", choice == "embrace"
                        ? "You let Maya hold you for a moment. She promised to stay close today. An old friendship has room to begin again."
                        : choice == "ask" ? "Maya said the call came late Tuesday. Ruth says Elias died at home. Maya never actually saw him there."
                        : "You told Maya you were only here for the funeral. She stepped back, but made sure you still had her number.");
                    break;
                case Act0Target.Casket:
                    Clue("missing-watch");
                    Note("The missing watch", choice == "notice"
                        ? "The pale mark on Elias's wrist is fresh. His watch was removed recently. You intend to ask Ruth about it."
                        : "You remember Elias teaching you to drive, his silver watch tapping the wheel. Today his wrist is bare.");
                    break;
                case Act0Target.Service:
                    if (choice != "silent") State.mayaTrust++;
                    else Clue("early-departure");
                    string memory = choice == "family" ? "You spoke about the place Elias always kept for you."
                        : choice == "work" ? "You spoke about Elias's belief that a promise should mean something."
                        : choice == "loyalty" ? "You spoke about Elias standing by people when it cost him."
                        : choice == "last-conversation" ? "You told the room Elias had asked you about Wednesday during your last conversation. Several faces turned toward you."
                        : "You remained silent and listened. An unfamiliar man left before the hymn ended.";
                    Note("The funeral service", memory);
                    State.gameTime = Math.Max(State.gameTime, Act0Sequence.ServiceEndSeconds);
                    State.phase = Act0Phase.Wake;
                    break;
                case Act0Target.Ruth:
                    State.ruthTrust += choice == "trust" ? 2 : choice == "confront" ? -2 : choice == "press" ? -1 : 0;
                    Note("Ruth's account", choice == "trust"
                        ? "You offered to stay and help Ruth. She gave you the apartment key and admitted Elias had been losing sleep over county business."
                        : choice == "confront" ? "You confronted Ruth with the receipt. A man from the county collected the watch 'for the family.' She asked why you were in the private office. Her trust in you has cooled."
                        : choice == "press" ? "Pressed about Elias's worries, Ruth mentioned county records, then changed the subject. She insists he went peacefully at home."
                        : "You kept your plans private. Ruth left the apartment key in your hand without another question.");
                    if (choice == "confront") Clue("county-collector");
                    if (choice == "press" || choice == "trust") Clue("county-business");
                    Note("An older acquaintance", "Ruth recalled Darius driving Elias home after a county dinner approximately fifteen years ago. "
                        + (State.Choice("darius") != null ? "Her account and Darius's shorter timeline can both remain in your notes."
                        : "A specific memory linking the two men long before today."));
                    break;
                case Act0Target.Office:
                    if (choice == "watch")
                    {
                        Clue("office-watch");
                        Note("Personal-effects receipt", "Elias's silver watch was received by the funeral home, then signed out before the viewing. The signature is unreadable. "
                            + (State.Choice("ruth") != null && Has("missing-watch") ? "Ruth's explanation does not fit." : "Someone took custody of the watch before you arrived."));
                    }
                    else
                    {
                        Clue("parcel-1147");
                        Note("Parcel 1147", "A county-records folder names Parcel 1147 in North County. Elias circled a pending transfer and wrote: ASK WHO BENEFITS. A lead for after the funeral.");
                    }
                    Record("office-" + choice, choice);
                    if (ChoiceMade != null) ChoiceMade(target, choice);
                    Notify(); return true;
                case Act0Target.Grave:
                    Note("Fresh dirt", choice == "promise"
                        ? "At Elias's grave, you promised to find out what he was trying to do. An envelope with your name was waiting at the gate."
                        : "You said the goodbye you had not managed inside. At the gate, you noticed an envelope with your name.");
                    State.burialAttended = true;
                    State.gameTime = Math.Max(State.gameTime, Act0Sequence.BurialStartSeconds);
                    State.phase = Act0Phase.Departure; break;
                case Act0Target.Card:
                    Clue("black-card");
                    if (choice == "share") State.mayaTrust += 2;
                    Note("The black card", "An embossed crown. Wednesday. The Velvet Room, upstairs table. On the back, in Elias's hand: TRUST IS A DEBT. "
                        + (choice == "share" ? "You showed Maya. She asked you to call before you go; she is now part of this secret."
                        : "You pocketed the invitation. For now, nobody else knows you have it."));
                    break;
                case Act0Target.Home:
                    Note("A key to Southside", "The apartment Elias kept for you is yours to come back to. For the first time in years, you have a home in Kentahten."); break;
                case Act0Target.Garage:
                    Note("Denny at Southside Garage", "You met Denny Price. He offered to look over your car tomorrow. Elias's name still opens a few doors."); break;
                case Act0Target.Velvet:
                    Note(Has("black-card") ? "Wednesday, upstairs" : "The Velvet Room", Has("black-card")
                        ? "You found the Velvet Room on Velvet Row. The upstairs windows are dark tonight. The invitation is a thread for the days ahead."
                        : "You found the Velvet Room on Velvet Row. Music carries through the entrance. Another place in Kentahten to get to know."); break;
                default: return false;
            }
            Record(target.ToString().ToLowerInvariant(), choice);
            if (ChoiceMade != null) ChoiceMade(target, choice);
            Notify();
            return true;
        }

        /// <summary>The funeral schedule continues whether or not a conversation is open.</summary>
        public void Tick(float delta)
        {
            if (!State.started || !Finite(delta) || delta <= 0) return;
            double previousTime = State.gameTime;
            Act0Phase previousPhase = State.phase;
            State.gameTime += delta;
            ApplySchedule();
            if (previousPhase != State.phase || Math.Floor(previousTime) != Math.Floor(State.gameTime)) Notify();
        }

        /// <summary>Call from physical location triggers, never from an on-screen objective selection.</summary>
        public void ReachLocation(Act0Target target)
        {
            if (!State.started || State.completed) return;
            if (target == Act0Target.Entrance && !State.enteredFuneral)
            {
                Choose(Act0Target.Entrance, "enter");
            }
            else if (target == Act0Target.Grave && State.phase >= Act0Phase.Wake && !State.burialAttended)
            {
                State.burialAttended = true;
                State.gameTime = Math.Max(State.gameTime, Act0Sequence.BurialStartSeconds);
                if (State.phase < Act0Phase.Burial) State.phase = Act0Phase.Burial;
                Note("The burial gathering", "You joined the mourners beside Elias's grave. There is time for a private goodbye, but nobody requires you to speak.");
                Notify();
            }
            else if (target == Act0Target.Departure) Depart();
        }

        private void ApplySchedule()
        {
            Act0Phase scheduled = Act0Sequence.PhaseAt(State.gameTime, State.enteredFuneral);
            if (State.phase < scheduled) State.phase = scheduled;
        }

        public void Move(float x, float y, float z, bool driving)
        {
            if (!State.started || !Finite(x) || !Finite(y) || !Finite(z)) return;
            if (State.playerX == x && State.playerY == y && State.playerZ == z && State.driving == driving) return;
            State.playerX = x; State.playerY = y; State.playerZ = z; State.driving = driving;
            if (driving) { State.carX = x; State.carY = y; State.carZ = z; }
            Notify();
        }

        public void ToggleCar()
        {
            if (!State.started) return;
            State.driving = !State.driving;
            if (State.driving) { State.playerX = State.carX; State.playerY = State.carY; State.playerZ = State.carZ; }
            Notify();
        }

        public void ArriveDowntown() { Depart(); }

        /// <summary>The world calls this after crossing the physical departure boundary, on foot.</summary>
        public void Depart()
        {
            if (!State.started || State.completed || State.phase < Act0Phase.Burial) return;
            State.phase = Act0Phase.FreeRoam; State.completed = true;
            Note("Kentahten is waiting", "You physically left the funeral behind and entered the city. Act 0 is complete. Your conversations, observations, and silences remain part of your history. You are free to explore.");
            Notify();
        }

        public static bool IsValidState(Act0State state)
        {
            if (state == null || state.version != 1 || string.IsNullOrWhiteSpace(state.name) || state.name.Length > 40
                || (state.origin != "home" && state.origin != "funeral") || !Enum.IsDefined(typeof(Act0Phase), state.phase)
                || !Finite(state.playerX) || !Finite(state.playerY) || !Finite(state.playerZ)
                || !Finite(state.carX) || !Finite(state.carY) || !Finite(state.carZ)
                || state.clues == null || state.clues.Count > 100 || state.journal == null || state.journal.Count > 200
                || state.choices == null || state.choices.Count > 100 || Math.Abs((long)state.mayaTrust) > 10 || Math.Abs((long)state.ruthTrust) > 10
                || double.IsNaN(state.gameTime) || double.IsInfinity(state.gameTime) || state.gameTime < 0
                || state.completed != (state.phase == Act0Phase.FreeRoam)
                || (!state.started && (state.phase != Act0Phase.Arrival || state.driving || state.completed))
                ) return false;
            var unique = new HashSet<string>();
            foreach (string clue in state.clues)
                if (string.IsNullOrEmpty(clue) || clue.Length > 120 || !unique.Add(clue)) return false;
            foreach (JournalEntry entry in state.journal)
                if (entry == null || string.IsNullOrEmpty(entry.title) || entry.title.Length > 120
                    || string.IsNullOrEmpty(entry.text) || entry.text.Length > 2000) return false;
            unique.Clear();
            foreach (ChoiceRecord choice in state.choices)
                if (choice == null || string.IsNullOrEmpty(choice.target) || choice.target.Length > 120 || !unique.Add(choice.target)
                    || string.IsNullOrEmpty(choice.choice) || choice.choice.Length > 120) return false;
            return true;
        }

        private static bool Finite(float value) { return !float.IsNaN(value) && !float.IsInfinity(value); }
        private bool Has(string clue) { return State.clues.Contains(clue); }
        private void Clue(string clue) { if (!Has(clue)) State.clues.Add(clue); }
        private void Note(string title, string text) { State.journal.Add(new JournalEntry(title, text)); }
        private void Record(string target, string choice)
        {
            ChoiceRecord existing = State.choices.Find(item => item.target == target);
            if (existing != null) existing.choice = choice;
            else State.choices.Add(new ChoiceRecord(target, choice));
        }
        private void Notify() { if (Changed != null) Changed(); }
    }
}
