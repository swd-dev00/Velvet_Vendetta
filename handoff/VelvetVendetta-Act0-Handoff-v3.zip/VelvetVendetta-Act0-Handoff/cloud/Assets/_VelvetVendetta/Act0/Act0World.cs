using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace VelvetVendetta.Act0
{
    /// <summary>A place in the continuous region; narrative state is owned by Act0Director.</summary>
    public sealed class Act0Point
    {
        public Act0Target Target;
        public string Label;
        public Vector3 Position;
        public float Radius;
    }

    /// <summary>
    /// Builds the small, asset-free Act 0 greybox. All geometry lives beneath this component,
    /// so authored additive cells can replace it without changing story or interaction data.
    /// Positive Z is south. The funeral home has a cutaway roof and walkable room entrances.
    /// </summary>
    public sealed class Act0World : MonoBehaviour
    {
        public static readonly Vector3 FuneralSpawn = new Vector3(25.6f, 0f, 31.2f);
        public static readonly Vector3 HomeSpawn = new Vector3(19.2f, 0f, 72.4f);
        public static readonly Vector3 FuneralCar = new Vector3(30.2f, 0f, 31.2f);
        public static readonly Vector3 HomeCar = new Vector3(24.8f, 0f, 73.6f);

        private readonly List<Act0Point> points = new List<Act0Point>();
        private readonly List<Material> materials = new List<Material>();
        private Material grass, road, pavement, cream, brick, darkBrick, roof, wood;
        private Material foliage, goldFoliage, stone, black, glass, copper, ivory, plum, water;
        private Font labelFont;
        private bool built;

        public IReadOnlyList<Act0Point> Points { get { return points; } }

        public void Build()
        {
            if (built) return;
            built = true;
            Palette();
            TerrainAndRoads();
            FuneralExterior();
            Cemetery();
            Southside();
            Downtown();
            CountyEdges();
            Atmosphere();
        }

        /// <summary>Called on a separate world component owned by an additive interior scene.</summary>
        public void BuildInterior(string id)
        {
            if (built) return;
            if (id != "INT_FuneralHome" && id != "INT_PlayerHome") return;
            built = true;
            Palette();
            if (id == "INT_FuneralHome") FuneralHome();
            else PlayerHomeInterior();
        }

        public string DistrictAt(Vector3 position)
        {
            if (position.z < 36f && position.x < 54f) return "OLD KENTAHTEN / BELL & HOLLOWAY";
            if (position.z < 31f && position.x > 74f && position.x < 105f) return "OLD KENTAHTEN / CEDAR REST";
            if (IsDowntown(position)) return "DOWNTOWN / VELVET ROW";
            if (position.z > 59f && position.x < 53f) return "SOUTHSIDE";
            if (position.x > 101f && position.z < 55f) return "NORTH COUNTY / RESERVOIR LOOKOUT";
            if (position.z > 86f && position.x > 62f) return "WEST INDUSTRIAL / FREIGHT APPROACH";
            if (position.z < 10f) return "HORSE COUNTRY / COUNTY LINE";
            return "KENTAHTEN / COUNTY ROADS";
        }

        public static bool IsDowntown(Vector3 position)
        {
            return position.x >= 65f && position.x <= 101f && position.z >= 65f && position.z <= 85f;
        }

        public static bool IsVehicleArea(Vector3 position)
        {
            bool funeralInterior = position.x >= 10.8f && position.x <= 49.6f &&
                                   position.z >= 10.4f && position.z <= 27.2f;
            bool burialGround = position.x >= 76f && position.x <= 103f &&
                                position.z >= 10f && position.z <= 29f;
            return !funeralInterior && !burialGround && position.x > 1f &&
                   position.x < 127f && position.z > 1f && position.z < 103f;
        }

        private void Palette()
        {
            grass = Mat("October grass", new Color(0.24f, 0.29f, 0.23f));
            road = Mat("Old asphalt", new Color(0.13f, 0.15f, 0.17f));
            pavement = Mat("Sidewalk limestone", new Color(0.49f, 0.48f, 0.43f));
            cream = Mat("Aged plaster", new Color(0.69f, 0.65f, 0.55f));
            brick = Mat("Kentucky brick", new Color(0.40f, 0.24f, 0.21f));
            darkBrick = Mat("Downtown brick", new Color(0.23f, 0.22f, 0.25f));
            roof = Mat("Slate roof", new Color(0.18f, 0.21f, 0.23f));
            wood = Mat("Walnut", new Color(0.26f, 0.16f, 0.12f));
            foliage = Mat("Cedar leaves", new Color(0.14f, 0.23f, 0.19f));
            goldFoliage = Mat("October leaves", new Color(0.58f, 0.37f, 0.17f));
            stone = Mat("Gravestone", new Color(0.53f, 0.55f, 0.53f));
            black = Mat("Mourning charcoal", new Color(0.09f, 0.10f, 0.12f));
            glass = Mat("Smoked glass", new Color(0.19f, 0.31f, 0.34f));
            copper = Mat("Warm brass", new Color(0.74f, 0.52f, 0.27f));
            ivory = Mat("Candle ivory", new Color(0.91f, 0.85f, 0.68f));
            plum = Mat("Velvet violet", new Color(0.34f, 0.17f, 0.30f));
            water = Mat("Reservoir water", new Color(0.19f, 0.34f, 0.38f));
#if UNITY_2022_2_OR_NEWER
            labelFont = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
#else
            labelFont = Resources.GetBuiltinResource<Font>("Arial.ttf");
#endif
        }

        private Material Mat(string label, Color color)
        {
            Shader shader = Shader.Find("Universal Render Pipeline/Lit");
            if (GraphicsSettings.currentRenderPipeline == null) shader = Shader.Find("Standard");
            if (shader == null) shader = Shader.Find("Standard");
            if (shader == null) shader = Shader.Find("Universal Render Pipeline/Unlit");
            if (shader == null) shader = Shader.Find("Unlit/Color");
            Material material = new Material(shader) { name = label };
            if (material.HasProperty("_BaseColor")) material.SetColor("_BaseColor", color);
            if (material.HasProperty("_Color")) material.SetColor("_Color", color);
            if (material.HasProperty("_Smoothness")) material.SetFloat("_Smoothness", 0.12f);
            if (material.HasProperty("_Glossiness")) material.SetFloat("_Glossiness", 0.12f);
            materials.Add(material);
            return material;
        }

        private void TerrainAndRoads()
        {
            Box("Kentahten continuous ground", new Vector3(64f, -0.25f, 52f), new Vector3(128f, 0.5f, 104f), grass);
            Flat("County road north/south", 58f, 52f, 8f, 104f, road);
            Flat("Crosstown avenue", 64f, 55f, 128f, 8f, road);
            Flat("Funeral parking and approach", 33f, 33f, 47f, 10f, road);
            Flat("Cedar Rest approach", 77f, 32f, 36f, 5f, road);
            Flat("Reservoir approach", 104f, 41f, 29f, 5f, road);
            Flat("Southside access", 31f, 76f, 50f, 6f, road);
            Flat("Velvet Row plaza", 84f, 77.5f, 39f, 13f, pavement);
            Flat("Freight access", 90f, 91f, 63f, 6f, road);
            Flat("Funeral entry walk", 26.4f, 27.3f, 4.4f, 5f, pavement);
            Flat("Cemetery footpath", 87f, 23f, 3.4f, 18f, pavement);
            Flat("Southside sidewalk", 27f, 72.3f, 41f, 1.2f, pavement);
            Flat("Downtown sidewalk", 79.5f, 62.3f, 45f, 2f, pavement);
            for (int z = 4; z < 102; z += 8)
                Flat("County road center marking", 58f, z, 0.12f, 3.5f, copper, 0.035f);
            for (int x = 4; x < 126; x += 8)
                if (x < 52 || x > 64) Flat("Avenue center marking", x, 55f, 3.5f, 0.12f, copper, 0.035f);
            for (int x = 12; x < 47; x += 6)
                Flat("Parking bay", x, 34f, 0.09f, 3.2f, cream, 0.035f);
            // Bounds are physical, with scenery behind the low wall in the playable region.
            Box("Northern field boundary", new Vector3(64f, 0.65f, 0f), new Vector3(128f, 1.3f, 0.4f), stone);
            Box("Southern region boundary", new Vector3(64f, 0.65f, 104f), new Vector3(128f, 1.3f, 0.4f), stone);
            Box("Western field boundary", new Vector3(0f, 0.65f, 52f), new Vector3(0.4f, 1.3f, 104f), stone);
            Box("Eastern region boundary", new Vector3(128f, 0.65f, 52f), new Vector3(0.4f, 1.3f, 104f), stone);
            Label("OLD KENTAHTEN", new Vector3(27f, 0.08f, 41f), 0.48f, ivory, true);
            Label("COUNTY ROUTE 16", new Vector3(63.5f, 0.08f, 45f), 0.22f, ivory, true);
        }

        private void FuneralExterior()
        {
            // The shell stays in the region while room contents stream additively.
            Wall("Funeral north wall", 30.2f, 10.4f, 38.8f, 0.35f, 2.4f);
            Wall("Viewing west wall", 10.8f, 18.8f, 0.35f, 16.8f, 1.45f);
            Wall("Wake east wall", 49.6f, 18.8f, 0.35f, 16.8f, 1.45f);
            Wall("Front west cutaway", 17.8f, 27.2f, 14f, 0.35f, 0.65f);
            Wall("Front east cutaway", 38.8f, 27.2f, 21.6f, 0.35f, 0.65f);
            Person("Maya", 27.3f, 29.8f, darkBrick, -35f);
            Label("MAYA", new Vector3(27.3f, 2.6f, 29.8f), 0.16f, ivory);
            Person("Mourner by the entrance", 21.5f, 29.7f, black, 60f);
            Person("Unfamiliar mourner", 37.4f, 30.2f, black, -65f);
            ParkedSuv(40f, 35f);
            Point(Act0Target.Maya, "Maya · funeral arrival", 25.8f, 30f);
            Point(Act0Target.Mourner, "Unfamiliar mourner", 36f, 30f);
            // Keep the observation endpoint beside the vehicle: a point inside its body
            // would be occluded by the interaction controller's eye-height linecast.
            Point(Act0Target.SUV, "Parked black SUV", 38.3f, 35f);
            Point(Act0Target.Entrance, "Funeral home entrance", 26.4f, 28f);
            Point(Act0Target.Departure, "The road into Kentahten", 58f, 60f, 3f);
            Label("BELL & HOLLOWAY", new Vector3(30.3f, 3.3f, 10.45f), 0.37f, ivory);
            Label("FUNERAL HOME  /  SINCE 1931", new Vector3(30.3f, 2.75f, 10.45f), 0.13f, ivory);
            Tree(7f, 15f, 4f, foliage);
            Tree(6f, 28f, 3.8f, goldFoliage);
            Tree(48f, 41f, 3.4f, goldFoliage);
            Lamp(11f, 28.7f);
            Lamp(48f, 28.7f);
        }

        private void FuneralHome()
        {
            Flat("Funeral home floor", 30.2f, 18.8f, 38.8f, 16.8f, cream, 0.025f);
            Flat("Viewing room rug", 17f, 16.5f, 8.6f, 8.3f, plum, 0.045f);
            Flat("Chapel runner", 28.6f, 17f, 2f, 10f, plum, 0.045f);
            Flat("Wake room carpet", 41.7f, 15.1f, 12.8f, 7.7f, darkBrick, 0.045f);
            Flat("Office wood floor", 44.7f, 23.1f, 8.5f, 6f, wood, 0.045f);
            Wall("Viewing chapel partition", 22.3f, 16.4f, 0.25f, 11.9f, 1.1f);
            Wall("Chapel wake partition", 34.3f, 16.4f, 0.25f, 11.9f, 1.1f);
            Wall("Viewing doorway west", 13.4f, 22.4f, 5.2f, 0.25f, 0.7f);
            Wall("Viewing doorway east", 20.7f, 22.4f, 3.4f, 0.25f, 0.7f);
            Wall("Chapel doorway west", 24.6f, 22.4f, 4.6f, 0.25f, 0.7f);
            Wall("Chapel doorway east", 32.2f, 22.4f, 4.4f, 0.25f, 0.7f);
            Wall("Wake doorway west", 35.9f, 19.6f, 3.2f, 0.25f, 0.7f);
            Wall("Wake doorway east", 44.9f, 19.6f, 9.4f, 0.25f, 0.7f);
            Wall("Office west partition", 40f, 21.3f, 0.25f, 3.4f, 0.9f);
            Wall("Office doorway south", 40f, 26.45f, 0.25f, 1.5f, 0.7f);

            Box("Casket plinth", new Vector3(17.4f, 0.25f, 13.4f), new Vector3(3.8f, 0.5f, 1.4f), wood);
            Box("Closed walnut casket", new Vector3(17.4f, 0.85f, 13.4f), new Vector3(3.3f, 0.65f, 1.1f), wood);
            Box("Casket brass rail", new Vector3(17.4f, 0.9f, 14f), new Vector3(2.9f, 0.08f, 0.08f), copper, false);
            Flowers(new Vector3(17.4f, 1.23f, 13.4f));
            Candle(13.6f, 12.6f);
            Candle(20.3f, 12.6f);
            Box("Memorial portrait stand", new Vector3(13f, 0.8f, 15.2f), new Vector3(0.15f, 1.6f, 0.15f), wood);
            Box("Memorial portrait", new Vector3(13f, 1.8f, 15.2f), new Vector3(0.9f, 1.05f, 0.1f), copper, false);
            Box("Memorial portrait inset", new Vector3(13f, 1.8f, 15.27f), new Vector3(0.73f, 0.88f, 0.03f), darkBrick, false);
            Box("Chapel lectern", new Vector3(28.6f, 0.65f, 12.4f), new Vector3(1f, 1.3f, 0.7f), wood);
            for (int row = 0; row < 2; row++)
            {
                Bench("Chapel pew", 25.1f, 17.4f + row * 2.3f, 3.2f, wood);
                Bench("Chapel pew", 31.8f, 17.4f + row * 2.3f, 3.2f, wood);
            }
            Person("Officiant", 30.5f, 12.2f, black, 0f);
            Person("Quiet mourner", 24.9f, 17.1f, darkBrick, 0f);
            Person("Quiet mourner", 31.6f, 19.4f, black, 0f);
            Table("Wake refreshments", 45.7f, 12.4f, 4.3f, 1.3f, wood);
            Cylinder("Coffee urn", new Vector3(46.4f, 1.22f, 12.4f), new Vector3(0.28f, 0.32f, 0.28f), stone, false);
            Flowers(new Vector3(44.8f, 1.04f, 12.4f));
            Bench("Wake sofa", 45.6f, 17.8f, 3.8f, plum);
            Person("Ruth", 41.15f, 16.35f, plum, -35f);
            Label("RUTH", new Vector3(41.15f, 2.6f, 16.35f), 0.16f, ivory);
            Person("Darius", 33.2f, 24f, darkBrick, -70f);
            Label("DARIUS", new Vector3(33.2f, 2.6f, 24f), 0.16f, ivory);
            Table("Private office desk", 44.4f, 21.3f, 3.3f, 1.3f, wood);
            Box("Office file cabinet", new Vector3(48.1f, 0.85f, 24.9f), new Vector3(0.9f, 1.7f, 1.1f), darkBrick);
            Box("Unfinished records", new Vector3(44.2f, 1.055f, 21.5f), new Vector3(0.7f, 0.07f, 0.6f), ivory, false);
            Label("VIEWING", new Vector3(17.2f, 0.075f, 21.2f), 0.18f, ivory, true);
            Label("SERVICE", new Vector3(28.5f, 0.075f, 21.2f), 0.18f, ivory, true);
            Label("WAKE", new Vector3(38f, 0.075f, 18.9f), 0.17f, ivory, true);
            Label("PRIVATE", new Vector3(43.6f, 0.09f, 26.1f), 0.15f, ivory, true);
            Point(Act0Target.Casket, "Pay your respects", 17.4f, 15.8f);
            Point(Act0Target.Service, "Funeral service", 28.6f, 15.2f);
            Point(Act0Target.Ruth, "Ruth · the wake", 39.4f, 16.4f);
            Point(Act0Target.Office, "Private office", 43.6f, 24.8f);
            Point(Act0Target.Darius, "Darius · hallway", 32f, 24f);
        }

        private void Cemetery()
        {
            Flat("Cedar Rest lawn", 89.3f, 19.6f, 27f, 18f, grass);
            Wall("Cemetery north wall", 89.5f, 10f, 27f, 0.35f, 0.9f);
            Wall("Cemetery west wall", 76f, 19.3f, 0.35f, 18.6f, 0.7f);
            Wall("Cemetery east wall", 103f, 19.3f, 0.35f, 18.6f, 0.7f);
            Wall("Cemetery entrance west", 80.1f, 29f, 8.2f, 0.35f, 0.7f);
            Wall("Cemetery entrance east", 97.2f, 29f, 11.6f, 0.35f, 0.7f);
            Flat("Fresh earth", 86.4f, 18.25f, 2.1f, 3.2f, wood, 0.04f);
            Box("Fresh grave headstone", new Vector3(86.4f, 0.65f, 16.2f), new Vector3(1.35f, 1.3f, 0.28f), stone);
            Flowers(new Vector3(86.4f, 0.17f, 18.2f));
            for (int row = 0; row < 3; row++)
            {
                Gravestone(79f, 13.6f + row * 4.8f);
                Gravestone(97.5f, 13.6f + row * 4.8f);
            }
            Bench("Cemetery bench", 93.5f, 26.6f, 2.5f, wood);
            Box("Black card", new Vector3(88.45f, 0.075f, 26.4f), new Vector3(0.27f, 0.07f, 0.17f), black, false);
            Box("Card crown mark", new Vector3(88.45f, 0.113f, 26.4f), new Vector3(0.08f, 0.009f, 0.065f), copper, false);
            Person("Mourner at the burial", 90.1f, 19.7f, black, -50f);
            Person("Family friend", 82.2f, 20.1f, darkBrick, 50f);
            Tree(74f, 8f, 4.8f, foliage);
            Tree(104.9f, 12f, 4.5f, foliage);
            Tree(104.9f, 26f, 3.8f, goldFoliage);
            Label("CEDAR REST", new Vector3(89.5f, 2.4f, 10.1f), 0.28f, ivory);
            Point(Act0Target.Grave, "Burial · Cedar Rest", 86.4f, 21.2f);
            Point(Act0Target.Card, "Something in the grass", 88f, 26.4f, 1.65f);
        }

        private void Southside()
        {
            Wall("Apartment north wall", 15.2f, 61.9f, 12f, 0.25f, 2.8f);
            Wall("Apartment west wall", 9.2f, 66.4f, 0.25f, 9f, 2.8f);
            Wall("Apartment east wall", 21.2f, 66.4f, 0.25f, 9f, 1.4f);
            Wall("Apartment front west", 13.75f, 70.9f, 9.1f, 0.25f, 1.4f);
            Wall("Apartment front east", 20.65f, 70.9f, 1.1f, 0.25f, 1.4f);
            Label("SOUTHSIDE APARTMENTS", new Vector3(15.2f, 3.25f, 61.9f), 0.22f, ivory);
            Box("Apartment doorstep", new Vector3(19.2f, 0.08f, 71.25f), new Vector3(1.9f, 0.16f, 0.7f), pavement);
            Building("Lennox garage", 34f, 68.3f, 14f, 8f, 3.7f, cream, "LENNOX AUTO");
            Box("Garage roll-up door", new Vector3(31.6f, 1.35f, 72.35f), new Vector3(4.6f, 2.7f, 0.08f), roof, false);
            for (int i = 1; i < 6; i++)
                Box("Garage door slat", new Vector3(31.6f, i * 0.4f, 72.4f), new Vector3(4.6f, 0.045f, 0.015f), stone, false);
            Cylinder("Workshop tire", new Vector3(42.5f, 0.4f, 70.9f), new Vector3(0.9f, 0.4f, 0.9f), black);
            Cylinder("Workshop tire", new Vector3(42.5f, 0.8f, 70.9f), new Vector3(0.9f, 0.2f, 0.9f), black, false);
            Building("Southside corner store", 13f, 86f, 12f, 8f, 3.6f, cream, "COOPER'S MARKET");
            Building("Southside ordinary home", 33f, 86f, 13f, 9f, 4.5f, brick, "");
            Person("Garage neighbor", 36.9f, 73.8f, roof, 30f);
            Bench("Southside bus stop", 47.7f, 70f, 2.5f, wood);
            Tree(6f, 65f, 3.5f, goldFoliage);
            Tree(46f, 83f, 4f, foliage);
            Lamp(8f, 73f);
            Lamp(43f, 73f);
            Label("SOUTHSIDE", new Vector3(28f, 0.08f, 80.3f), 0.4f, ivory, true);
            Point(Act0Target.Home, "Your apartment", 19.2f, 72.4f);
            Point(Act0Target.Garage, "Lennox Auto", 31.6f, 74f);
        }

        private void PlayerHomeInterior()
        {
            Flat("Apartment floor", 15.2f, 66.4f, 11.7f, 8.7f, wood, 0.035f);
            Flat("Apartment rug", 16.8f, 67f, 5f, 4f, plum, 0.06f);
            Box("Apartment bed frame", new Vector3(11.5f, 0.27f, 64.5f), new Vector3(2.5f, 0.54f, 3.4f), wood);
            Box("Apartment mattress", new Vector3(11.5f, 0.62f, 64.5f), new Vector3(2.4f, 0.25f, 3.2f), cream, false);
            Box("Apartment pillow", new Vector3(11.5f, 0.82f, 63.5f), new Vector3(1.8f, 0.2f, 0.7f), ivory, false);
            Bench("Apartment sofa", 17.5f, 64f, 2.8f, roof);
            Table("Apartment kitchen table", 12.1f, 68.7f, 2.1f, 1.1f, wood);
            Box("Apartment belongings", new Vector3(12.2f, 1.06f, 68.7f), new Vector3(0.65f, 0.1f, 0.5f), ivory, false);
        }

        private void Downtown()
        {
            Building("The Velvet Room", 82f, 66.7f, 15f, 7f, 5.8f, darkBrick, "THE VELVET ROOM");
            Box("Velvet awning", new Vector3(82f, 2.9f, 70.9f), new Vector3(7f, 0.2f, 1.7f), plum, false);
            Box("Velvet double doors", new Vector3(82f, 1.15f, 70.25f), new Vector3(2.2f, 2.3f, 0.08f), black, false);
            Box("Velvet brass door trim", new Vector3(82f, 1.15f, 70.31f), new Vector3(0.07f, 2.3f, 0.02f), copper, false);
            Building("Downtown bank", 96.8f, 66.8f, 9f, 8f, 7.5f, cream, "KENTAHTEN TRUST");
            Building("The Kentahten Ledger", 69f, 67.2f, 7f, 8f, 6.5f, brick, "THE LEDGER");
            Building("Velvet Row restaurants", 73f, 86.5f, 16f, 6f, 4.7f, darkBrick, "");
            Building("Downtown residences", 94.8f, 86.5f, 14f, 6f, 9f, brick, "");
            Flat("Velvet plaza inset", 85f, 77.7f, 8f, 4f, darkBrick, 0.035f);
            Bench("Plaza bench", 69f, 79.5f, 2.7f, wood);
            Bench("Plaza bench", 97f, 79.5f, 2.7f, wood);
            Person("Velvet Row regular", 86f, 72.4f, plum, -40f);
            Person("City resident", 74.8f, 79.8f, roof, 30f);
            Tree(64f, 74f, 3.6f, goldFoliage);
            Tree(103f, 74f, 3.6f, goldFoliage);
            Lamp(75f, 73.2f);
            Lamp(91f, 73.2f);
            Lamp(64f, 83f);
            Label("VELVET ROW", new Vector3(84f, 0.07f, 77.8f), 0.4f, ivory, true);
            Point(Act0Target.Velvet, "The Velvet Room", 82f, 73.2f);
        }

        private void CountyEdges()
        {
            Flat("Reservoir", 119.7f, 20f, 13f, 35f, water);
            // Shore walls keep the prototype player above water without invisible water colliders.
            Box("Reservoir retaining wall", new Vector3(112.8f, 0.7f, 20f), new Vector3(0.5f, 1.4f, 35f), stone);
            Box("Reservoir south bank", new Vector3(119.8f, 0.5f, 37.7f), new Vector3(14f, 1f, 0.5f), stone);
            Flat("Reservoir lookout paving", 108.5f, 37.3f, 6f, 5.3f, pavement);
            Bench("Lookout bench", 110.7f, 35.9f, 2f, wood);
            Label("NORTH COUNTY", new Vector3(109.4f, 2.1f, 34.4f), 0.17f, ivory);
            Point(Act0Target.Lookout, "Reservoir lookout", 108.8f, 37.2f);
            Building("Industrial warehouse", 79f, 98.6f, 21f, 8f, 5.5f, roof, "KENTAHTEN FREIGHT");
            Building("Industrial machine shop", 109f, 97.8f, 16f, 9f, 4.2f, darkBrick, "");
            Box("Freight shipping container", new Vector3(112f, 1.15f, 87.2f), new Vector3(8f, 2.3f, 3f), brick);
            Box("Freight shipping container", new Vector3(121f, 1.15f, 87.2f), new Vector3(6f, 2.3f, 3f), roof);
            Building("Horse country stable", 35f, 4.4f, 18f, 6f, 3.5f, cream, "");
            for (int x = 6; x < 51; x += 5)
                Tree(x, 47f, 3f + (x % 3) * 0.3f, x % 2 == 0 ? foliage : goldFoliage);
            for (int x = 65; x < 107; x += 9)
                Tree(x, 46.5f, 3.5f, x % 2 == 0 ? goldFoliage : foliage);
            Tree(109f, 7f, 4.3f, foliage);
            Tree(109f, 25f, 4.1f, foliage);
            Tree(120f, 47f, 4.2f, goldFoliage);
            Tree(121f, 67f, 4.8f, foliage);
            Tree(113f, 77f, 3.4f, goldFoliage);
            Tree(8f, 98f, 4f, foliage);
            Tree(48f, 98f, 4f, goldFoliage);
            for (int x = 8; x < 52; x += 4)
                Box("Horse fence post", new Vector3(x, 0.65f, 8f), new Vector3(0.13f, 1.3f, 0.13f), wood);
            Box("Horse fence rail", new Vector3(28f, 0.65f, 8f), new Vector3(44f, 0.12f, 0.12f), wood);
            Box("Horse fence rail", new Vector3(28f, 1.1f, 8f), new Vector3(44f, 0.12f, 0.12f), wood);
        }

        private void Atmosphere()
        {
            RenderSettings.ambientMode = AmbientMode.Flat;
            RenderSettings.ambientLight = new Color(0.54f, 0.56f, 0.59f);
            RenderSettings.fog = true;
            RenderSettings.fogMode = FogMode.ExponentialSquared;
            RenderSettings.fogDensity = 0.008f;
            RenderSettings.fogColor = new Color(0.46f, 0.51f, 0.53f);
            // Reuse an authored scene's lights when present.
            if (FindObjectOfType<Light>() != null) return;
            GameObject sunObject = new GameObject("October afternoon");
            sunObject.transform.SetParent(transform, false);
            sunObject.transform.rotation = Quaternion.Euler(48f, -35f, 0f);
            Light sun = sunObject.AddComponent<Light>();
            sun.type = LightType.Directional;
            sun.intensity = 1.05f;
            sun.color = new Color(1f, 0.90f, 0.76f);
            sun.shadows = LightShadows.Soft;
            sun.shadowStrength = 0.5f;
        }

        private void Point(Act0Target target, string label, float x, float z, float radius = 2.1f)
        {
            points.Add(new Act0Point { Target = target, Label = label, Position = new Vector3(x, 0f, z), Radius = radius });
        }

        private GameObject Box(string label, Vector3 position, Vector3 scale, Material material, bool solid = true)
        {
            return Shape(PrimitiveType.Cube, label, position, scale, material, solid);
        }

        private GameObject Cylinder(string label, Vector3 position, Vector3 scale, Material material, bool solid = true)
        {
            return Shape(PrimitiveType.Cylinder, label, position, scale, material, solid);
        }

        private GameObject Shape(PrimitiveType type, string label, Vector3 position, Vector3 scale, Material material, bool solid)
        {
            GameObject item = GameObject.CreatePrimitive(type);
            item.name = label;
            item.transform.SetParent(transform, false);
            item.transform.localPosition = position;
            item.transform.localScale = scale;
            Renderer renderer = item.GetComponent<Renderer>();
            renderer.sharedMaterial = material;
            renderer.shadowCastingMode = solid ? ShadowCastingMode.On : ShadowCastingMode.Off;
            Collider collider = item.GetComponent<Collider>();
            if (!solid && collider != null)
            {
                collider.enabled = false;
                Release(collider);
            }
            return item;
        }

        private void Flat(string label, float x, float z, float width, float depth, Material material, float height = 0.015f)
        {
            Box(label, new Vector3(x, height, z), new Vector3(width, 0.015f, depth), material, false);
        }

        private void Wall(string label, float x, float z, float width, float depth, float height)
        {
            Box(label, new Vector3(x, height * 0.5f, z), new Vector3(width, height, depth), cream);
        }

        private void Label(string text, Vector3 position, float size, Material color, bool ground = false)
        {
            GameObject item = new GameObject(text);
            item.transform.SetParent(transform, false);
            item.transform.localPosition = position;
            item.transform.localRotation = Quaternion.Euler(ground ? 90f : 35f, 180f, 0f);
            TextMesh label = item.AddComponent<TextMesh>();
            label.text = text;
            label.font = labelFont;
            label.fontSize = 52;
            label.characterSize = size;
            label.anchor = TextAnchor.MiddleCenter;
            label.alignment = TextAlignment.Center;
            label.color = color.HasProperty("_BaseColor") ? color.GetColor("_BaseColor") : color.color;
            MeshRenderer renderer = item.GetComponent<MeshRenderer>();
            if (labelFont != null) renderer.sharedMaterial = labelFont.material;
            renderer.shadowCastingMode = ShadowCastingMode.Off;
            renderer.receiveShadows = false;
        }

        private void Person(string label, float x, float z, Material clothing, float rotation)
        {
            GameObject body = Shape(PrimitiveType.Capsule, label, new Vector3(x, 0.88f, z), new Vector3(0.5f, 0.63f, 0.44f), clothing, true);
            body.transform.localRotation = Quaternion.Euler(0f, rotation, 0f);
            Shape(PrimitiveType.Sphere, label + " head", new Vector3(x, 1.72f, z), new Vector3(0.39f, 0.43f, 0.39f), cream, false);
            Box(label + " shoes", new Vector3(x, 0.11f, z), new Vector3(0.47f, 0.22f, 0.48f), black, false);
        }

        private void Bench(string label, float x, float z, float width, Material material)
        {
            Box(label + " seat", new Vector3(x, 0.48f, z), new Vector3(width, 0.15f, 0.65f), material);
            Box(label + " back", new Vector3(x, 0.89f, z + 0.3f), new Vector3(width, 0.7f, 0.13f), material);
            Box(label + " leg", new Vector3(x - width * 0.34f, 0.2f, z), new Vector3(0.14f, 0.4f, 0.5f), black, false);
            Box(label + " leg", new Vector3(x + width * 0.34f, 0.2f, z), new Vector3(0.14f, 0.4f, 0.5f), black, false);
        }

        private void Table(string label, float x, float z, float width, float depth, Material material)
        {
            Box(label, new Vector3(x, 0.91f, z), new Vector3(width, 0.18f, depth), material);
            Box(label + " base", new Vector3(x, 0.4f, z), new Vector3(width * 0.7f, 0.8f, depth * 0.75f), material);
        }

        private void Candle(float x, float z)
        {
            Cylinder("Candle stand", new Vector3(x, 0.55f, z), new Vector3(0.16f, 0.55f, 0.16f), copper);
            Cylinder("Memorial candle", new Vector3(x, 1.22f, z), new Vector3(0.15f, 0.17f, 0.15f), ivory, false);
        }

        private void Flowers(Vector3 position)
        {
            Shape(PrimitiveType.Sphere, "Memorial greenery", position, new Vector3(1.1f, 0.22f, 0.5f), foliage, false);
            for (int i = 0; i < 3; i++)
                Shape(PrimitiveType.Sphere, "White memorial flower", position + new Vector3((i - 1) * 0.28f, 0.12f, 0f), new Vector3(0.25f, 0.19f, 0.25f), ivory, false);
        }

        private void Gravestone(float x, float z)
        {
            Box("Old grave base", new Vector3(x, 0.1f, z), new Vector3(1f, 0.2f, 0.7f), stone);
            Box("Old grave marker", new Vector3(x, 0.55f, z), new Vector3(0.75f, 1.1f, 0.24f), stone);
        }

        private void Tree(float x, float z, float height, Material leaves)
        {
            Cylinder("Tree trunk", new Vector3(x, height * 0.36f, z), new Vector3(0.32f, height * 0.36f, 0.32f), wood);
            Shape(PrimitiveType.Sphere, "Autumn canopy", new Vector3(x, height * 0.82f, z), new Vector3(height * 0.75f, height * 0.8f, height * 0.7f), leaves, false);
        }

        private void Lamp(float x, float z)
        {
            Cylinder("Streetlamp", new Vector3(x, 1.6f, z), new Vector3(0.12f, 1.6f, 0.12f), black);
            Box("Warm lantern", new Vector3(x, 3.3f, z), new Vector3(0.38f, 0.45f, 0.38f), ivory, false);
            Box("Lantern cap", new Vector3(x, 3.56f, z), new Vector3(0.48f, 0.1f, 0.48f), black, false);
        }

        private void ParkedSuv(float x, float z)
        {
            Box("Unmarked black SUV", new Vector3(x, 0.85f, z), new Vector3(2f, 0.95f, 4.5f), black);
            Box("SUV cabin", new Vector3(x, 1.6f, z - 0.25f), new Vector3(1.9f, 0.65f, 2.65f), black);
            Box("SUV windshield", new Vector3(x, 1.65f, z + 1.09f), new Vector3(1.62f, 0.4f, 0.03f), glass, false);
            Box("SUV rear glass", new Vector3(x, 1.65f, z - 1.59f), new Vector3(1.62f, 0.4f, 0.03f), glass, false);
            for (int side = -1; side <= 1; side += 2)
            {
                Box("SUV side glass", new Vector3(x + side * 0.965f, 1.65f, z - 0.2f), new Vector3(0.02f, 0.4f, 2.25f), glass, false);
                for (int end = -1; end <= 1; end += 2)
                {
                    GameObject tire = Cylinder("SUV tire", new Vector3(x + side * 0.96f, 0.45f, z + end * 1.45f), new Vector3(0.8f, 0.15f, 0.8f), black, false);
                    tire.transform.localRotation = Quaternion.Euler(0f, 0f, 90f);
                }
            }
        }

        private void Building(string label, float x, float z, float width, float depth, float height, Material material, string sign)
        {
            Box(label, new Vector3(x, height * 0.5f, z), new Vector3(width, height, depth), material);
            Box(label + " cornice", new Vector3(x, height, z), new Vector3(width + 0.35f, 0.23f, depth + 0.35f), roof, false);
            int windowCount = Mathf.Max(2, Mathf.FloorToInt(width / 3f));
            for (int i = 0; i < windowCount; i++)
            {
                float windowX = x - width * 0.5f + (i + 0.5f) * width / windowCount;
                Box(label + " window", new Vector3(windowX, height > 5f ? height - 1.65f : 1.9f, z + depth * 0.5f + 0.035f), new Vector3(1.05f, 1.4f, 0.06f), glass, false);
            }
            if (!string.IsNullOrEmpty(sign))
                Label(sign, new Vector3(x, height + 0.55f, z + depth * 0.5f), Mathf.Min(0.25f, width / (sign.Length * 1.1f)), ivory);
        }

        private void OnDestroy()
        {
            foreach (Material material in materials)
                if (material != null) Release(material);
        }

        private static void Release(Object item)
        {
            if (Application.isPlaying) Destroy(item);
            else DestroyImmediate(item);
        }
    }
}
