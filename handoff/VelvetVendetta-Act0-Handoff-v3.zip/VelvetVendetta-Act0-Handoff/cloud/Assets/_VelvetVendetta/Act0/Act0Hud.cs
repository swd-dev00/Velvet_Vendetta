using UnityEngine;
using VelvetVendetta.Core;
using VelvetVendetta.Gameplay;

namespace VelvetVendetta.Act0
{
    /// <summary>Temporary controller-friendly UI for the playable greybox. No UI package is required.</summary>
    public sealed class Act0Hud : MonoBehaviour
    {
        private Act0Director director;
        private GUIStyle heading, subtitle, body, small, choice, choiceHint;
        private Vector2 journalScroll, dialogueScroll;
        private Dialogue lastDialogue;
        private readonly Color panel = new Color(.045f, .06f, .065f, .94f);
        private readonly Color accent = new Color(.82f, .72f, .48f, 1);
        private string ConfirmKey { get { return PlayerInput.UsingGamepad ? "A" : "E / Enter"; } }
        private string BackKey { get { return PlayerInput.UsingGamepad ? "B" : "Esc"; } }

        public void Initialize(Act0Director owner) { director = owner; }

        private void Update()
        {
            if (director == null) return;
            // The right stick remains available for reading long text while the left stick selects responses.
            if (director.Mode == Act0Mode.Dialogue)
                dialogueScroll.y = Mathf.Max(0, dialogueScroll.y - PlayerInput.Look.y * 300 * Time.unscaledDeltaTime);
            else if (director.Mode == Act0Mode.Journal)
            {
                float vertical = Mathf.Abs(PlayerInput.Look.y) > .01f ? PlayerInput.Look.y : PlayerInput.Move.y;
                journalScroll.y = Mathf.Max(0, journalScroll.y - vertical * 300 * Time.unscaledDeltaTime);
            }
        }

        private void OnGUI()
        {
            if (director == null || director.Services == null || director.Services.Story == null) return;
            EnsureStyles();
            Matrix4x4 original = GUI.matrix;
            Color originalColor = GUI.color;
            float scale = Mathf.Min(Screen.width / 1280f, Screen.height / 720f);
            if (scale <= 0) return;
            GUI.matrix = Matrix4x4.TRS(new Vector3((Screen.width - 1280 * scale) * .5f,
                (Screen.height - 720 * scale) * .5f, 0), Quaternion.identity, Vector3.one * scale);
            GUI.color = Color.white;
            switch (director.Mode)
            {
                case Act0Mode.Loading:
                    Box(new Rect(380, 300, 520, 110), panel);
                    GUI.Label(new Rect(405, 326, 470, 60), "Returning to Kentahten…", heading);
                    break;
                case Act0Mode.Title: DrawTitle(); break;
                case Act0Mode.Intro: DrawIntro(); break;
                case Act0Mode.Dialogue: DrawDialogue(); break;
                case Act0Mode.Paused: DrawPause(); break;
                case Act0Mode.Journal: DrawJournal(); break;
                case Act0Mode.Phone: DrawPhone(); break;
                case Act0Mode.Complete: DrawCompletion(); break;
                case Act0Mode.ConfirmRestart: DrawRestart(); break;
                default: DrawGameplay(); break;
            }
            GUI.matrix = original;
            GUI.color = originalColor;
        }

        private void EnsureStyles()
        {
            if (heading != null) return;
            heading = TextStyle(32, FontStyle.Bold, Color.white);
            subtitle = TextStyle(21, FontStyle.Bold, accent);
            body = TextStyle(20, FontStyle.Normal, Color.white);
            small = TextStyle(17, FontStyle.Normal, new Color(.8f, .84f, .84f));
            choice = TextStyle(20, FontStyle.Normal, Color.white);
            choiceHint = TextStyle(16, FontStyle.Normal, new Color(.75f, .8f, .8f));
        }

        private static GUIStyle TextStyle(int size, FontStyle weight, Color color)
        {
            var result = new GUIStyle(GUI.skin.label);
            result.fontSize = size;
            result.fontStyle = weight;
            result.wordWrap = true;
            result.richText = false;
            result.normal.textColor = color;
            return result;
        }

        private static void Box(Rect rect, Color color)
        {
            Color previous = GUI.color;
            GUI.color = color;
            GUI.DrawTexture(rect, Texture2D.whiteTexture);
            GUI.color = previous;
        }

        private void Panel(string title, string detail)
        {
            Box(new Rect(128, 35, 1024, 650), panel);
            Box(new Rect(128, 35, 5, 650), accent);
            GUI.Label(new Rect(165, 62, 945, 50), title, heading);
            if (!string.IsNullOrEmpty(detail)) GUI.Label(new Rect(165, 110, 945, 54), detail, small);
        }

        private bool Row(Rect rect, int index, string label, string hint = "")
        {
            bool selected = director.SelectedChoice == index;
            Box(rect, selected ? new Color(.23f, .28f, .27f, 1) : new Color(.1f, .13f, .14f, 1));
            if (selected) Box(new Rect(rect.x, rect.y, 4, rect.height), accent);
            bool clicked = GUI.Button(rect, GUIContent.none, GUIStyle.none);
            GUI.Label(new Rect(rect.x + 16, rect.y + 5, rect.width - 30, string.IsNullOrEmpty(hint) ? rect.height - 8 : 30),
                (selected ? "›  " : "   ") + label, choice);
            if (!string.IsNullOrEmpty(hint)) GUI.Label(new Rect(rect.x + 38, rect.y + 31, rect.width - 54, 24), hint, choiceHint);
            return clicked;
        }

        private void MenuRow(float y, int index, string label, string hint = "")
        {
            if (!Row(new Rect(165, y, 950, string.IsNullOrEmpty(hint) ? 46 : 60), index, label, hint)) return;
            director.SelectChoice(index);
            director.ActivateSelection();
        }

        private void Footer(string extra = "")
        {
            string navigation = PlayerInput.UsingGamepad ? "Left stick / D-pad: select" : "W/S or ↑/↓: select";
            GUI.Label(new Rect(165, 646, 945, 28), navigation + "     " + ConfirmKey + ": confirm"
                + (string.IsNullOrEmpty(extra) ? "" : "     " + extra), small);
        }

        private void DrawTitle()
        {
            Act0State state = director.Services.Story.State;
            Panel("VELVET VENDETTA", "A return to Kentahten, Kentucky");
            GUI.Label(new Rect(165, 177, 940, 48), "ACT 0 — HOMECOMING", subtitle);
            GUI.Label(new Rect(165, 223, 930, 98),
                "You came home for your uncle Elias Mercer's funeral. The doors are open. People are waiting, and the afternoon will carry on while you decide what to do.", body);
            int index = 0;
            float y = 345;
            if (state.started) { MenuRow(y, index++, "Continue", "Return to your saved place in Kentahten."); y += 74; }
            MenuRow(y, index++, "Start at the funeral", "Arrive in the parking lot at Mercer & Sons.");
            MenuRow(y + 74, index, "Start at home — arrive late", "Begin in Southside. The service has already begun.");
            GUI.Label(new Rect(165, 590, 945, 40), director.Services.SaveStatus ?? "", small);
            Footer();
        }

        private void DrawIntro()
        {
            Box(new Rect(0, 0, 1280, 75), new Color(0, 0, 0, .8f));
            Box(new Rect(0, 548, 1280, 172), new Color(0, 0, 0, .85f));
            GUI.Label(new Rect(60, 568, 1100, 42), "ACT 0 — HOMECOMING", heading);
            bool home = director.Services.Story.State.origin == "home";
            GUI.Label(new Rect(60, 615, 1100, 30), home ? "Southside, Kentahten, Kentucky" : "Old Kentahten, Kentucky", subtitle);
            GUI.Label(new Rect(60, 659, 1100, 30), ConfirmKey + ": begin     " +
                (home ? "The service has begun. Follow the road north to Mercer & Sons." : "Take a moment. Then find your way inside."), small);
        }

        private void DrawGameplay()
        {
            Act0State state = director.Services.Story.State;
            Box(new Rect(28, 24, 666, 116), panel);
            GUI.Label(new Rect(45, 35, 635, 32), state.completed ? "KENTAHTEN — FREE ROAM" : "ACT 0 — " + Act0Story.PhaseTitle(state.phase).ToUpperInvariant(), subtitle);
            GUI.Label(new Rect(45, 72, 625, 62), Act0Story.Objective(state.phase), body);
            Box(new Rect(910, 24, 342, 62), panel);
            GUI.Label(new Rect(928, 36, 304, 47), director.Location ?? "Kentahten", body);

            if (!string.IsNullOrEmpty(director.Toast))
            {
                Box(new Rect(265, 163, 750, 68), panel);
                GUI.Label(new Rect(284, 174, 712, 51), director.Toast, body);
            }
            if (!string.IsNullOrEmpty(director.Prompt))
            {
                Box(new Rect(230, 566, 820, 58), panel);
                GUI.Label(new Rect(250, 581, 780, 35), ConfirmKey + "  •  " + director.Prompt, body);
            }
            Box(new Rect(28, 643, 1224, 53), panel);
            GUI.Label(new Rect(45, 653, 1190, 40), PlayerInput.UsingGamepad
                ? "Left stick: move    Right stick: camera    A: interact    LS / RB: hurry    Y / View: journal    Menu: pause"
                : "WASD / arrows: move    Hold right mouse: camera    E: interact    Shift: hurry    J / Tab: journal    Esc: pause", small);
        }

        private void DrawDialogue()
        {
            Dialogue dialogue = director.ActiveDialogue;
            if (dialogue == null) return;
            if (!ReferenceEquals(lastDialogue, dialogue)) { lastDialogue = dialogue; dialogueScroll = Vector2.zero; }
            Panel(dialogue.title, dialogue.speaker + "  ·  " + dialogue.role);
            int count = dialogue.choices == null ? 0 : dialogue.choices.Count;
            float choicesHeight = count * 60;
            float choicesTop = 628 - choicesHeight;
            var textArea = new Rect(165, 168, 950, Mathf.Max(70, choicesTop - 185));
            string text = dialogue.text == null ? "" : string.Join("\n\n", dialogue.text);
            float textHeight = Mathf.Max(textArea.height, body.CalcHeight(new GUIContent(text), textArea.width - 26));
            dialogueScroll = GUI.BeginScrollView(textArea, dialogueScroll, new Rect(0, 0, textArea.width - 26, textHeight));
            GUI.Label(new Rect(0, 0, textArea.width - 26, textHeight), text, body);
            GUI.EndScrollView();
            for (int i = 0; i < count; i++)
            {
                DialogueChoice option = dialogue.choices[i];
                if (Row(new Rect(165, choicesTop + i * 60, 950, 55), i, option.label, option.hint))
                {
                    director.SelectChoice(i);
                    director.ActivateSelection();
                    break;
                }
            }
            Footer(BackKey + ": step away    " + (PlayerInput.UsingGamepad ? "Right stick: read" : "Mouse wheel: read"));
        }

        private void DrawPause()
        {
            Panel("PAUSED", "The afternoon will continue when you return.");
            string[] options = { "Resume", "Journal", "Phone", "Save progress", "Return to title" };
            for (int i = 0; i < options.Length; i++) MenuRow(192 + i * 66, i, options[i]);
            GUI.Label(new Rect(165, 560, 930, 64), director.Services.SaveStatus ?? "", small);
            Footer(BackKey + ": resume");
        }

        private void DrawJournal()
        {
            Panel("JOURNAL", "What you remember. What people told you may not be the whole truth.");
            GUILayout.BeginArea(new Rect(165, 173, 950, 400));
            journalScroll = GUILayout.BeginScrollView(journalScroll);
            foreach (JournalEntry entry in director.Services.Story.State.journal)
            {
                if (entry == null) continue;
                GUILayout.Label(entry.title ?? "", subtitle);
                GUILayout.Label(entry.text ?? "", body);
                GUILayout.Space(16);
            }
            DrawKnownAccounts();
            GUILayout.EndScrollView();
            GUILayout.EndArea();
            MenuRow(590, 0, "Back");
            Footer(BackKey + ": return    " + (PlayerInput.UsingGamepad ? "Stick: scroll" : "Mouse wheel: scroll"));
        }

        private void DrawKnownAccounts()
        {
            bool darius = false, ruth = false, stranger = false;
            SocialMemory memory = director.Services.Memory;
            if (memory == null || memory.claims == null) return;
            foreach (ClaimRecord claim in memory.claims)
            {
                if (claim == null) continue;
                if (claim.topic == "Darius.KnewEliasYears")
                {
                    if (claim.speakerId == GameServices.EntityId(Act0Target.Darius)) darius = true;
                    if (claim.speakerId == GameServices.EntityId(Act0Target.Ruth)) ruth = true;
                }
                if (claim.speakerId == GameServices.EntityId(Act0Target.Mourner) && claim.topic == "Elias.LastMeeting") stranger = true;
            }
            if (!darius && !ruth && !stranger) return;
            GUILayout.Label("Accounts you heard", subtitle);
            if (darius) GUILayout.Label("Darius says he knew Elias for only about two years.", body);
            if (ruth) GUILayout.Label("Ruth remembers Darius driving Elias home from a county dinner fifteen years ago.", body);
            if (darius && ruth) GUILayout.Label("Their timelines do not fit. You do not yet know why.", body);
            if (stranger) GUILayout.Label("An unfamiliar mourner said Elias hated Wednesdays. You have no explanation yet.", body);
        }

        private void DrawPhone()
        {
            Panel("PHONE", "Messages stay with you as you move through Kentahten.");
            GUI.Label(new Rect(165, 180, 945, 33), "Maya Bell", subtitle);
            GUI.Label(new Rect(165, 220, 915, 84), "I'm outside Mercer & Sons. They kept a place for you. Come in when you're ready.", body);
            float y = 325;
            if (director.Services.Story.State.enteredFuneral)
            {
                GUI.Label(new Rect(165, y, 945, 32), "Unknown number", subtitle);
                GUI.Label(new Rect(165, y + 40, 915, 74), "I'm sorry for your loss. Elias wanted you to come home.", body);
                y += 139;
            }
            if (director.Services.World.GetBool("Funeral.MentionedWednesday"))
            {
                GUI.Label(new Rect(165, y, 945, 32), "Unknown number · New message", subtitle);
                GUI.Label(new Rect(165, y + 38, 915, 80), "You mentioned Wednesday. We should talk.", body);
            }
            MenuRow(590, 0, "Back");
            Footer(BackKey + ": return");
        }

        private void DrawCompletion()
        {
            Panel("ACT 0 COMPLETE", "The road into Kentahten");
            GUI.Label(new Rect(165, 196, 920, 145),
                "The funeral is behind you. The people you spoke with, the things you noticed, and the words you chose are part of your history now.", body);
            GUI.Label(new Rect(165, 346, 920, 117),
                "Continue into Southside, stop by the garage, visit Velvet Row, or take the road to the overlook. Kentahten remains open.", body);
            MenuRow(516, 0, "Continue exploring");
            GUI.Label(new Rect(165, 587, 930, 46), director.Services.SaveStatus ?? "", small);
            Footer();
        }

        private void DrawRestart()
        {
            Panel("START A NEW GAME?", "This replaces your current local save.");
            GUI.Label(new Rect(165, 214, 920, 138),
                "Your current place in Kentahten, choices, and journal will be replaced. Cancel to keep them and return to the title.", body);
            MenuRow(403, 0, "Start new game");
            MenuRow(477, 1, "Cancel — keep my progress");
            Footer(BackKey + ": cancel");
        }
    }
}
