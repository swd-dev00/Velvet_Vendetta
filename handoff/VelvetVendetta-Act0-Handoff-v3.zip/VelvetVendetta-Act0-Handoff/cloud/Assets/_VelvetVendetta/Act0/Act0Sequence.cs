using System;
using System.Collections.Generic;

namespace VelvetVendetta.Act0
{
    public enum OpportunityAvailability { Locked, Available, Expired }

    [Serializable]
    public sealed class NarrativeOpportunity
    {
        public string id;
        public Act0Target target;
        public bool optional;
        public double? startsAt;
        public double? endsAt;
        public string[] prerequisites = new string[0];
        public string onMissedEvent = "funeral.continue";
    }

    public sealed class FuneralMilestone
    {
        public readonly string id;
        public readonly double at;
        public readonly Act0Phase phase;
        public FuneralMilestone(string id, double at, Act0Phase phase) { this.id = id; this.at = at; this.phase = phase; }
    }

    /// <summary>Small authored opportunity table. References describe availability, never a compulsory mission chain.</summary>
    public static class Act0Sequence
    {
        public const double ServiceStartSeconds = 120;
        public const double ServiceEndSeconds = 240;
        public const double BurialStartSeconds = 360;

        public static readonly FuneralMilestone[] Milestones = {
            new FuneralMilestone("service-start", ServiceStartSeconds, Act0Phase.Service),
            new FuneralMilestone("service-end", ServiceEndSeconds, Act0Phase.Wake),
            new FuneralMilestone("burial-ready", BurialStartSeconds, Act0Phase.Burial)
        };

        public static readonly string[] KnownFactKeys = {
            "Funeral.WentHomeFirst", "Funeral.Arrived", "Funeral.ArrivalTime", "Funeral.ArrivedLate",
            "Funeral.BlackSUVApproached", "Funeral.BlackSUVObserved", "Funeral.EnteredFuneralHome",
            "Funeral.ViewedDeceased", "Funeral.SpokeWith.Maya", "Funeral.SpokeWith.Ruth", "Funeral.SpokeWith.Darius", "Funeral.SpokeWith.Mourner",
            "Funeral.SatForService", "Funeral.SpokeAtEulogy", "Funeral.MentionedWednesday", "Funeral.PrivateOfficeEntered",
            "Funeral.MissingWatchObserved", "Funeral.OfficeMaterialObserved", "Funeral.BurialAttended",
            "Funeral.BlackCardCollected", "Funeral.Departed", "Act0.Completed"
        };

        public static readonly NarrativeOpportunity[] Opportunities = {
            new NarrativeOpportunity { id = "arrival", target = Act0Target.Entrance, startsAt = 0 },
            new NarrativeOpportunity { id = "parking-lot", target = Act0Target.SUV, prerequisites = new[] { "node:arrival" } },
            new NarrativeOpportunity { id = "funeral-entrance", target = Act0Target.Entrance, prerequisites = new[] { "node:arrival" } },
            new NarrativeOpportunity { id = "viewing-room", target = Act0Target.Casket, optional = true, endsAt = BurialStartSeconds,
                prerequisites = new[] { "fact:Funeral.EnteredFuneralHome" } },
            new NarrativeOpportunity { id = "social-interaction", target = Act0Target.Ruth, optional = true },
            new NarrativeOpportunity { id = "funeral-service", target = Act0Target.Service, startsAt = ServiceStartSeconds, endsAt = ServiceEndSeconds,
                prerequisites = new[] { "fact:Funeral.EnteredFuneralHome" }, onMissedEvent = "funeral.service-missed" },
            new NarrativeOpportunity { id = "post-service-gathering", target = Act0Target.Ruth, startsAt = ServiceEndSeconds },
            new NarrativeOpportunity { id = "private-office", target = Act0Target.Office, optional = true,
                prerequisites = new[] { "fact:Funeral.EnteredFuneralHome" } },
            new NarrativeOpportunity { id = "burial", target = Act0Target.Grave, startsAt = BurialStartSeconds, onMissedEvent = "funeral.burial-missed" },
            new NarrativeOpportunity { id = "black-card", target = Act0Target.Card, optional = true, startsAt = BurialStartSeconds },
            new NarrativeOpportunity { id = "departure", target = Act0Target.Departure, startsAt = BurialStartSeconds },
            new NarrativeOpportunity { id = "free-roam", target = Act0Target.Departure, prerequisites = new[] { "fact:Funeral.Departed" } },
            new NarrativeOpportunity { id = "completion-persisted", target = Act0Target.Departure, prerequisites = new[] { "fact:Act0.Completed" } }
        };

        public static Act0Phase PhaseAt(double gameTime, bool entered)
        {
            Act0Phase phase = entered ? Act0Phase.Viewing : Act0Phase.Arrival;
            foreach (FuneralMilestone milestone in Milestones)
                if (gameTime >= milestone.at && milestone.phase > phase) phase = milestone.phase;
            return phase;
        }

        /// <summary>Pure availability query. The caller records a missed event once; reading never changes history.</summary>
        public static OpportunityAvailability Evaluate(NarrativeOpportunity opportunity, double gameTime,
            Func<string, bool> fact, Func<string, bool> nodeCompleted)
        {
            if (opportunity == null) throw new ArgumentNullException(nameof(opportunity));
            if (double.IsNaN(gameTime) || double.IsInfinity(gameTime) || gameTime < 0)
                throw new ArgumentOutOfRangeException(nameof(gameTime));
            // A deadline can pass even when a player never satisfied the prerequisites.
            if (opportunity.endsAt.HasValue && gameTime >= opportunity.endsAt.Value) return OpportunityAvailability.Expired;
            if (opportunity.startsAt.HasValue && gameTime < opportunity.startsAt.Value) return OpportunityAvailability.Locked;
            if (opportunity.prerequisites == null) return OpportunityAvailability.Locked;
            foreach (string requirement in opportunity.prerequisites)
            {
                if (requirement != null && requirement.StartsWith("fact:", StringComparison.Ordinal))
                {
                    if (fact == null || !fact(requirement.Substring(5))) return OpportunityAvailability.Locked;
                }
                else if (requirement != null && requirement.StartsWith("node:", StringComparison.Ordinal))
                {
                    if (nodeCompleted == null || !nodeCompleted(requirement.Substring(5))) return OpportunityAvailability.Locked;
                }
                else return OpportunityAvailability.Locked;
            }
            return OpportunityAvailability.Available;
        }

        /// <summary>Validate authored references without requiring a Unity scene or any service credentials.</summary>
        public static List<string> Validate(IEnumerable<NarrativeOpportunity> source = null)
        {
            var definitions = new List<NarrativeOpportunity>(source ?? Opportunities);
            var errors = new List<string>();
            var nodes = new Dictionary<string, NarrativeOpportunity>(StringComparer.Ordinal);
            var facts = new HashSet<string>(KnownFactKeys, StringComparer.Ordinal);
            foreach (NarrativeOpportunity node in definitions)
            {
                if (node == null) { errors.Add("Null opportunity."); continue; }
                if (string.IsNullOrWhiteSpace(node.id)) errors.Add("Opportunity has no ID.");
                else if (nodes.ContainsKey(node.id)) errors.Add("Duplicate opportunity ID: " + node.id);
                else nodes.Add(node.id, node);
                if (!Enum.IsDefined(typeof(Act0Target), node.target)) errors.Add("Unknown target on " + node.id);
                if (InvalidTime(node.startsAt) || InvalidTime(node.endsAt)
                    || (node.startsAt.HasValue && node.endsAt.HasValue && node.endsAt.Value < node.startsAt.Value))
                    errors.Add("Invalid time window on " + node.id);
                if (node.prerequisites == null) errors.Add("Missing prerequisite list on " + node.id);
                if (node.onMissedEvent != "funeral.continue" && node.onMissedEvent != "funeral.service-missed" && node.onMissedEvent != "funeral.burial-missed")
                    errors.Add("Unknown missed-event ID on " + node.id);
            }
            foreach (NarrativeOpportunity node in definitions)
            {
                if (node == null || node.prerequisites == null) continue;
                foreach (string requirement in node.prerequisites)
                {
                    if (requirement != null && requirement.StartsWith("fact:", StringComparison.Ordinal))
                    {
                        if (!facts.Contains(requirement.Substring(5))) errors.Add("Unknown fact prerequisite " + requirement + " on " + node.id);
                    }
                    else if (requirement != null && requirement.StartsWith("node:", StringComparison.Ordinal))
                    {
                        string reference = requirement.Substring(5);
                        NarrativeOpportunity prerequisite;
                        if (!nodes.TryGetValue(reference, out prerequisite)) errors.Add("Unknown node prerequisite " + requirement + " on " + node.id);
                        else if (reference == node.id) errors.Add("Self prerequisite on " + node.id);
                        else if (!node.optional && prerequisite.optional) errors.Add("Required opportunity depends on optional discovery: " + node.id);
                    }
                    else errors.Add("Invalid prerequisite " + requirement + " on " + node.id);
                }
            }
            var visited = new HashSet<string>(StringComparer.Ordinal);
            var active = new HashSet<string>(StringComparer.Ordinal);
            foreach (string id in nodes.Keys) DetectCycle(id, nodes, visited, active, errors);
            return errors;
        }

        private static void DetectCycle(string id, Dictionary<string, NarrativeOpportunity> nodes,
            HashSet<string> visited, HashSet<string> active, List<string> errors)
        {
            if (active.Contains(id)) { errors.Add("Cyclic node prerequisites involving " + id); return; }
            if (visited.Contains(id)) return;
            active.Add(id);
            NarrativeOpportunity node = nodes[id];
            if (node.prerequisites != null)
                foreach (string requirement in node.prerequisites)
                    if (requirement != null && requirement.StartsWith("node:", StringComparison.Ordinal)
                        && nodes.ContainsKey(requirement.Substring(5)))
                        DetectCycle(requirement.Substring(5), nodes, visited, active, errors);
            active.Remove(id);
            visited.Add(id);
        }

        private static bool InvalidTime(double? value)
        { return value.HasValue && (double.IsNaN(value.Value) || double.IsInfinity(value.Value) || value.Value < 0); }
    }
}
