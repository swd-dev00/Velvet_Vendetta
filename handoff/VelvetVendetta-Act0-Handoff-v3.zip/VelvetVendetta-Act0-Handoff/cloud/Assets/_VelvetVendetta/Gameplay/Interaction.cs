using System;
using UnityEngine;
using VelvetVendetta.Core;

namespace VelvetVendetta.Gameplay
{
    public enum InteractionKind { Talk, Inspect, PickUp, Open, Sit, Use, EnterVehicle, Examine }

    public sealed class InteractionContext
    {
        public string ActorId;
        public WorldState World;
        public SocialMemory Memory;
        public double GameTime;
    }

    public interface IInteractable
    {
        string PersistentId { get; }
        string Prompt { get; }
        InteractionKind Kind { get; }
        bool CanInteract(InteractionContext context);
        void Interact(InteractionContext context);
    }

}
