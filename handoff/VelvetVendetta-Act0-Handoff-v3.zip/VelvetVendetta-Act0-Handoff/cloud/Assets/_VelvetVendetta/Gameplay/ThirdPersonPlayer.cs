using System.Collections.Generic;
using UnityEngine;

namespace VelvetVendetta.Gameplay
{
    [RequireComponent(typeof(CharacterController))]
    public sealed class ThirdPersonPlayer : MonoBehaviour
    {
        [SerializeField] private float walkSpeed = 3.2f;
        [SerializeField] private float runSpeed = 5.8f;
        [SerializeField] private Animator animator = null;
        public float Speed { get { return velocity.magnitude; } }
        private CharacterController controller;
        private Transform body, leftLeg, rightLeg;
        private Vector3 velocity;
        private float stride;
        private readonly List<Material> materials = new List<Material>();
        private bool animatorHasSpeed;

        public void Initialize(Vector3 position)
        {
            controller = GetComponent<CharacterController>();
            controller.height = 1.8f;
            controller.radius = .32f;
            controller.center = Vector3.up * .9f;
            controller.stepOffset = .25f;
            controller.skinWidth = .04f;
            Material suit = MakeMaterial(new Color(.13f, .15f, .15f));
            Material skin = MakeMaterial(new Color(.58f, .40f, .29f));
            body = new GameObject("Temporary player visual").transform;
            body.SetParent(transform, false);
            Part("Coat", PrimitiveType.Capsule, new Vector3(0, 1.03f, 0), new Vector3(.6f, .46f, .4f), suit);
            Part("Head", PrimitiveType.Sphere, new Vector3(0, 1.64f, 0), Vector3.one * .37f, skin);
            leftLeg = Part("Left leg", PrimitiveType.Cube, new Vector3(-.14f, .35f, 0), new Vector3(.21f, .7f, .24f), suit);
            rightLeg = Part("Right leg", PrimitiveType.Cube, new Vector3(.14f, .35f, 0), new Vector3(.21f, .7f, .24f), suit);
            Part("Left arm", PrimitiveType.Capsule, new Vector3(-.34f, 1f, 0), new Vector3(.17f, .35f, .19f), suit);
            Part("Right arm", PrimitiveType.Capsule, new Vector3(.34f, 1f, 0), new Vector3(.17f, .35f, .19f), suit);
            if (animator != null)
                foreach (AnimatorControllerParameter parameter in animator.parameters)
                    if (parameter.name == "Speed" && parameter.type == AnimatorControllerParameterType.Float)
                        animatorHasSpeed = true;
            Teleport(position);
        }

        public void Tick(Vector2 movement, float cameraHeading, bool running, float delta)
        {
            Vector3 direction = Quaternion.Euler(0, cameraHeading, 0) * new Vector3(-movement.x, 0, -movement.y);
            velocity = Vector3.MoveTowards(velocity, direction * (running ? runSpeed : walkSpeed), 24 * delta);
            controller.Move((velocity + Vector3.down * 8) * delta);
            if (velocity.sqrMagnitude > .01f)
                body.rotation = Quaternion.Slerp(body.rotation, Quaternion.LookRotation(velocity),
                    1 - Mathf.Exp(-14 * delta));
            stride += velocity.magnitude * delta * 3;
            float swing = Mathf.Sin(stride) * Mathf.Min(25, velocity.magnitude * 7);
            leftLeg.localRotation = Quaternion.Euler(swing, 0, 0);
            rightLeg.localRotation = Quaternion.Euler(-swing, 0, 0);
            if (animatorHasSpeed) animator.SetFloat("Speed", velocity.magnitude);
        }

        public void Stop()
        {
            velocity = Vector3.zero;
            if (leftLeg != null) leftLeg.localRotation = rightLeg.localRotation = Quaternion.identity;
            if (animatorHasSpeed) animator.SetFloat("Speed", 0);
        }

        public void Teleport(Vector3 position)
        {
            controller.enabled = false;
            transform.position = position;
            controller.enabled = true;
            Stop();
        }

        private Material MakeMaterial(Color color)
        {
            Shader shader = Shader.Find("Universal Render Pipeline/Lit");
            if (UnityEngine.Rendering.GraphicsSettings.currentRenderPipeline == null || shader == null)
                shader = Shader.Find("Standard");
            if (shader == null) shader = Shader.Find("Sprites/Default");
            Material material = new Material(shader) { color = color };
            materials.Add(material);
            return material;
        }

        private Transform Part(string label, PrimitiveType shape, Vector3 position, Vector3 scale, Material material)
        {
            GameObject part = GameObject.CreatePrimitive(shape);
            part.name = label;
            part.transform.SetParent(body, false);
            part.transform.localPosition = position;
            part.transform.localScale = scale;
            Collider collider = part.GetComponent<Collider>();
            collider.enabled = false;
            Destroy(collider);
            part.GetComponent<Renderer>().sharedMaterial = material;
            return part.transform;
        }

        private void OnDestroy() { foreach (Material material in materials) Destroy(material); }
    }
}
