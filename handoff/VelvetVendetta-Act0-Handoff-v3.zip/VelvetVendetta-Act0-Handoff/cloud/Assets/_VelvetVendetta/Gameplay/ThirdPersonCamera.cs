using UnityEngine;

namespace VelvetVendetta.Gameplay
{
    [RequireComponent(typeof(Camera))]
    public sealed class ThirdPersonCamera : MonoBehaviour
    {
        public float Heading { get; private set; }
        private Transform target;
        private float elevation = 27;
        private Vector3 velocity;
        private float introRemaining;
        private readonly RaycastHit[] hits = new RaycastHit[32];

        public void Follow(Transform player, bool intro)
        {
            target = player;
            introRemaining = intro ? 5 : 0;
            Heading = 0;
            elevation = 27;
            velocity = Vector3.zero;
            transform.position = player.position + new Vector3(0, 7, 12);
        }

        public void Tick(Vector2 look, bool blocked, float delta, bool gamepad)
        {
            if (target == null) return;
            if (!blocked)
            {
                // Mouse input is already a per-frame pixel delta; multiplying by frame
                // duration again would change sensitivity with frame rate.
                Heading += look.x * (gamepad ? 115 * delta : 2.5f);
                elevation = Mathf.Clamp(elevation - look.y * (gamepad ? 75 * delta : 2.5f), 12, 68);
            }
            float cinematic = Mathf.Clamp01(introRemaining / 5);
            introRemaining = Mathf.Max(0, introRemaining - delta);
            Vector3 focus = target.position + Vector3.up * 1.3f;
            float distance = Mathf.Lerp(6.5f, 15, cinematic);
            Vector3 offset = Quaternion.Euler(-Mathf.Lerp(elevation, 35, cinematic), Heading, 0) * Vector3.forward * distance;
            Vector3 desired = focus + offset;
            Vector3 direction = (desired - focus).normalized;
            int count = Physics.SphereCastNonAlloc(focus, .22f, direction, hits, distance, ~0, QueryTriggerInteraction.Ignore);
            float unobstructed = distance;
            for (int i = 0; i < count; i++)
            {
                if (hits[i].collider.transform.IsChildOf(target)) continue;
                unobstructed = Mathf.Min(unobstructed, Mathf.Max(.8f, hits[i].distance - .15f));
            }
            desired = focus + direction * unobstructed;
            transform.position = Vector3.SmoothDamp(transform.position, desired, ref velocity, .12f, Mathf.Infinity, delta);
            transform.LookAt(focus);
        }
    }
}
