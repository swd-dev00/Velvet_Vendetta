using System;
using UnityEngine;
using VelvetVendetta.Core;

namespace VelvetVendetta.Gameplay
{
    public sealed class InteractionController : MonoBehaviour
    {
        public IInteractable Current { get; private set; }
        private readonly Collider[] nearby = new Collider[48];
        private InteractionContext context;
        private Camera view;

        public void Initialize(InteractionContext interactionContext, Camera camera)
        { context = interactionContext; view = camera; }

        public void Scan()
        {
            Current = null;
            Vector3 eye = transform.position + Vector3.up * 1.2f;
            int count = Physics.OverlapSphereNonAlloc(eye, 3.8f, nearby, ~0, QueryTriggerInteraction.Collide);
            float best = float.MaxValue;
            for (int i = 0; i < count; i++)
            {
                InteractionTarget candidate = nearby[i].GetComponent<InteractionTarget>();
                if (candidate == null || !candidate.CanInteract(context)) continue;
                Vector3 target = candidate.transform.position + Vector3.up * 1.2f;
                float distance = Vector3.Distance(eye, target);
                if (distance > candidate.Radius) continue;
                Vector3 screen = view.WorldToViewportPoint(target);
                if (screen.z < 0 || screen.x < -.1f || screen.x > 1.1f) continue;
                RaycastHit hit;
                if (Physics.Linecast(eye, target, out hit, ~0, QueryTriggerInteraction.Ignore)
                    && !hit.transform.IsChildOf(transform)
                    && !hit.transform.IsChildOf(candidate.transform)) continue;
                float score = distance + Mathf.Abs(screen.x - .5f);
                if (score < best) { best = score; Current = candidate; }
            }
        }

        public bool TryInteract()
        {
            if (Current == null || !Current.CanInteract(context)) return false;
            Current.Interact(context);
            return true;
        }
    }
}
