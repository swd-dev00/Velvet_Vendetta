using System;
using UnityEngine;
using VelvetVendetta.Core;

namespace VelvetVendetta.Gameplay
{
    // A reusable endpoint. The narrative/location owner supplies the action, not the player.
    public sealed class InteractionTarget : MonoBehaviour, IInteractable
    {
        public string PersistentId { get; private set; }
        public string Prompt { get; private set; }
        public InteractionKind Kind { get; private set; }
        public float Radius { get; private set; }
        private Action<InteractionContext> action;
        private Func<bool> available;

        public void Initialize(string id, string prompt, InteractionKind kind, float radius,
            Action<InteractionContext> onInteract, Func<bool> canInteract = null)
        {
            PersistentId = id;
            Prompt = prompt;
            Kind = kind;
            Radius = radius;
            action = onInteract;
            available = canInteract;
            EntityIdentity identity = GetComponent<EntityIdentity>();
            if (identity == null) identity = gameObject.AddComponent<EntityIdentity>();
            identity.Initialize(id);
            SphereCollider trigger = gameObject.AddComponent<SphereCollider>();
            trigger.radius = .3f;
            trigger.center = Vector3.up * .8f;
            trigger.isTrigger = true;
        }

        public bool CanInteract(InteractionContext context)
        { return context != null && action != null && (available == null || available()); }
        public void Interact(InteractionContext context)
        { if (CanInteract(context)) action(context); }
    }

}
